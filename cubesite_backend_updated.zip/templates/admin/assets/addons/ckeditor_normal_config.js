CKEDITOR.editorConfig = function( config )
{
	config.skin = 'moono';
	config.toolbarCanCollapse = false;
	config.language = 'en';

	config.toolbar = 'Normal';
	config.toolbar_Normal=
	[
		['Source'], ['Bold', 'Italic', 'Underline', '-', 'RemoveFormat'], ['NumberedList', 'BulletedList', '-', 'Indent', 'Outdent', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'], ['Link', 'Unlink'],
		'/', 
		['Format', 'Font', 'FontSize'], ['TextColor', 'BGColor'], ['Image', 'Table', 'HorizontalRule'], ['ShowBlocks', 'Maximize']
	];

};