<?php

$dir = dirname(__FILE__);
$root = realpath($dir . '/..');

// Turn off all error reporting 
	// error_reporting(0);

// Prevents errors being displayed
	ini_set('display_errors','Off');

// ini_set('max_execution_time', 300);
	set_time_limit(300);

// enable logging cron errors to specific file
	ini_set('log_errors', TRUE);
	ini_set('error_log', $dir . '/cron_error.log');

// Start CRON Interval
	$time_start = microtime(true);

/* Include CRON Dependencies
/* NOTE: $current_dir is retrived from app.init.php
-------------------------------------------------- */
	require_once $root . '/inc/app.init.php';
	require_once $current_dir . '/function_final_process.php';
	require_once $current_dir . '/function_estimation.php';
	require_once $current_dir . '/lib/classes/phpwhois-cvs/whois.main.php';
	require_once $current_dir . '/lib/classes/GooglePR.class.php';
	require_once $current_dir . '/lib/classes/maxmind_geoip/geoip.inc';
	require_once $current_dir . '/lib/classes/shuber-curl/curl.php';
	require_once $current_dir . '/lib/classes/shuber-curl/curl_response.php';
	require_once $current_dir . '/lib/classes/stats.class.php';

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Required Configurations and Set it on Session 
-------------------------------------------------- */
	$arg = array(
		'ALLOW_SUBDOMAIN',
		'DATA_PRIVACY_UNSAFE',
		'GOOGLE_API_SERVER_APPS',
		'SEOMOZ_API_ACCESSID',
		'SEOMOZ_API_SECRETKEY',
		'GOOGLE_SAFE_BROWSING_API',
		'WOT_API',
		'IPINFODB_API',
		'TOTAL_INTERNET_USERS',
		'CRON_INTERVAL'
		);
	$sql = "SELECT placeholder, value FROM config WHERE placeholder IN ('" . implode("', '", $arg) . "')";
	$rows = $db->fetch_array($sql);
	foreach ($rows as $record) {
		$config[$record['placeholder']] = $record['value'];
	}

/* Get Active TLDs
-------------------------------------------------- */
	$sql = "SELECT extension FROM tld WHERE status = 'ACTIVE'";
	$rows = $db->fetch_array($sql);
    foreach ($rows as $record) {
        $config['active_tld'][] = $record['extension'];
    }

/* Fetch Domains from Queue
-------------------------------------------------- */
	$sql = "SELECT id, domain FROM queue_domains ORDER BY id ASC LIMIT 15";
	$rows = $db->fetch_array($sql);

/* Process Domains from Queue
-------------------------------------------------- */
	foreach ($rows as $record) {

		$queue_id = $record['id'];
		$domain_array = getDomain($record['domain']);

		$db->query("DELETE FROM queue_domains WHERE id='$queue_id'");

		if ($domain_array) {

			$domain = $domain_array['label'] . '.' . $domain_array['extension'];
			if ($domain_array['sub_domain'] != "") {
				$domain = $domain_array['sub_domain'] . '.' . $domain;
				$is_sub_domain = "yes";
			}

			$sql = "SELECT id FROM insights_base WHERE domain = '$domain'";
			$row = $db->query_first($sql);

			if(empty($row['id'])) {

				$where_clause_data = array();
				$where_clause_data[] = "data = '$domain'";
				if ($domain_array['sub_domain'] != "") {
					$where_clause_data[] = "data = '" . $domain_array['label'] . "." . $domain_array['extension'] . "'";
				}
				$where_clause_data = implode(" || ", $where_clause_data);

				$blocking_sql = "SELECT id FROM blockings WHERE type = 'DOMAINS' && ($where_clause_data)";
				$blocking_row = $db->query_first($blocking_sql);

				if (empty($blocking_row['id']) || (!empty($blocking_row['id']) && $config['DATA_PRIVACY_UNSAFE'] != "BLOCKED TO ALL")) {

					// print $domain . "<br />";

					/* Initiate Stat Class
					-------------------------------------------------- */
						$stat = new stats;

					$response_meta = $stat->getMeta($domain);
					// print_r($response_meta);
					if ($response_meta['status'] != 'success') { continue; }

					$response_host = $stat->getHost($domain, $config['IPINFODB_API']);
					// print_r($response_host);
					if ($response_host['status'] != 'success') { continue; }

					$response_pagespeed = $stat->getPageSpeed($domain, $config['GOOGLE_API_SERVER_APPS']);
					// print_r($response_pagespeed);
					if ($response_pagespeed['status'] != 'success') { continue; }

					$response_weboftrust = $stat->getWebOfTrustData($domain, $config['WOT_API']);
					// print_r($response_weboftrust);
					if ($response_weboftrust['status'] != 'success') { continue; }

					$response_safebrowsing = $stat->getSafeBrowsingData($domain, $config['GOOGLE_SAFE_BROWSING_API']);
					// print_r($response_safebrowsing);
					if ($response_safebrowsing['status'] != 'success') { continue; }

					$response_siteadvisor = $stat->getSiteAdvisor($domain);
					// print_r($response_siteadvisor);
					if ($response_siteadvisor['status'] != 'success') { continue; }

					$response_pagerank = $stat->getGooglePageRank($domain);
					// print_r($response_pagerank);
					if ($response_pagerank['status'] != 'success') { continue; }

					$response_alexa = $stat->getAlexa($domain);
					// print_r($response_alexa);
					if ($response_alexa['status'] != 'success') { continue; }
					
					if ($is_sub_domain != 'yes') {

						$response_seomoz = $stat->getSeoMoz($domain, $config['SEOMOZ_API_ACCESSID'], $config['SEOMOZ_API_SECRETKEY']);
						// print_r($response_seomoz);
						if ($response_seomoz['status'] != 'success') { continue; }

						$response_whois = $stat->getWhois($domain);
						// print_r($response_whois);
						if ($response_whois['status'] != 'success') { continue; }

					};

					$dns = $stat->getDNS($domain);
					$response_dns['data'] = array(
						'dns_records' => $dns['data']['dns_records']
						);

					$google_indexed_page = $stat->getGoogleIndexedPage($domain);
					$bing_indexed_page = $stat->getBingIndexedPage($domain);
					$yahoo_indexed_page = $stat->getYahooIndexedPage($domain);
					$google_inbound_links = $stat->getGoogleInboundLinks($domain);
					$bing_inbound_links = $stat->getBingInboundLinks($domain);
					$response_searchengine['data'] = array(
						'google_indexed_page' => $google_indexed_page['data']['google_indexed_page'],
						'google_inbound_links' => $google_inbound_links['data']['google_inbound_links'],
						'yahoo_indexed_page' => $yahoo_indexed_page['data']['yahoo_indexed_page'],
						'bing_indexed_page' => $bing_indexed_page['data']['bing_indexed_page'],
						'bing_inbound_links' => $bing_inbound_links['data']['bing_inbound_links']
						);

					$facebook = $stat->getFacebookData($domain);
					$twitter = $stat->getTwitterData($domain);
					$linkedin = $stat->getLinkedInData($domain);
					$delicious = $stat->getDeliciousData($domain);
					$googleplus = $stat->getGooglePlusData($domain);
					$response_social['data'] = array(
						'fb_share_count' => $facebook['data']['fb_share_count'],
						'fb_like_count' => $facebook['data']['fb_like_count'],
						'fb_comment_count' => $facebook['data']['fb_comment_count'],
						'twitter_count' => $twitter['data']['twitter_count'],
						'linkedin_share_count' => $linkedin['data']['linkedin_share_count'],
						'delicious_total_posts' => $delicious['data']['delicious_total_posts'],
						'g_plus_count' => $googleplus['data']['g_plus_count']
						);


					$final_data = array_merge(
						$response_meta['data'],
						$response_host['data'],
						$response_pagerank['data'],
						$response_pagespeed['data'],
						$response_safebrowsing['data'],
						$response_weboftrust['data'],
						$response_siteadvisor['data'],
						$response_alexa['data'],
						$response_seomoz['data'],
						$response_whois['data'],
						$response_dns['data'],
						$response_searchengine['data'],
						$response_social['data']
						);
					$args = array(
						'domain' => $domain,
						'extension' => $domain_array['extension'],
						'is_sub_domain' => $is_sub_domain,
						'type' => "add",
						'total_internet_users' => $config['TOTAL_INTERNET_USERS'],
						'data' => $final_data
						);
					$response = finalProcess($args, true);

					// print_r($response);
					// print "<hr />";

					/* Pause for 5 seconds
					-------------------------------------------------- */
						sleep(5);

				}

			}

		}

		/* Log Memory Usages
		-------------------------------------------------- */
			// $m = memory_get_peak_usage(true)/1024/1024;
			// file_put_contents($dir . "/memory.log", $m . "\n", FILE_APPEND | LOCK_EX);

		/* Break (Stop Processing) the loop if more than $config['CRON_INTERVAL'] minutes
		/* We reserved 2 seconds on each minutes to make sure multiple cron will not be activated on same instances 
		-------------------------------------------------- */
			if ( (microtime(true) - $time_start) > $config['CRON_INTERVAL'] * 58) {
				break;
			}

	}

/* Close Database Connection
-------------------------------------------------- */
	$db->close();
?>