<?php
/* Defining Header Information and Starting Session
-------------------------------------------------- */
	header("Cache-Control: no-cache");
	header("Pragma: no-cache");
	header('Content-type: application/json');
	session_start();

/* Including Dependencies
-------------------------------------------------- */
	require_once '../inc/app.init.php';
	require_once $current_dir . '/function_final_process.php';
	require_once $current_dir . '/function_estimation.php';
	require_once $current_dir . '/lib/classes/phpwhois-cvs/whois.main.php';
	require_once $current_dir . '/lib/classes/GooglePR.class.php';
	require_once $current_dir . '/lib/classes/maxmind_geoip/geoip.inc';
	require_once $current_dir . '/lib/classes/shuber-curl/curl.php';
	require_once $current_dir . '/lib/classes/shuber-curl/curl_response.php';
	require_once $current_dir . '/lib/classes/stats.class.php';

/* Populating Posted Data
-------------------------------------------------- */
	$domain 				= trim($_POST['domain']);
	$session_domain 		= $_SESSION['run_process_domain'];
	$token_id 				= $_SESSION['token_id'];
	$request_time 			= $_SESSION['request_time'];

	$step 					= trim($_POST['step']);
	
	$is_sub_domain 			= trim($_POST['is_sub_domain']);
	$type 					= trim($_POST['type']);
	
	$final_data 			= $_POST['final_data'];
	
	$total_internet_users 	= $_SESSION['TOTAL_INTERNET_USERS'];

if(strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {

	$response = array(
		'status' => 'error',
		'msg' => 'Not a Valid Ajax Request.'
	);

} elseif ($domain != $session_domain) {
	
	$response = array(
		'status' => 'error',
		'msg' => 'Invalid Domain.'
	);

} elseif (validateToken($token_id, $request_time, '120') != TRUE) {
	
	$response = array(
		'status' => 'error',
		'msg' => 'Invalid Token Data.'
	);

} else {

	$stat = new stats;

	if ($step == "meta") {

		$response = $stat->getMeta($domain);

	} elseif ($step == "dns") {

		$dns = $stat->getDNS($domain);

		$response = array(
			'status' => 'success',
			'data' => array(
				'dns_records' => $dns['data']['dns_records']
			)
		);

	} elseif ($step == "host") {

		$response = $stat->getHost($domain);

	} elseif ($step == "whois") {

		$response = $stat->getWhois($domain);

	} elseif ($step == "pagerank") {

		$response = $stat->getGooglePageRank($domain);

	} elseif ($step == "pagespeed") {

		$response = $stat->getPageSpeed($domain);

	} elseif ($step == "seomoz" && $is_sub_domain != "yes") {

		$response = $stat->getSeoMoz($domain);

	} elseif ($step == "siteadvisor") {

		$response = $stat->getSiteAdvisor($domain);

	} elseif ($step == "alexa") {

		$response = $stat->getAlexa($domain);

	} elseif ($step == "social") {

		$facebook = $stat->getFacebookData($domain);
		$twitter = $stat->getTwitterData($domain);
		$linkedin = $stat->getLinkedInData($domain);
		$delicious = $stat->getDeliciousData($domain);
		$googleplus = $stat->getGooglePlusData($domain);

		$response = array(
			'status' => 'success',
			'data' => array(
				'fb_share_count' => $facebook['data']['fb_share_count'],
				'fb_like_count' => $facebook['data']['fb_like_count'],
				'fb_comment_count' => $facebook['data']['fb_comment_count'],
				'twitter_count' => $twitter['data']['twitter_count'],
				'linkedin_share_count' => $linkedin['data']['linkedin_share_count'],
				'delicious_total_posts' => $delicious['data']['delicious_total_posts'],
				'g_plus_count' => $googleplus['data']['g_plus_count']
			)
		);

	} elseif ($step == "safebrowsing") {

		$response = $stat->getSafeBrowsingData($domain);

	} elseif ($step == "weboftrust") {

		$response = $stat->getWebOfTrustData($domain);

	} elseif ($step == "searchengine") {

		$google_indexed_page = $stat->getGoogleIndexedPage($domain);
		$bing_indexed_page = $stat->getBingIndexedPage($domain);
		$yahoo_indexed_page = $stat->getYahooIndexedPage($domain);
		$google_inbound_links = $stat->getGoogleInboundLinks($domain);
		$bing_inbound_links = $stat->getBingInboundLinks($domain);

		$response = array(
			'status' => 'success',
			'data' => array(
				'google_indexed_page' => $google_indexed_page['data']['google_indexed_page'],
				'google_inbound_links' => $google_inbound_links['data']['google_inbound_links'],
				'yahoo_indexed_page' => $yahoo_indexed_page['data']['yahoo_indexed_page'],
				'bing_indexed_page' => $bing_indexed_page['data']['bing_indexed_page'],
				'bing_inbound_links' => $bing_inbound_links['data']['bing_inbound_links']
			)
		);

	} elseif ($step == "final_process") {

		/* Initiate Database Connection and database related works
		-------------------------------------------------- */
			$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
			$db->connect();

		/* Process Final Step
		-------------------------------------------------- */
			$args = array(
				'domain' => $domain,
				'extension' => $_SESSION['extension'],
				'is_sub_domain' => $is_sub_domain,
				'type' => $type,
				'total_internet_users' => $total_internet_users,
				'data' => $final_data
				);
			$response = finalProcess($args);

		/* Post Tweets (if enabled)
		-------------------------------------------------- */
			if ($_SESSION['TWITTER_AUTOMATION'] == "ENABLED" && $response['status'] == "success" && !empty($final_data['page_title']) && (empty($response['is_unsafe']) || ($response['is_unsafe'] == true && $_SESSION['DATA_PRIVACY_UNSAFE'] != "BLOCKED TO ALL")) && ($_SESSION['MANUAL_APPROVAL_DOMAIN'] == "DISABLED" || ($_SESSION['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $_SESSION['DATA_PRIVACY_PENDING'] != "BLOCKED TO ALL")) && strtolower(trim($final_data['page_title'])) != $domain) {

				$tmsg = trim(html_entity_decode($final_data['page_title'], ENT_QUOTES, 'UTF-8'));
				$count_tmsg = mb_strlen($tmsg, "UTF-8");
				$valid_length = (stripos($tmsg, $domain) !== false) ? 115 - 24 + strlen($domain) : 115 ;

				if ($count_tmsg > $valid_length) {
					$tmsg = mb_substr($tmsg, 0, $valid_length - 3, "UTF-8") . "...";
				}

				$tmsg = $tmsg . " " . $_SESSION['stat_url'];
				
				require_once $current_dir . '/lib/classes/tmhOAuth/tmhOAuth.php';
				
				$tmhOAuth = new tmhOAuth(array(
					'consumer_key'    => $_SESSION['TWITTER_CONSUMER_KEY'],
					'consumer_secret' => $_SESSION['TWITTER_CONSUMER_SECRET'],
					'user_token'      => $_SESSION['TWITTER_USER_TOKEN'],
					'user_secret'     => $_SESSION['TWITTER_USER_SECRET'],
					));

				$tmhOAuth->request('POST', $tmhOAuth->url('1.1/statuses/update'), array(
					'status' => $tmsg
					));
				
			}

		/* Clear Cache
		-------------------------------------------------- */
			if ($response['status'] == "success") {
				$smarty->clearCache(NULL, 'stats|' . $domain);
				$smarty->clearCache(NULL, 'widget|' . $domain);
			}

		/* Close Database Connection
		-------------------------------------------------- */
			$db->close();

	} else {

		$response = array(
			'status' => 'error',
			'msg' => 'Unknown Step.'
		);

	}
	
}

print json_encode($response);

?>