<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$id = (int) trim($_GET['id']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	$load_tld = ($action == "add" && $_POST['cmd'] == "process_form") ? true : false ;
	getConfiguration($smarty, $placeholders, $load_tld);

/* Process Actions
-------------------------------------------------- */

	if ($action == "manage") {

		$data['page_header'] = 'Manage Allowed Subdomain Hosts';

		$sql = "SELECT COUNT(id) AS total_items FROM subdomain_hosts";
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "subdomain_hosts.php?action=$action&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, host FROM subdomain_hosts ORDER BY host ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add Allowed Subdomain Hosts';

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {
			
			$host = getDomain($_POST['host'], FALSE);

			if ($host) {

				$data['form_data']['host'] = $host = $host['label'] . '.' . $host['extension'];

				$sql = "SELECT id FROM subdomain_hosts WHERE host = '$host'";
				$row = $db->query_first($sql);

				if (!empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Domain/Host you specified already exist.'
						);
				} else {

					$primary_id = $db->insert("subdomain_hosts", $data['form_data']);
					if ($primary_id > 0) {
						$data['show_form'] = FALSE;
						$response[] = array(
							'type' => 'success',
							'text' => 'A New Allowed Subdomain Domain/Host is added successfully.'
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => 'Database Error. Please Try again or Contact Support if this error repeats.'
							);
					}

				}

			} else {

				$data['form_data']['host'] = trim($_POST['host']);
				$response[] = array(
					'type' => 'error',
					'text' => 'Invalid Domain/Host.'
					);

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Allowed Subdomain Hosts';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {
			
				$sql = "SELECT * FROM subdomain_hosts WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				$check_insights_sql = "SELECT COUNT(id) AS total FROM insights_base WHERE domain LIKE '%.$each_domain'";
				$check_insights_row = $db->query_first($check_insights_sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Domain/Host Having <b>ID: $dataIDArray</b> does not exist in the list."
						);
				} elseif ($check_insights_row['total'] > 0) {
					$response[] = array(
						'type' => 'error',
						'text' => "Subdomains exist for <b>$host</b> Domain/Host."
						);
				} else {

					$host = $row['host'];

					$db->query("DELETE FROM subdomain_hosts WHERE id='$dataIDArray'");

					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "Domain/Host: <b>$host</b> successfully deleted from the list."
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete Domain/Host Having <b>ID: $dataIDArray</b> from the list."
							);
					}

				}
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Allowed Subdomain Hosts';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'subdomain_hosts';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/subdomain_hosts.tpl');
?>