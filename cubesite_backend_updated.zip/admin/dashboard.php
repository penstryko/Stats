<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL');
	getConfiguration($smarty, $placeholders);

/* Get General Statistics
-------------------------------------------------- */
	$sql = "SELECT COUNT(id) AS total FROM insights_base";
	$row = $db->query_first($sql);
	$data['general_statistics']['domains'] = array(
		'total' => number_format($row['total']),
		'link' => 'added_data.php?action=domains&status=0'
		);

	$sql = "SELECT COUNT(id) AS total FROM tags";
	$row = $db->query_first($sql);
	$data['general_statistics']['keyword'] = array(
		'total' => number_format($row['total']),
		'link' => 'added_data.php?action=keywords&status=0'
		);

	$sql = "SELECT COUNT(id) AS total FROM queue_domains";
	$row = $db->query_first($sql);
	$data['general_statistics']['queued'] = array(
		'total' => number_format($row['total']),
		'link' => 'queuing.php?action=manage'
		);

/* Get Chart Statistics
-------------------------------------------------- */
	$days = 10;
	$limit_date = date('Y-m-d', strtotime("-$days day"));

	for ($i = $days-1; $i >= 0; $i--) {
	    $date = date('Y-m-d', strtotime("-$i day"));
	    $data['chart_data'][$date] = array(
	    	'added_domains' => 0,
	    	'updated_domains' => 0
	    	);
	}

	$sql = "SELECT
				COUNT(id) AS total, added_date
			FROM
				insights_base
			WHERE
				added_date > '$limit_date'
			GROUP BY
				added_date
			ORDER BY
				added_date ASC";

	$rows = $db->fetch_array($sql);
	foreach ($rows as $record) {
		$data['chart_data'][$record['added_date']]['added_domains'] = $record['total'];
	}
	
	$sql = "SELECT
				COUNT(id) AS total, updated_date
			FROM
				insights_base
			WHERE
				added_date != updated_date && updated_date > '$limit_date'
			GROUP BY
				updated_date
			ORDER BY
				updated_date ASC";

	$rows = $db->query($sql);
	while ($record = $db->fetch($rows)) {
		$data['chart_data'][$record['updated_date']]['updated_domains'] = $record['total'];
	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'dashboard';
	$data['page_header'] = 'Dashboard';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/dashboard.tpl');
?>