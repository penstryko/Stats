<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$id = (int) trim($_GET['id']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

	$data['valid_banner_location'] 	= array('SIDEBAR', 'SIDEBAR INNER', 'CUSTOM');
	$data['valid_banner_format'] 	= array('IMAGE', 'FLASH', 'HTML');
	$data['valid_banner_status'] 	= array('ACTIVE', 'INACTIVE');
	$data['valid_image_type']	 	= array('jpg', 'jpeg', 'png', 'gif');
	$data['valid_flash_type']	 	= array('swf');
	
/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "manage") {

		$data['page_header'] = 'Manage Banners';

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$location = trim($_GET['location']);
			if (in_array($location, $data['valid_banner_location'])) {
				$where_array[] = "location = '$location'";
			}

			$format = trim($_GET['format']);
			if (in_array($format, $data['valid_banner_format'])) {
				$where_array[] = "format = '$format'";
			}

			$status = trim($_GET['status']);
			if (in_array($status, $data['valid_banner_status'])) {
				$where_array[] = "status = '$status'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM banners" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "banner.php?action=$action&location=$location&format=$format&status=$status&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, title, location, short_code, format, banner_order, status FROM banners" . $where_clause . " ORDER BY location DESC, banner_order ASC, short_code ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add a New Banner';

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {

			$data['form_data']['title'] = $title = htmlentities(trim(stripslashes($_POST['title'])), ENT_QUOTES, 'UTF-8');
			$data['form_data']['location'] = $location = trim($_POST['location']);

			if (!empty($_POST['short_code'])) {
				$data['form_data']['short_code'] = $short_code = trim(stripslashes($_POST['short_code']));
			}
			
			$data['form_data']['banner_order'] = $banner_order = (int) trim($_POST['banner_order']);
			$data['form_data']['format'] = $format = trim($_POST['format']);
			$data['form_data']['width'] = $width = (int) trim($_POST['width']);
			$data['form_data']['height'] = $height = (int) trim($_POST['height']);
			$data['form_data']['link'] = $link = trim($_POST['link']);
			$data['form_data']['html_code'] = $html_code = htmlentities(trim(stripslashes($_POST['html_code'])), ENT_QUOTES, 'UTF-8');
			$data['form_data']['alternative_html_code'] = $alternative_html_code = htmlentities(trim(stripslashes($_POST['alternative_html_code'])), ENT_QUOTES, 'UTF-8');
			$data['form_data']['status'] = $status = trim($_POST['status']);

			$file_extension = getExtension($_FILES['banner_image']['name']);

			$sql = "SELECT id FROM banners WHERE short_code = '$short_code'";
			$row = $db->query_first($sql);

			if (empty($title)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please enter Descriptive Banner Title.'
					);
			} elseif (!in_array($location, $data['valid_banner_location'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Banner Location.'
					);
			} elseif ($location == "CUSTOM" && empty($short_code)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Enter Short Code that is used on your template to display this banner.'
					);
			} elseif (!empty($row['id']) && !empty($short_code)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Short Code you specified is already in use. Please enter unique Short Code.'
					);
			} elseif (!in_array($format, $data['valid_banner_format'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Banner Format.'
					);
			} elseif (in_array($format, array('IMAGE', 'FLASH')) && empty($_FILES['banner_image']['name'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Banner Image.'
					);
			} elseif ($format == "IMAGE" && !in_array($file_extension, $data['valid_image_type'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select valid Image File. Only ' . implode(', ', $data['valid_image_type']) . ' files were accepted.'
					);
			} elseif ($format == "FLASH" && !in_array($file_extension, $data['valid_flash_type'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select valid Image File. Only ' . implode(', ', $data['valid_flash_type']) . ' files were accepted.'
					);
			} elseif ($format == "HTML" && empty($html_code)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Enter HTML Code for your Banner.'
					);
			} elseif (!in_array($status, $data['valid_banner_status'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Banner Status.'
					);
			} else {

				if (!empty($_FILES['banner_image']['name'])) {
					$temp_file_title = generatePassword(5, TRUE);
					$temp_filename = $temp_file_title.'.'.$file_extension;
					$upload_img = move_uploaded_file($_FILES['banner_image']['tmp_name'], "../templates/userfiles/banners/$temp_filename");
					if ($upload_img == true) {										
						$data['form_data']['image'] = $temp_filename;
						$add_db_record = TRUE;
					} else {
						$add_db_record = FALSE;
						$response[] = array(
							'type' => 'error',
							'text' => 'Error Uploading Banner Image. Please Try Again.'
							);
					}
				} else {
					$add_db_record = TRUE;
				}

				if ($add_db_record) {
					$primary_id = $db->insert("banners", $data['form_data']);
					if ($primary_id > 0) {
						$data['show_form'] = FALSE;
						$response[] = array(
							'type' => 'success',
							'text' => 'A New Banner is added successfully.'
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => 'Database Error. Please Try again or Contact Support if this error repeats.'
							);
						@unlink("../templates/userfiles/banners/$temp_filename");
					}
				}

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "modify") {

		$data['page_header'] = 'Modify Banner';

		$sql = "SELECT * FROM banners WHERE id = '$id'";
		$row = $db->query_first($sql);

		if (empty($row['id'])) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Selected Banner ID does not exist.'
				);
		} else {

			$data['show_form'] = TRUE;

			if ($_POST['cmd'] == "process_form") {

				$data['form_data']['title'] = $title = htmlentities(trim(stripslashes($_POST['title'])), ENT_QUOTES, 'UTF-8');
				$data['form_data']['location'] = $location = trim($_POST['location']);

				if (!empty($_POST['short_code'])) {
					$data['form_data']['short_code'] = $short_code = trim(stripslashes($_POST['short_code']));
				}
				
				$data['form_data']['banner_order'] = $banner_order = (int) trim($_POST['banner_order']);
				$data['form_data']['format'] = $format = trim($_POST['format']);
				$data['form_data']['width'] = $width = (int) trim($_POST['width']);
				$data['form_data']['height'] = $height = (int) trim($_POST['height']);
				$data['form_data']['image'] = $image = trim($_POST['old_image']);
				$data['form_data']['link'] = $link = trim($_POST['link']);
				
				$data['form_data']['html_code'] = $html_code = htmlentities(trim(stripslashes($_POST['html_code'])), ENT_QUOTES, 'UTF-8');
				$data['form_data']['alternative_html_code'] = $alternative_html_code = htmlentities(trim(stripslashes($_POST['alternative_html_code'])), ENT_QUOTES, 'UTF-8');
				$data['form_data']['status'] = $status = trim($_POST['status']);

				$file_extension = getExtension($_FILES['banner_image']['name']);

				$sql = "SELECT id FROM banners WHERE short_code = '$short_code' && id != '$id'";
				$row = $db->query_first($sql);

				if (empty($title)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please enter Descriptive Banner Title.'
						);
				} elseif (!in_array($location, $data['valid_banner_location'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select Banner Location.'
						);
				} elseif ($location == "CUSTOM" && empty($short_code)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Enter Short Code that is used on your template to display this banner.'
						);
				} elseif (!empty($row['id']) && !empty($short_code)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Short Code you specified is already in use. Please enter unique Short Code.'
						);
				} elseif (!in_array($format, $data['valid_banner_format'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select Banner Format.'
						);
				} elseif (in_array($format, array('IMAGE', 'FLASH')) && empty($_FILES['banner_image']['name']) && empty($image)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select Banner Image.'
						);
				} elseif ($format == "IMAGE" && !empty($_FILES['banner_image']['name']) && !in_array($file_extension, $data['valid_image_type'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select valid Image File. Only ' . implode(', ', $data['valid_image_type']) . ' files were accepted.'
						);
				} elseif ($format == "FLASH" && !empty($_FILES['banner_image']['name']) && !in_array($file_extension, $data['valid_flash_type'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select valid Image File. Only ' . implode(', ', $data['valid_flash_type']) . ' files were accepted.'
						);
				} elseif ($format == "HTML" && empty($html_code)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Enter HTML Code for your Banner.'
						);
				} elseif (!in_array($status, $data['valid_banner_status'])) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select Banner Status.'
						);
				} else {
					
					if (!empty($_FILES['banner_image']['name'])) {
						$temp_file_title = generatePassword(5, TRUE);
						$temp_filename = $temp_file_title.'.'.$file_extension;
						$upload_img = move_uploaded_file($_FILES['banner_image']['tmp_name'], "../templates/userfiles/banners/$temp_filename");
						if ($upload_img == true) {										
							$data['form_data']['image'] = $temp_filename;
							$update_db_record = TRUE;
							$delete_old_img = TRUE;
						} else {
							$update_db_record = FALSE;
							$response[] = array(
								'type' => 'error',
								'text' => 'Error Uploading Banner Image. Please Try Again.'
								);
						}
					} else {
						$update_db_record = TRUE;
					}

					if ($format == "HTML" && !empty($image)) {
						$delete_old_img = TRUE;
						$data['form_data']['image'] = NULL;
					}

					if ($update_db_record) {

						$db->update("banners", $data['form_data'], "id='$id'");
						if ($db->affected_rows > 0) {
							$data['show_form'] = FALSE;
							$response[] = array(
								'type' => 'success',
								'text' => 'Banner successfully Updated.'
								);
							if ($delete_old_img) {
								@unlink("../templates/userfiles/banners/$image");
							}
						} else {
							$response[] = array(
								'type' => 'error',
								'text' => 'Error updating Banner. Please Try Again and Make sure there is some changes.'
								);
							@unlink("../templates/userfiles/banners/$temp_filename");
						}

					}

				}

			} else {

				$data['form_data']['title'] = $row['title'];
				$data['form_data']['location'] = $row['location'];
				$data['form_data']['short_code'] = $row['short_code'];
				$data['form_data']['banner_order'] = $row['banner_order'];
				$data['form_data']['format'] = $row['format'];
				$data['form_data']['width'] = $row['width'];
				$data['form_data']['height'] = $row['height'];
				$data['form_data']['image'] = $row['image'];
				$data['form_data']['link'] = $row['link'];
				$data['form_data']['html_code'] = $row['html_code'];
				$data['form_data']['alternative_html_code'] = $row['alternative_html_code'];
				$data['form_data']['status'] = $row['status'];

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Banners';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {

				$sql = "SELECT id, image FROM banners WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Banner Having <b>ID: $dataIDArray</b> does not Exist."
						);
				} else {

					$banner_image = $row['image'];

					$db->query("DELETE FROM banners WHERE id='$dataIDArray'");

					if ($db->affected_rows > 0) {
						$response[] = array(
							'type' => 'success',
							'text' => "Banner Having <b>ID: $dataIDArray</b> successfully deleted."
							);
						if ($banner_image != "") {
							@unlink("../templates/userfiles/banners/$banner_image");
						}
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete Banner Having <b>ID: $dataIDArray</b>."
							);
					}

				}

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Banner Management';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'banner_management';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/banner.tpl');
?>