<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$id = (int) trim($_GET['id']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();


	$data['valid_page_type'] = array('MAIN MENU', 'FOOTER PAGES', 'EXTRA PAGES');

	$sql = "SELECT id, title FROM pages WHERE type = 'MAIN MENU' && parent_id = '0' ORDER BY page_order ASC";
	$rows = $db->fetch_array($sql);
	foreach ($rows as $record) {
		$data['top_menu'][$record['id']] = $record['title'];
	}

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "manage") {

		$data['page_header'] = 'Manage Pages';

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$type = trim($_GET['type']);
			if(in_array($type, $data['valid_page_type'])){
				$where_array[] = "type = '$type'";
			}

			$parent_id = (int) trim($_GET['parent_id']);
			if(count($data['top_menu']) > 0 && array_key_exists($parent_id, $data['top_menu'])){
				$where_array[] = "parent_id = '$parent_id'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM pages" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "page.php?action=$action&type=$type&parent_id=$parent_id&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, title, sef_title, type, parent_id, page_order FROM pages" . $where_clause . " ORDER BY parent_id ASC, page_order ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add a New Page';

		$data['show_form'] = TRUE;
		$data['ckeditor'] = TRUE;
		$data['ckeditor_type'] = 'normal';

		if ($_POST['cmd'] == "process_form") {

			$data['form_data']['type'] = $type = trim($_POST['type']);
			$data['form_data']['page_order'] = $page_order = (int) trim($_POST['page_order']);
			$data['form_data']['parent_id'] = $parent_id = (int) trim($_POST['parent_id']);
			$data['form_data']['title'] = $title = htmlentities(trim(stripslashes($_POST['title'])), ENT_QUOTES, 'UTF-8');
			$data['form_data']['sef_title'] = $sef_title = trim($_POST['sef_title']);
			$data['form_data']['redirect_link'] = $redirect_link = trim($_POST['redirect_link']);
			$data['form_data']['details'] = $details = trim(stripslashes($_POST['details']));

			$sql = "SELECT id FROM pages WHERE sef_title = '$sef_title'";
			$row = $db->query_first($sql);

			if(!in_array($type, $data['valid_page_type'])){
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Page Type.'
					);
			} elseif ($type != "MAIN MENU" && $parent_id > 0) {
				$response[] = array(
					'type' => 'error',
					'text' => 'You can not specify Parent Menu to other Page Types except MAIN MENU.'
					);
			} elseif (empty($title)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please enter Page Title.'
					);
			} elseif (empty($sef_title)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please enter unique SEF Title or populate SEF Title.'
					);
			} elseif (!empty($row['id']) || $sef_title == "404") {
				$response[] = array(
					'type' => 'error',
					'text' => 'SEF Title you specified is already in use. Please enter unique SEF Title.'
					);
			} elseif (empty($redirect_link) && empty($details)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Select Content Type and Either Page Link or Page Details is required.'
					);
			} else {

				$primary_id = $db->insert("pages", $data['form_data']);
				if ($primary_id > 0) {
					$data['show_form'] = FALSE;
					$response[] = array(
						'type' => 'success',
						'text' => 'A New Page is created successfully.'
						);
				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'Database Error. Please Try again or Contact Support if this error repeats.'
						);
				}

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "modify") {

		$data['page_header'] = 'Modify Page';

		$sql = "SELECT * FROM pages WHERE id = '$id'";
		$row = $db->query_first($sql);

		if (empty($row['id'])) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Selected Page ID does not exist.'
				);
		} else {

			$data['show_form'] = TRUE;
			$data['ckeditor'] = TRUE;
			$data['ckeditor_type'] = 'normal';

			if ($_POST['cmd'] == "process_form") {

				$data['form_data']['type'] = $type = trim($_POST['type']);
				$data['form_data']['page_order'] = $page_order = (int) trim($_POST['page_order']);
				$data['form_data']['parent_id'] = $parent_id = (int) trim($_POST['parent_id']);
				$data['form_data']['title'] = $title = htmlentities(trim($_POST['title']), ENT_QUOTES, 'UTF-8');
				$data['form_data']['sef_title'] = $sef_title = trim($_POST['sef_title']);
				$data['form_data']['redirect_link'] = $redirect_link = trim($_POST['redirect_link']);
				$data['form_data']['details'] = $details = trim(stripslashes($_POST['details']));

				$sql = "SELECT id FROM pages WHERE sef_title = '" . $db->escape($sef_title) . "' && id != '$id'";
				$row = $db->query_first($sql);

				if(!in_array($type, $data['valid_page_type'])){
					$response[] = array(
						'type' => 'error',
						'text' => 'Please select Page Type.'
						);
				} elseif ($type != "MAIN MENU" && $parent_id > 0) {
					$response[] = array(
						'type' => 'error',
						'text' => 'You can not specify Parent Menu to other Page Types except MAIN MENU.'
						);
				} elseif (empty($title)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please enter Page Title.'
						);
				} elseif (empty($sef_title)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Please enter unique SEF Title or populate SEF Title.'
						);
				} elseif (!empty($row['id']) || $sef_title == "404") {
					$response[] = array(
						'type' => 'error',
						'text' => 'SEF Title you specified is already in use. Please enter unique SEF Title.'
						);
				} elseif (empty($redirect_link) && empty($details)) {
					$response[] = array(
						'type' => 'error',
						'text' => 'Either Page Link or Page Details is required.'
						);
				} else {

					$db->update("pages", $data['form_data'], "id='$id'");
					if($db->affected_rows > 0){
						$data['show_form'] = FALSE;
						$response[] = array(
							'type' => 'success',
							'text' => 'Page details is successfully Updated.'
							);
						$smarty->clearCache(NULL, 'page|' . $sef_title);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => 'There is nothing new on your provided page details for change.'
							);
					}

				}

			} else {

				$data['form_data']['type'] = $row['type'];
				$data['form_data']['page_order'] = $row['page_order'];
				$data['form_data']['parent_id'] = $row['parent_id'];
				$data['form_data']['title'] = $row['title'];
				$data['form_data']['sef_title'] = $row['sef_title'];
				$data['form_data']['redirect_link'] = $row['redirect_link'];
				$data['form_data']['details'] = $row['details'];

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Pages';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {
			
				$sql = "SELECT id, sef_title FROM pages WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				$sub_sql = "SELECT id FROM pages WHERE parent_id = '$dataIDArray'";
				$sub_row = $db->query_first($sub_sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Page Having <b>ID: $dataIDArray</b> does not Exist."
						);
				} elseif (!empty($sub_row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Unable to delete Page Having <b>ID: $dataIDArray</b>.<br />Sub Pages exist under that Page."
						);
				} else {

					$sef_title = $row['sef_title'];

					$db->query("DELETE FROM pages WHERE id='$dataIDArray'");

					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "Page Having <b>ID: $dataIDArray</b> successfully deleted."
							);
						$smarty->clearCache(NULL, 'page|' . $sef_title);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete Page Having <b>ID: $dataIDArray</b>."
							);
					}

				}
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Page Management';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'page_management';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/page.tpl');
?>