<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$id = (int) trim($_GET['id']);
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

	$sql = "SELECT DISTINCT grp FROM config";
	$rows = $db->fetch_array($sql);
	foreach ($rows as $record) {
		$data['config_group'][] = $record['grp'];
	}

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "modify") {

		$data['page_header'] = 'Modify Website Configurations';

		$sql = "SELECT * FROM config WHERE id = '$id'";
		$row = $db->query_first($sql);

		if (empty($row['id'])) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Supplied Configuration ID does not exist.'
				);
		} else {
			
			$data['show_form'] = TRUE;

			if ($_POST['cmd'] == "process_form") {

				$update['value'] = htmlentities(trim(stripslashes($_POST['config_value'])), ENT_QUOTES, 'UTF-8');
				$db->update("config", $update, "id='" . $id . "'");

				if($db->affected_rows > 0){
					$response[] = array(
						'type' => 'success',
						'text' => 'Configuration Value of <strong>' . $row['placeholder'] . '</strong> is successfully updated.'
						);
					$data['show_form'] = FALSE;
				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'There is nothing new on your provided details for change.'
						);
				}

				if ($row['placeholder'] == "SCRIPT_LICENSE_KEY")
				{
					file_put_contents($root_dir . '/admin/integrity.txt', '');
				}

			}

			$data['db_data']['id'] = $row['id'];
			$data['db_data']['placeholder'] = $row['placeholder'];
			$data['db_data']['details'] = $row['details'];
			$data['db_data']['type'] = $row['type'];
			$data['db_data']['value'] = $row['value'];
			$data['db_data']['options'] = explode(',', $row['options']);
			
		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Website Configurations';

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$group = $db->escape(stripslashes($_GET['group']));
			if(in_array($group, $data['config_group'])){
				$where_array[] = "grp = '$group'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM config" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}
		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "configurations.php?action=$action&group=$group&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, placeholder, type, details, value FROM config" . $where_clause . " LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'configurations';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/configurations.tpl');
?>