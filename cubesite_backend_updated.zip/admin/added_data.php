<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$sub = trim($_GET['sub']);
	$id = (int) trim($_GET['id']);
	$page = trim($_GET['page']);
	$status = trim($_GET['status']);
	$data_id = $_POST['dataID'];
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS', 'PREFIX_TAG');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "domains") {

		$data['page_header'] = 'Added Domains Management';
		$data['valid_status'] = array(
			'0' => 'PENDING',
			'1' => 'ACTIVE',
			'2' => 'UNSAFE',
			'3' => 'DISABLED'
		);

		/* Process Status Change
		-------------------------------------------------- */
			$new_status = trim($_GET['new_status']);
			if ($sub == "modify" && is_array($data_id) && in_array($new_status, $data['valid_status'])) {

				$domain_id = "'" . implode("', '", $data_id) . "'";
				
				$update['status'] = array_search($new_status, $data['valid_status']);
				$db->update("insights_base", $update, "id IN ($domain_id)");

				if ($db->affected_rows > 0) {
					
					$response[] = array(
						'type' => 'success',
						'text' => 'Status for selected domains successfully changed.'
						);

					$sql = "SELECT domain FROM insights_base WHERE id IN ($domain_id)";
					$rows = $db->fetch_array($sql);
					foreach ($rows as $record) {
						$smarty->clearCache(NULL, 'stats|' . $record['domain']);
						$smarty->clearCache(NULL, 'widget|' . $record['domain']);
					}

				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'There is nothing new on your provided details for change.'
						);
				}

				$data['response_data'] = array('method' => 'static', 'response' => $response);

			}

		/* Process Delete
		-------------------------------------------------- */
			if ($sub == "delete" && is_array($data_id)) {

				$domain_id = "'" . implode("', '", $data_id) . "'";
				
				$db->query("DELETE FROM insights_meta WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_tags WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_full_whois WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_header WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_dns WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_nameservers WHERE domain_id IN ($domain_id)");
				$db->query("DELETE FROM insights_base WHERE id IN ($domain_id)");

				// Affected rows of last query
				if($db->affected_rows > 0){
					
					$response[] = array(
						'type' => 'success',
						'text' => "Selected domains successfully deleted."
						);

					$sql = "SELECT domain FROM insights_base WHERE id IN ($domain_id)";
					$rows = $db->fetch_array($sql);
					foreach ($rows as $record) {
						$smarty->clearCache(NULL, 'stats|' . $record['domain']);
						$smarty->clearCache(NULL, 'widget|' . $record['domain']);
					}

				} else {
					$response[] = array(
						'type' => 'error',
						'text' => "Unable to delete selected domains."
						);
				}

				$data['response_data'] = array('method' => 'static', 'response' => $response);

			}

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			if(array_key_exists($status, $data['valid_status'])){
				$where_array[] = "status = '$status'";
			}

			$part = $db->escape(stripslashes(trim($_GET['part'])));
			if(!empty($part)){
				$where_array[] = "domain LIKE '$part%'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		/* Listings
		-------------------------------------------------- */
			$sql = "SELECT COUNT(id) AS total_items FROM insights_base" . $where_clause;
			$row = $db->query_first($sql);
			$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

			if ($page > 1 && $page > $total_pages) {
				$page = $total_pages;
			}

			$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
			$paginate = array(
				'page_current' => $page,
				'url' => "added_data.php?action=$action&part=$part&status=$status&",
				'page_total' => $total_pages
				);
			$data['pagination'] = TRUE;
			$data['pagination_data'] = $paginate;

			$sql = "SELECT 
						IB.id AS id, domain, status, added_datetime,
						IM.page_title AS page_title,
						IM.meta_description AS meta_description
					FROM
						insights_base IB 
					LEFT JOIN
						insights_meta IM ON IB.id = IM.domain_id 
					" . $where_clause . " ORDER BY added_datetime ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];

			$rows = $db->fetch_array($sql);
			foreach ($rows as $record) {

				$data['listing_data'][] = array(
					'id' => $record['id'],
					'domain' => $record['domain'],
					'status' => $record['status'],
					'added_datetime' => $record['added_datetime'],
					'title' => html_entity_decode($record['page_title'], ENT_QUOTES, 'UTF-8'),
					'description' => html_entity_decode($record['meta_description'], ENT_QUOTES, 'UTF-8')
				);

			}

			$data['listing_show'] = TRUE;

	} elseif ($action == "keywords") {

		$data['page_header'] = 'Added Keywords Management';
		$data['valid_status'] = array(
			'0' => 'PENDING',
			'1' => 'ACTIVE',
			'2' => 'UNSAFE'
		);

		/* Process Status Change
		-------------------------------------------------- */
			$new_status = trim($_GET['new_status']);
			if ($sub == "modify" && is_array($data_id) && in_array($new_status, $data['valid_status'])) {

				$tag_id = "'" . implode("', '", $data_id) . "'";
				
				$update['status'] = array_search($new_status, $data['valid_status']);
				$db->update("tags", $update, "id IN ($tag_id)");

				if($db->affected_rows > 0){
					
					$response[] = array(
						'type' => 'success',
						'text' => 'Status for selected keywords successfully changed.'
						);

					$sql = "SELECT tag FROM tags WHERE id IN ($tag_id)";
					$rows = $db->fetch_array($sql);
					foreach ($rows as $record) {
						$smarty->clearCache(NULL, $config['PREFIX_TAG'] . '|' . md5($record['tag']));
					}

				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'There is nothing new on your provided details for change.'
						);
				}

				$data['response_data'] = array('method' => 'static', 'response' => $response);

			}

		/* Process Delete
		-------------------------------------------------- */
			if ($sub == "delete" && is_array($data_id)) {

				$tag_id = "'" . implode("', '", $data_id) . "'";

				$sql = "SELECT tag FROM tags WHERE id IN ($tag_id)";
				$rows = $db->fetch_array($sql);
				foreach ($rows as $record) {
					$smarty->clearCache(NULL, $config['PREFIX_TAG'] . '|' . md5($record['tag']));
				}
				
				$db->query("DELETE FROM insights_tags WHERE tag_id IN ($tag_id)");
				$db->query("DELETE FROM tags WHERE id IN ($tag_id)");

				// Affected rows of last query
				if($db->affected_rows > 0){					
					$response[] = array(
						'type' => 'success',
						'text' => "Selected tags successfully deleted."
						);
				} else {
					$response[] = array(
						'type' => 'error',
						'text' => "Unable to delete selected tags."
						);
				}

				$data['response_data'] = array('method' => 'static', 'response' => $response);

			}

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			if(array_key_exists($status, $data['valid_status'])){
				$where_array[] = "status = '$status'";
			}

			$part = $db->escape(stripslashes($_GET['part']));
			if(!empty($part)){
				$where_array[] = "tag LIKE '$part%'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		/* Listings
		-------------------------------------------------- */
			$sql = "SELECT COUNT(id) AS total_items FROM tags" . $where_clause;
			$row = $db->query_first($sql);
			$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

			if ($page > 1 && $page > $total_pages) {
				$page = $total_pages;
			}

			$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
			$paginate = array(
				'page_current' => $page,
				'url' => "added_data.php?action=$action&part=$part&status=$status&",
				'page_total' => $total_pages
				);
			$data['pagination'] = TRUE;
			$data['pagination_data'] = $paginate;

			$sql = "SELECT id, tag, status FROM tags" . $where_clause . " ORDER BY id ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
			$rows = $db->fetch_array($sql);
			$data['listing_show'] = TRUE;
			$data['listing_data'] = $rows;

	} else {

		$data['page_header'] = 'Added Data Management';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'added_data';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/added_data.tpl');
?>