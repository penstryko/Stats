<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

	$data['valid_file_type'] = array('txt', 'csv');

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	$load_tld = ($action == "add" && $_POST['cmd'] == "process_form") ? true : false ;
	getConfiguration($smarty, $placeholders, $load_tld);

/* Process Actions
-------------------------------------------------- */
	if ($action == "manage") {

		$data['page_header'] = 'Manage Queued Domains';

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$part = $db->escape(stripslashes(trim($_GET['part'])));
			if(!empty($part)){
				$where_array[] = "domain LIKE '$part%'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM queue_domains" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "queuing.php?action=$action&part=$part&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, domain FROM queue_domains" . $where_clause . " ORDER BY id ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add Domains to the Queue';

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {

			$domain_text = trim($_POST['domain_text']);

			if(empty($_FILES['domain_csv']['name']) && empty($domain_text)){
				$response[] = array(
					'type' => 'error',
					'text' => 'Either upload a plain text data file having Domain Names or Enter Domain Names in Textarea field.'
					);
			} else {

				// ini_set('max_execution_time', 300);
				set_time_limit(300);
				
				$data['show_form'] = FALSE;

				/* Adding Domain Names from CSV File
				-------------------------------------------------- */
					if (!empty($_FILES['domain_csv']['name'])) {

						$file_extension = getExtension($_FILES['domain_csv']['name']);
						if(!empty($_FILES['domain_csv']['name']) && !in_array($file_extension, $data['valid_file_type'])){
							$response[] = array(
								'type' => 'error',
								'text' => 'Please select valid File Type. Only ' . implode(', ', $data['valid_file_type']) . ' files were accepted.'
								);
						} else {

							$temp_file_title = generatePassword(5, TRUE);
							$temp_filename = $temp_file_title.'.'.$file_extension;
							$temp_path =  "../cs_tmp/uploads/";
							$upload_file = move_uploaded_file($_FILES['domain_csv']['tmp_name'], $temp_path . $temp_filename);

							if ($upload_file == FALSE) {
								$response[] = array(
									'type' => 'error',
									'text' => 'Unable to upload selected file. Please Try Again.'
									);
							} else {

								$fh = fopen($temp_path . $temp_filename, "r");
								if ($fh == false) {
									$response[] = array(
										'type' => 'error',
										'text' => 'Unable to read uploaded file. Please Try Again.'
										);
									@unlink($temp_path . $temp_filename);
								} else {
									
									$domain_count = 0;
									$total_added = 0;
									while(!feof($fh)) {

										$domain_count++;
										$each_domain = fgets($fh);
										$each_domain = getDomain($each_domain);

										if ($each_domain) {

											if (!empty($each_domain['sub_domain'])) {
												$each_domain = $each_domain['sub_domain'] . '.' . $each_domain['label'] . '.' . $each_domain['extension'];
											} else {
												$each_domain = $each_domain['label'] . '.' . $each_domain['extension'];
											}

											$check_queue_sql = "SELECT id FROM queue_domains WHERE domain = '$each_domain'";
											$check_queue_row = $db->query_first($check_queue_sql);

											$check_insights_sql = "SELECT id FROM insights_base WHERE domain = '$each_domain'";
											$check_insights_row = $db->query_first($check_insights_sql);

											if (empty($check_queue_row['id']) && empty($check_insights_row['id'])) {
												$new_data['domain'] = $each_domain;
												$primary_id = $db->insert("queue_domains", $new_data);
												if ($primary_id > 0) {
													$total_added++;
												}
											}
										}

									}
									fclose($fh);
									@unlink($temp_path . $temp_filename);

									$response[] = array(
										'type' => 'success',
										'text' => "<b>$total_added</b> out of <b>$domain_count</b> Domain Names from uploaded file successfully added to the Queue."
										);

								}

							}

						}

					}

				/* Adding Domain Names from Textarea
				-------------------------------------------------- */
					$domain_array = explode("\n", $domain_text);

					if (!empty($domain_text)) {

						$domain_count = 0;
						$total_added = 0;
						
						foreach ($domain_array as $each_domain) {

							$domain_count++;
							$each_domain = getDomain($each_domain);

							if ($each_domain) {

								if (!empty($each_domain['sub_domain'])) {
									$each_domain = $each_domain['sub_domain'] . '.' . $each_domain['label'] . '.' . $each_domain['extension'];
								} else {
									$each_domain = $each_domain['label'] . '.' . $each_domain['extension'];
								}

								$check_queue_sql = "SELECT id FROM queue_domains WHERE domain = '$each_domain'";
								$check_queue_row = $db->query_first($check_queue_sql);

								$check_insights_sql = "SELECT id FROM insights_base WHERE domain = '$each_domain'";
								$check_insights_row = $db->query_first($check_insights_sql);

								if (empty($check_queue_row['id']) && empty($check_insights_row['id'])) {
									$new_data['domain'] = $each_domain;
									$primary_id = $db->insert("queue_domains", $new_data);
									if ($primary_id > 0) {
										$total_added++;
									}
								}
							}

						}

						$response[] = array(
							'type' => 'success',
							'text' => "<b>$total_added</b> out of <b>$domain_count</b> Domain Names from Textarea successfully added to the Queue."
							);

					}

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Queued Domains';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {
			
				$sql = "SELECT * FROM queue_domains WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Domain Having <b>ID: $dataIDArray</b> does not exist in the Queue."
						);
				} else {

					$domain = $row['domain'];

					$db->query("DELETE FROM queue_domains WHERE id='$dataIDArray'");

					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "Domain Name: <b>$domain</b> successfully deleted from the Queue."
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete Domain Having <b>ID: $dataIDArray</b> from the Queue."
							);
					}

				}
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "compact") {

		$data['page_header'] = 'Compact Queued Domains';

		$sql = "DELETE QD FROM queue_domains QD INNER JOIN insights_base IB ON IB.domain = QD.domain";
		$db->query($sql);

		if($db->affected_rows > 0){
			$response[] = array(
				'type' => 'success',
				'text' => $db->affected_rows . " domains for which the stats already exist has been removed from the Queue."
				);
		} else {
			$response[] = array(
				'type' => 'error',
				'text' => "At the moment, there are not any Domains to filter."
				);
		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Domain Queuing';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'domain_queuing';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/queuing.tpl');
?>