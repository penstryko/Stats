<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

	$data['valid_file_type'] = array('txt', 'csv');
	$data['valid_type']	= array('DOMAINS', 'KEYWORDS');

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	$load_tld = ($action == "add" && $_POST['cmd'] == "process_form") ? true : false ;
	getConfiguration($smarty, $placeholders, $load_tld);

/* Process Actions
-------------------------------------------------- */
	if ($action == "manage") {

		$data['page_header'] = 'Manage Blocked Data';

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$part = $db->escape(stripslashes($_GET['part']));
			if(!empty($part)){
				$where_array[] = "data LIKE '$part%'";
			}

			$type = trim($_GET['type']);
			if(in_array($type, $data['valid_type'])){
				$where_array[] = "type = '$type'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM blockings" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "blockings.php?action=$action&part=$part&type=$type&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, type, data FROM blockings" . $where_clause . " ORDER BY data ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add New Blocked Data';

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {

			$data['form_data']['type'] = $type = trim($_POST['type']);
			$data_text = trim($_POST['data_text']);

			if (!in_array($type, $data['valid_type'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Blocking Type.'
					);
			} elseif (empty($_FILES['data_csv']['name']) && empty($data_text)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Either upload a plain text data file or Enter Data in Textarea field.'
					);
			} else {

				// ini_set('max_execution_time', 300);
				set_time_limit(300);

				$data['show_form'] = FALSE;

				/* Adding Data from CSV File
				-------------------------------------------------- */
					if (!empty($_FILES['data_csv']['name'])) {

						$file_extension = get_extension($_FILES['data_csv']['name']);
						if(!empty($_FILES['data_csv']['name']) && !in_array($file_extension, $data['valid_file_type'])){
							$response[] = array(
								'type' => 'error',
								'text' => 'Please select valid File Type. Only ' . implode(', ', $data['valid_file_type']) . ' files were accepted.'
								);
						} else {

							$temp_file_title = generatePassword(5, TRUE);
							$temp_filename = $temp_file_title.'.'.$file_extension;
							$temp_path =  "../cs_tmp/uploads/";
							$upload_file = move_uploaded_file($_FILES['data_csv']['tmp_name'], $temp_path . $temp_filename);

							if ($upload_file == FALSE) {
								$response[] = array(
									'type' => 'error',
									'text' => 'Unable to upload selected file. Please Try Again.'
									);
							} else {

								$fh = fopen($temp_path . $temp_filename, "r");
								if ($fh == false) {
									$response[] = array(
										'type' => 'error',
										'text' => 'Unable to read uploaded file. Please Try Again.'
										);
									@unlink($temp_path . $temp_filename);
								} else {

									$data_count = 0;
									$total_added = 0;
									while(!feof($fh)) {

										$data_count++;
										$each_data = fgets($fh);

										if ($type == "DOMAINS") {
											$each_data = getDomain($each_data);
										} elseif ($type == "KEYWORDS") {
											$each_data = htmlentities(correctTag($each_data), ENT_QUOTES, 'UTF-8');
										}

										if ($each_data) {

											if ($type == "DOMAINS") {

												if (!empty($each_data['sub_domain'])) {
													$each_data = $each_data['sub_domain'] . '.' . $each_data['label'] . '.' . $each_data['extension'];
												} else {
													$each_data = $each_data['label'] . '.' . $each_data['extension'];
												}

											}

											$sql = "SELECT id FROM blockings WHERE data = '$each_data' && type = '$type'";
											$row = $db->query_first($sql);

											if (empty($row['id'])) {
												$new_data['type'] = $type;
												$new_data['data'] = $each_data;
												$primary_id = $db->insert("blockings", $new_data);
												if ($primary_id > 0) {
													$total_added++;
												}
											}
										}

									}
									fclose($fh);
									@unlink($temp_path . $temp_filename);

									$response[] = array(
										'type' => 'success',
										'text' => "<b>$total_added</b> out of <b>$data_count</b> " . ucfirst($type) . " from Textarea successfully added to the Blocked Lists."
										);


								}

							}

						}

					}

				/* Adding Data from Textarea
				-------------------------------------------------- */
					$data_array = explode("\n", $data_text);

					if (!empty($data_text)) {

						$data_count = 0;
						$total_added = 0;
						
						foreach ($data_array as $each_data) {

							$data_count++;

							if ($type == "DOMAINS") {
								$each_data = getDomain($each_data);
							} elseif ($type == "KEYWORDS") {
								$each_data = htmlentities(correctTag($each_data), ENT_QUOTES, 'UTF-8');
							}

							if ($each_data) {

								if ($type == "DOMAINS") {

									if (!empty($each_data['sub_domain'])) {
										$each_data = $each_data['sub_domain'] . '.' . $each_data['label'] . '.' . $each_data['extension'];
									} else {
										$each_data = $each_data['label'] . '.' . $each_data['extension'];
									}

								}

								$sql = "SELECT id FROM blockings WHERE data = '$each_data' && type = '$type'";
								$row = $db->query_first($sql);

								if (empty($row['id'])) {
									$new_data['type'] = $type;
									$new_data['data'] = $each_data;
									$primary_id = $db->insert("blockings", $new_data);
									if ($primary_id > 0) {
										$total_added++;
									}
								}
							}

						}

						$response[] = array(
							'type' => 'success',
							'text' => "<b>$total_added</b> out of <b>$data_count</b> " . ucfirst($type) . " from Textarea successfully added to the Blocked Lists."
							);

					}
				
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Blocked Data';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {
			
				$sql = "SELECT * FROM blockings WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Data having <b>ID: $dataIDArray</b> does not exist in the Blocked Lists."
						);
				} else {

					$data_type = $row['type'];
					$data_value = $row['data'];

					$db->query("DELETE FROM blockings WHERE id='$dataIDArray'");

					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "Data having <b>ID: $dataIDArray</b> successfully deleted from the Blocked Lists."
							);
						if ($data_type == "DOMAINS") {
							$smarty->clearCache(NULL, 'stats|' . $data_value);
							$smarty->clearCache(NULL, 'widget|' . $data_value);
						}
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete Data having <b>ID: $dataIDArray</b> from the Blocked Lists."
							);
					}

				}
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Blockings';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'blockings';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/blockings.tpl');
?>