<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);
	$sub = trim($_GET['sub']);
	$id = (int) trim($_GET['id']);
	$data_id = $_POST['dataID'];
	$page = trim($_GET['page']);
	
	if ($page < 1) {
		$page = 1;
	}

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

	$data['valid_status'] 	= array('ACTIVE','INACTIVE');

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL', 'ADMIN_PER_PAGE_LISTINGS');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "manage") {

		$data['page_header'] = 'Manage Domain Extensions';

		/* Process Status Change
		-------------------------------------------------- */
			if ($sub == "change_status" && $id > 0) {

				$sql = "SELECT id, extension, status FROM tld WHERE id='$id'";
				$row = $db->query_first($sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Domain Extension Having <b>ID: $id</b> does not Exist."
						);
				} else {

					if ($row['status'] == "ACTIVE") {
						$update['status'] = "INACTIVE";
					} else {
						$update['status'] = "ACTIVE";						
					}

					$db->update("tld", $update, "id='$id'");
					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "Status of <b>.$row[extension]</b> Domain Extension changed to <b>$update[status]</b>"
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Error occured while changing Status of <b>.$row[extension]</b> Domain Extension to <b>$update[status]</b>"
							);
					}

				}

				$data['response_data'] = array('method' => 'static', 'response' => $response);

			}

		/* Build Where Clause
		-------------------------------------------------- */
			$where_array = array();
			$status = trim($_GET['status']);
			if(in_array($status, $data['valid_status'])){
				$where_array[] = "status = '$status'";
			}

			$part = $db->escape(stripslashes(trim($_GET['part'])));
			if(!empty($part)){
				$where_array[] = "extension LIKE '%$part%'";
			}

			if (count($where_array) > 0) {
				$where_clause = ' WHERE ' . implode(' && ', $where_array);
			}

		$sql = "SELECT COUNT(id) AS total_items FROM tld" . $where_clause;
		$row = $db->query_first($sql);
		$total_pages = ceil($row['total_items'] / $config['ADMIN_PER_PAGE_LISTINGS']);

		if ($page > 1 && $page > $total_pages) {
			$page = $total_pages;
		}

		$current_index = $config['ADMIN_PER_PAGE_LISTINGS'] * ($page-1);
		$paginate = array(
			'page_current' => $page,
			'url' => "extension.php?action=$action&part=$part&status=$status&",
			'page_total' => $total_pages
			);
		$data['pagination'] = TRUE;
		$data['pagination_data'] = $paginate;

		$sql = "SELECT id, extension, status FROM tld" . $where_clause . " ORDER BY extension ASC LIMIT " . $current_index . ", " . $config['ADMIN_PER_PAGE_LISTINGS'];
		$rows = $db->fetch_array($sql);
		$data['listing_show'] = TRUE;
		$data['listing_data'] = $rows;

	} elseif ($action == "add") {

		$data['page_header'] = 'Add New Domain Extension';

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {

			$data['form_data']['status'] = $status = trim($_POST['status']);
			$data['form_data']['extension'] = $extension = strtolower(trim($_POST['extension']));

			$sql = "SELECT id FROM tld WHERE extension = '$extension'";
			$row = $db->query_first($sql);

			if(!in_array($status, $data['valid_status'])){
				$response[] = array(
					'type' => 'error',
					'text' => 'Please select Status.'
					);
			} elseif (empty($extension)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please enter Domain Extension.'
					);
			} elseif (!preg_match("/^[a-z0-9]+((\.|-){1}?[a-z0-9]+)*$/", $extension)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Please enter valid Domain Extension.'
					);
			} elseif (!empty($row['id'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Domain Extension you specified is already added.'
					);
			} else {
				
				$primary_id = $db->insert("tld", $data['form_data']);
				if ($primary_id > 0) {
					$data['show_form'] = FALSE;
					$response[] = array(
						'type' => 'success',
						'text' => 'A New Domain Extension is added successfully.'
						);
				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'Database Error. Please Try again or Contact Support if this error repeats.'
						);
				}

			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} elseif ($action == "delete") {

		$data['page_header'] = 'Delete Domain Extension';

		if (empty($data_id)) {
			$response[] = array(
				'type' => 'error',
				'text' => 'Nothing is Posted for Deleting.'
				);
		} else {

			foreach ($data_id as $dataIDArray) {
			
				$sql = "SELECT id, extension FROM tld WHERE id = '$dataIDArray'";
				$row = $db->query_first($sql);

				if (empty($row['id'])) {
					$response[] = array(
						'type' => 'error',
						'text' => "Domain Extension Having <b>ID: $dataIDArray</b> does not Exist."
						);
				} else {

					$extension = $row['extension'];

					$db->query("DELETE FROM tld WHERE id='$dataIDArray'");

					if($db->affected_rows > 0){
						$response[] = array(
							'type' => 'success',
							'text' => "<b>.$extension</b> Domain Extension successfully deleted."
							);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => "Unable to delete <b>.$extension</b> Domain Extension."
							);
					}

				}
			}

		}

		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Domain Extensions Management';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'domain_extensions';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/extension.tpl');
?>