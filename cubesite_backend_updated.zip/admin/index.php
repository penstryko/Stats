<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get User Submitted Data
-------------------------------------------------- */
	$action = $_GET['action'];
	$process = $_POST['process'];

/* Check if an administrator is already Logged in, if so, redirect to Dashboard
-------------------------------------------------- */
	if (!empty($_SESSION['email']) && $_SESSION['logged'] == "yes" && $_SESSION['user_type'] == "ADMINISTRATOR") {
		header ("Location: dashboard.php");
		exit;
	}

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('SITE_ADDRESS', 'CDN_STATUS', 'CDN_URL');
	getConfiguration($smarty, $placeholders);

/* Several Authentication Processes / Actions
-------------------------------------------------- */
	if ($process == "login") {
		
		$email = trim($db->escape(stripslashes($_POST['email'])));
		$password = trim($db->escape(stripslashes($_POST['password'])));

		if (filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($password)){

			$password_hash = md5($password);
			$sql = "SELECT id, email FROM users WHERE email = '$email' && password = '$password_hash' && level = '1' && status ='1'";
			$row = $db->query_first($sql);

			if (!empty($row['id'])) {
				session_regenerate_id(TRUE);
				$_SESSION['user_id'] = $row['id'];
				$_SESSION['email'] = $row['email'];
				$_SESSION['logged'] = "yes";
				$_SESSION['user_type'] = "ADMINISTRATOR";
				$_SESSION['app_base_uri'] = APP_BASE_URI; // Used in filemanager's PHP Connector
				header ("Location: dashboard.php");
				exit;
			} else {
				$response[] = array(
					'type' => 'error',
					'text' => 'Supplied Administrator does not exist.'
					);
			}

		} else {
			$response[] = array(
				'type' => 'error',
				'text' => 'Your E-Mail is invalid or the Password field is blank.'
				);
		}

		$login = array(
			'response_data' => array('method' => 'static', 'response' => $response),
			'form_data' => array('email' => $email)
			);
		$smarty->assign('login', $login);

	} elseif ($process == "forgot") {

		$email = trim($db->escape(stripslashes($_POST['email'])));

		if (filter_var($email, FILTER_VALIDATE_EMAIL)){

			$sql = "SELECT id FROM users WHERE email = '$email' && level = '1' && status ='1'";
			$row = $db->query_first($sql);

			if (!empty($row['id'])) {

				$reset_code = generatePassword();
				$update['reset_hash'] = md5($reset_code);
				$update['reset_expiry'] = date('Y-m-d H:i:s', strtotime("+1 hour"));
				$db->update("users", $update, "email ='$email'");

				if ($db->affected_rows > 0) {

					$host = strtoupper(parse_url($config['SITE_ADDRESS'], PHP_URL_HOST));
					$to = strtolower($email);
					$subject = "Password Retrieval for Admin Panel - $host";
					$mailheaders = "From: System<noreply@" . strtolower($host) . ">";
					$verification_url = $config['SITE_ADDRESS'] . "/admin/index.php?action=verification&email=$to&code=$reset_code";
					$app_details = APP_NAME . ' ' . APP_VERSION;

					$msg = "Hello Administrator,

Below is your verification link to reset your password for the Admin Panel of $host

$verification_url

Please note that this link is only valid for next one hour.

If you have not requested this information, then do not worry.
It means someone has entered your E-Mail address in Forgot Password utility.
But remember, you could always change your password by logging in and clicking on Admin Profile.

Please do not reply to this E-Mail as it is an automatic E-Mail notification and it will not be monitored!

$app_details
Licensed to $host";

					$success = mail($to, $subject, $msg, $mailheaders);
					if ($success) {
						$response[] = array(
							'type' => 'success',
							'text' => 'We have sent you a mail regarding further steps to reset your password.'
							);
						unset($email);
					} else {
						$response[] = array(
							'type' => 'error',
							'text' => 'Error Processing your request. Please Try Again.'
							);
					}

				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'Error occured while generating reset data. Please Try Again.'
						);
				}

			} else {
				$response[] = array(
					'type' => 'error',
					'text' => 'Supplied Administrator does not exist.'
					);								
			}

		} else {
			$response[] = array(
				'type' => 'error',
				'text' => 'Supplied E-Mail is invalid.'
				);
		}

		$forgot = array(
			'response_data' => array('method' => 'static', 'response' => $response),
			'form_data' => array('email' => $email)
			);
		$smarty->assign('forgot', $forgot);

	} elseif ($action == "verification") {
		
		$smarty->assign('show_links', TRUE);

		$email = $db->escape(stripslashes($_GET['email']));
		$reset_hash = md5($_GET['code']);

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$response[] = array(
				'type' => 'error',
				'text' => 'Supplied E-Mail is invalid.'
				);
		} else {

			$current_date = date('Y-m-d H:i:s');
			$sql = "SELECT id FROM users WHERE email = '$email' && level = '1' && status ='1' && reset_hash = '$reset_hash' && reset_expiry > '$current_date'";
			$row = $db->query_first($sql);

			if (!empty($row['id'])) {

				$smarty->assign('show_reset_form', TRUE);

				if ($process == "reset") {

					$new_password = trim($_POST['new_password']);
					$v_new_password = trim($_POST['v_new_password']);

					if (strlen($new_password) > 5 && $new_password === $v_new_password) {
						
						$update['password'] = md5($new_password);
						$update['reset_hash'] = '';
						$update['reset_expiry'] = '';
						$db->update("users", $update, "email ='$email'");

						if ($db->affected_rows > 0) {

							$smarty->assign('show_reset_form', FALSE);

							$response[] = array(
								'type' => 'success',
								'text' => 'Your password is successfully changed.'
								);

						} else {

							$smarty->assign('show_links', FALSE);
							$response[] = array(
								'type' => 'error',
								'text' => 'Error modifying your password. Plese Try Again.'
								);

						}

					} else {
						$smarty->assign('show_links', FALSE);
						$response[] = array(
							'type' => 'error',
							'text' => 'Invalid Password. New Password must have more than 5 characters long and both password must match for typo errors.'
							);						
					}
				} else {
					$smarty->assign('show_links', FALSE);
				}

			} else {
				$response[] = array(
					'type' => 'error',
					'text' => 'Your verification data is invalid or expired.'
					);	
			}

		}

		$verification = array(
			'response_data' => array('method' => 'static', 'response' => $response)
			);
		$smarty->assign('verification', $verification);

	}

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/login.tpl');
?>