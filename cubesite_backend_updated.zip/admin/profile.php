<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL');
	getConfiguration($smarty, $placeholders);

/* Get / Assign / Process Data
-------------------------------------------------- */
	$sql = "SELECT id, full_name, email FROM users WHERE email = '" . $_SESSION['email'] . "' && level = '1' && status ='1'";
	$row = $db->query_first($sql);
	if (!empty($row['id'])) {

		$data['show_form'] = TRUE;

		if ($_POST['cmd'] == "process_form") {

			$full_name = htmlentities(trim(stripslashes($_POST['full_name'])), ENT_QUOTES, 'UTF-8');
			$admin_email = trim($_POST['admin_email']);
			$current_pass = trim($_POST['current_pass']);
			$new_pass = trim($_POST['new_pass']);

			$sql = "SELECT id FROM users WHERE email = '" . $_SESSION['email'] . "' && level = '1' && status ='1' && password = '" . md5($current_pass) . "'";
			$verify_row = $db->query_first($sql);

			if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Supplied E-Mail is not valid.'
					);
			} elseif (empty($verify_row['id'])) {
				$response[] = array(
					'type' => 'error',
					'text' => 'Supplied current password does not match.'
					);
			} elseif (!empty($new_pass) && strlen($new_pass) <= 5) {
				$response[] = array(
					'type' => 'error',
					'text' => 'New Password must be more than 5 characters long.'
					);				
			} else {
				
				$update['full_name'] = $full_name;
				$update['email'] = $admin_email;
				if (!empty($new_pass)) {
					$update['password'] = md5($new_pass);
				}
				$db->update("users", $update, "email='" . $_SESSION['email'] . "'");

				if($db->affected_rows > 0){
					$response[] = array(
						'type' => 'success',
						'text' => 'Your Profile Details is Successfully Updated.'
						);
					$_SESSION['email'] = $admin_email;
					$data['show_form'] = FALSE;
				} else {
					$response[] = array(
						'type' => 'error',
						'text' => 'There is nothing new on your provided details for change.'
						);
				}

			}

			$data['response_data'] = array('method' => 'static', 'response' => $response);

		}
		
		$data['db_data'] = array('full_name' => $row['full_name'], 'email' => $row['email']);
		$data['selected_nav'] = 'admin_profile';
		$data['page_header'] = 'Admin Profile';
		$smarty->assign('data', $data);

	} else {
		header ("Location: logout.php");
        exit;
	}

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/profile.tpl');
?>