<?php
define("APP_INTERFACE", "admin");
session_start();
require_once '../inc/app.init.php';

/* Get Submitted General Data
-------------------------------------------------- */
	$action = trim($_GET['action']);

/* Check if an user is Logged in, if not, redirect to logout page and then ask for login
-------------------------------------------------- */
	checkAdminLogged($smarty);

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	$placeholders = array('CDN_STATUS', 'CDN_URL');
	getConfiguration($smarty, $placeholders);

/* Process Actions
-------------------------------------------------- */
	if ($action == "clear_cache") {

		$data['page_header'] = 'Clear ALL Caches';

		$smarty->clearCompiledTemplate();
		$smarty->clearAllCache();

		 $response[] = array(
			'type' => 'success',
			'text' => 'All Caches and Compiled Templates successfully cleared.'
			);

		 $data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$data['page_header'] = 'Utilities';

		$response[] = array(
			'type' => 'error',
			'text' => '<b>Oops!</b><br />You are on wrong page.<br />Please select correct action from sidebar.'
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	}

/* Get / Assign Data for Dashboard Stats
-------------------------------------------------- */
	$data['selected_nav'] = 'utilities';
	$smarty->assign('data', $data);

/* Close Database Connection
-------------------------------------------------- */
	$db->close();

/* Load Template and Send Contents to the Browser
-------------------------------------------------- */
	$smarty->display('admin/utilities.tpl');
?>