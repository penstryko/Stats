<?php
header("Content-type: application/x-javascript");

require_once 'inc/app.init.php';

/* Collect User Data
-------------------------------------------------- */
	$domain = strtolower(trim($_GET['domain']));
	$type = strtolower(trim($_GET['type']));

/* Set Template & Cache ID
-------------------------------------------------- */
	$template = APP_THEME . "/widget.tpl";
	$cache_id = "widget|" . $domain . "|" . $type;

/* Set Smarty Caching
-------------------------------------------------- */
	$smarty->setCaching(Smarty::CACHING_LIFETIME_SAVED);
	$smarty->setCacheLifetime(2592000); // 30 Days of Caching (if data is updated then the old cache will be removed by other process)

/* Basic Pre-Validation
-------------------------------------------------- */
	if (in_array($type, array('worth', 'stats', 'pr')) && filter_var("http://" . $domain, FILTER_VALIDATE_URL)) {

		if(!$smarty->isCached($template, $cache_id)) {

			/* Initiate Database Connection and database related works
			-------------------------------------------------- */
				$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
				$db->connect();

			/* Sanitize User Posted Data
			-------------------------------------------------- */
				$domain = $db->escape($domain);
				$type = $db->escape($type);

			/* Get Config
			-------------------------------------------------- */
				$sql = "SELECT placeholder, value FROM config WHERE placeholder IN ('SITE_ADDRESS', 'STAT_URL_STRUCTURE', 'MANUAL_APPROVAL_DOMAIN', 'DATA_PRIVACY_UNSAFE',  'DATA_PRIVACY_PENDING', 'PREFIX_STAT')";
				$rows = $db->fetch_array($sql);
				foreach ($rows as $record) {
				    $config[$record['placeholder']] = $record['value'];
				}

			/* Prepare Valid Domain Status
			-------------------------------------------------- */
				$valid_domain_status = array();
				$valid_domain_status[] = 1;

				if ($config['DATA_PRIVACY_UNSAFE'] != "BLOCKED TO ALL") {
					$valid_domain_status[] = 2;
				}

				if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
					$valid_domain_status[] = 0;
				} elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] != "BLOCKED TO ALL") {
					$valid_domain_status[] = 0;
				}

				if (count($valid_domain_status) == 1) {
		            $safe_where_domain = "&& status = $valid_domain_status[0]";
		        } elseif (count($valid_domain_status) == 2) {
		            $safe_where_domain = "&& status IN ('" . implode("', '", $valid_domain_status) . "')";
		        }

			/* Prepare SQL Query
			-------------------------------------------------- */
				switch ($type) {

					case "worth":
						
						$sql = "SELECT
									domain, estimated_value
								FROM 
									insights_base
								WHERE domain = '$domain' $safe_where_domain";
						break;

					case "stats":
						
						$sql = "SELECT
									domain, estimated_value, google_pr, alexa_rank
								FROM
									insights_base
								WHERE domain = '$domain' $safe_where_domain";

						break;

					case "pr":

						$sql = "SELECT
									domain, google_pr
								FROM 
									insights_base
								WHERE domain = '$domain' $safe_where_domain";
						break;

				}

			/* Fetch & Assign Data
			-------------------------------------------------- */
				$record = $db->query_first($sql);
				if(empty($record['domain'])) {

					$cache_id = "no_cache";
					$data = array(
						'status' => 'error',
						'msg' => 'Sorry! The Domain does not exist on our database.'
					);

				} else {

					$data['site_address'] = $config['SITE_ADDRESS'];
					$data['type'] = $type;
					$data['record'] = $record;
					$data['stat_link'] = getStatLink($record['domain']);

				}

				$smarty->assign('data', $data);

			/* Close Database Connection
			-------------------------------------------------- */
				$db->close();

		}
		
	} else {

		$cache_id = "no_cache";
		$data = array(
			'status' => 'error',
			'msg' => 'Sorry! The Domain does not exist on our database.'
		);
		$smarty->assign('data', $data);

	}

$smarty->display($template, $cache_id);
?>