<?php
session_start();
require_once 'inc/app.init.php';

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	getConfiguration($smarty, NULL, TRUE);

/* Get Menu
-------------------------------------------------- */
	generateMenu($smarty);

/* Get Site Lists
-------------------------------------------------- */
	generateSiteList($smarty);

/* Set Language
-------------------------------------------------- */
	if (empty($config['DEFAULT_LANGUAGE'])) {
		$config['DEFAULT_LANGUAGE'] = "en_US";
	}
	require_once $current_dir . '/locale/' . $config['DEFAULT_LANGUAGE'] . '.php';
    $smarty->assign('lang', $lang, TRUE);

/* Get/Validate User Data 
-------------------------------------------------- */
	$t = trim($db->escape($_GET['t']));
	$q = trim($db->escape($_GET['q']));
	$tmp_q = correctTag(stripslashes($q));

	if (empty($q) || empty($tmp_q)) {
		
		$data['content_title'] = $lang["process"]["oops_heading"];
		$response[] = array(
			'type' => 'error',
			'text' => $lang['process']['missing_query']
			);
		$data['response_data'] = array('method' => 'static', 'response' => $response);

	} else {

		$valid_type = array('auto', 'domain', 'tag', 'email', 'ip', 'nameserver');
		if ($t == "auto" || !in_array($t, $valid_type)) {
			$t = detectQuery($q);
		}

	}

/* Redirect query to proper handler if it is other than a domain query
-------------------------------------------------- */
	if ($t != "domain" && !empty($q) && !empty($tmp_q)) {
		
		switch ($t) {
			case 'tag':
				$q = str_replace(' ', '-', $tmp_q);
				$prefix = $config['PREFIX_TAG'];
				break;
			case 'email':
				$prefix = $config['PREFIX_EMAIL'];
				break;
			case 'ip':
				$prefix = $config['PREFIX_HOSTED_IP'];
				break;
			case 'nameserver':
				$prefix = $config['PREFIX_NAMESERVER'];
				break;
		}

		header ("Location: " . $config['SITE_ADDRESS'] . "/" . $prefix . "/" . $q . "/");
		exit;
	}

/* Process data if it is a domain query
-------------------------------------------------- */
	if ($t == "domain" && !empty($q) && !empty($tmp_q)) {

		$domain_array = getDomain($q);
		$process_type = trim($db->escape($_POST['process_type']));
		
		if (!$domain_array) {

			$data['content_title'] = $lang["process"]["oops_heading"];
			$response[] = array(
				'type' => 'error',
				'text' => $lang['process']['missing_valid_domain']
				);
			$data['response_data'] = array('method' => 'static', 'response' => $response);

		} else {

			$domain = $domain_array['label'] . '.' . $domain_array['extension'];
			if (!empty($domain_array['sub_domain'])) {
				$domain = $domain_array['sub_domain'] . '.' . $domain;
				$is_sub_domain = "yes";
			}

			$sql = "SELECT id, status, updated_datetime FROM insights_base WHERE domain = '$domain'";
			$row = $db->query_first($sql);

			$current_timestamp = strtotime("now");

			if (!empty($row['id']) && $process_type != "update") {

				$redirect_url = getStatLink($domain);
				header ("Location: " . $redirect_url);
				exit;

			} elseif ($process_type == "update" && (($current_timestamp - strtotime($row['updated_datetime'])) < $config['UPDATE_BLOCK'])) {

				$data['content_title'] = $lang["process"]["oops_heading"];
				$response[] = array(
					'type' => 'error',
					'text' => $lang['process']['error_update_block']
					);
				$data['response_data'] = array('method' => 'static', 'response' => $response);

			} else {

				$where_clause_data = array();
				$where_clause_data[] = "data = '$domain'";
				if (!empty($domain_array['sub_domain'])) {
					$where_clause_data[] = "data = '" . $domain_array['label'] . "." . $domain_array['extension'] . "'";
				}
				$where_clause_data = implode(" || ", $where_clause_data);

				$blocking_sql = "SELECT id FROM blockings WHERE type = 'DOMAINS' && ($where_clause_data)";
				$blocking_row = $db->query_first($blocking_sql);

				if ($row['status'] == "3" || ( !empty($blocking_row['id']) || $row['status'] == "2" && $config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO ALL" ) || ( $row['status'] == "0" && $config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "BLOCKED TO ALL" ) ) {
					
					$data['content_title'] = $lang["process"]["oops_heading"];
					$response[] = array(
						'type' => 'error',
						'text' => $lang['process']['error_domain_block']
						);
					$data['response_data'] = array('method' => 'static', 'response' => $response);

				} elseif (!empty($row['id']) && $process_type == "update") {

					$data['content_title'] = $lang["process"]["heading"]["update"];
					$response[] = array(
						'type' => 'success',
						'text' => $lang["process"]["details"]["update"]
						);
					$data['response_data'] = array('method' => 'static', 'response' => $response);

					$data['run_process'] = TRUE;
					$data['run_process_header'] = $lang["process"]["heading"]["update_process"];
					$data['run_process_type'] = "update";

				} else {
					
					$data['content_title'] = $lang["process"]["heading"]["add"];
					$response[] = array(
						'type' => 'success',
						'text' => $lang["process"]["details"]["add"]
						);
					$data['response_data'] = array('method' => 'static', 'response' => $response);

					$data['run_process'] = TRUE;
					$data['run_process_header'] = $lang["process"]["heading"]["add_process"];
					$data['run_process_type'] = "add";
					
				}

				/* Assigning common data to add and update process
				-------------------------------------------------- */
				if ($data['run_process']) {

					$data['run_process_domain'] = $domain;
					$new_token = generateToken();
					$data['process_token'] = $new_token;
					$data['is_sub_domain'] = $is_sub_domain;
					$data['redirect_url'] = getStatLink($domain);

					$_SESSION['run_process_domain'] 		= $domain;
					$_SESSION['token_id'] 					= $new_token['id'];
					$_SESSION['request_time'] 				= $new_token['time'];

					$_SESSION['extension'] 					= $domain_array['extension'];

					$_SESSION['DATA_PRIVACY_UNSAFE'] 		= $config['DATA_PRIVACY_UNSAFE'];
					$_SESSION['GOOGLE_API_SERVER_APPS'] 	= $config['GOOGLE_API_SERVER_APPS'];
					$_SESSION['SEOMOZ_API_ACCESSID'] 		= $config['SEOMOZ_API_ACCESSID'];
					$_SESSION['SEOMOZ_API_SECRETKEY'] 		= $config['SEOMOZ_API_SECRETKEY'];
					$_SESSION['GOOGLE_SAFE_BROWSING_API'] 	= $config['GOOGLE_SAFE_BROWSING_API'];
					$_SESSION['WOT_API'] 					= $config['WOT_API'];
					$_SESSION['IPINFODB_API'] 				= $config['IPINFODB_API'];
					$_SESSION['TOTAL_INTERNET_USERS'] 		= $config['TOTAL_INTERNET_USERS'];
					$_SESSION['TWITTER_AUTOMATION'] 		= $config['TWITTER_AUTOMATION'];

					if ($config['TWITTER_AUTOMATION'] == "ENABLED") {
						$_SESSION['TWITTER_CONSUMER_KEY'] 		= $config['TWITTER_CONSUMER_KEY'];
						$_SESSION['TWITTER_CONSUMER_SECRET'] 	= $config['TWITTER_CONSUMER_SECRET'];
						$_SESSION['TWITTER_USER_TOKEN'] 		= $config['TWITTER_USER_TOKEN'];
						$_SESSION['TWITTER_USER_SECRET'] 		= $config['TWITTER_USER_SECRET'];
						$_SESSION['MANUAL_APPROVAL_DOMAIN'] 	= $config['MANUAL_APPROVAL_DOMAIN'];
						$_SESSION['DATA_PRIVACY_PENDING'] 		= $config['DATA_PRIVACY_PENDING'];
						$_SESSION['stat_url'] 					= $data['redirect_url'];
					}

				}

			}

		}

	}

/* Close Database Connection
-------------------------------------------------- */
	$data['page_title'] = $lang['process']['title'] . sprintf(' %s ', $config['TITLEBAR_SEPERATOR']) . $config['SITE_TITLE'];
	$data['meta'][] = "<META NAME='ROBOTS' CONTENT='NOINDEX, NOFOLLOW'>";
	$smarty->assign('data', $data);

/* Finally Display the results to User
-------------------------------------------------- */
	$smarty->display(APP_THEME . '/process.tpl');

/* Close Database Connection
-------------------------------------------------- */
	$db->close();
?>