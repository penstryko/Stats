<?php
require_once 'inc/app.init.php';

/* Initiate Database Connection and database related works
-------------------------------------------------- */
	$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
	$db->connect();

/* Get Configurations
-------------------------------------------------- */
	getConfiguration($smarty);

/* Set Language
-------------------------------------------------- */
	if (empty($config['DEFAULT_LANGUAGE'])) {
		$config['DEFAULT_LANGUAGE'] = "en_US";
	}
	require_once $current_dir . '/locale/' . $config['DEFAULT_LANGUAGE'] . '.php';
    $smarty->assign('lang', $lang, TRUE);

/* Define valid routes and its controller.
/* Routes value must be a base filename without its extension i.e ".php"
/* Routes Format is [1st DATA FROM URL] = [Processing File]
-------------------------------------------------- */
	$routes['default'] 							= "welcome";	// Homepage [This is Default route]
	
	$routes[$config['PREFIX_TAG']] 				= "listings";	// Listings by Tags
	$routes[$config['PREFIX_EMAIL']] 			= "listings";	// Listings by E-Mail
	$routes[$config['PREFIX_HOSTED_IP']]		= "listings";	// Listings by Hosted IP
	$routes[$config['PREFIX_HOSTED_COUNTRY']]	= "listings";	// Listings by Hosted Country
	$routes[$config['PREFIX_NAMESERVER']] 		= "listings";	// Listings by Nameserver	
	$routes[$config['PREFIX_REGISTRAR']] 		= "listings";	// Listings by Domain Registrar
	$routes[$config['PREFIX_EXTENSION']] 		= "listings";	// Listings by Domain Extension
	$routes[$config['PREFIX_PAGERANK']] 		= "listings";	// Listings by Google Pagerank
	$routes[$config['PREFIX_ADSENSE']]			= "listings";	// Listings by Google Adsense ID
	$routes["topsites"]							= "listings";	// Topsites
	$routes["recently-added"]					= "listings";	// New Sites

	$routes[$config['PREFIX_STAT']] 			= "stat";		// Domain Stat
	
	$routes[$config['PREFIX_PAGE']] 			= "page";		// Pages
	$routes['rss'] 								= "rss";		// RSS
	$routes['sitemap'] 							= "sitemap";	// Sitemap

/* Process Routes
-------------------------------------------------- */
	$route_path = processRoutes($routes);
	require_once $route_path;

/* Close Database Connection
-------------------------------------------------- */
	$db->close();
?>