<?php
error_reporting(0);

/* Define Absolute Application Path
-------------------------------------------------- */
	$current_dir = dirname(__FILE__);
	$root_dir = realpath($current_dir . '/..');

/* Define Application Details
-------------------------------------------------- */
	define("APP_NAME", "CubeStat");
	define("APP_VERSION", "2.0");
	define("APP_URL", "http://www.domain.com/");

/* Include Application Dependencies
-------------------------------------------------- */
	require_once $current_dir . '/app.config.php';
	require_once $current_dir . '/lib/smarty/Smarty.class.php';
	require_once $current_dir . '/lib/classes/Database.singleton.php';	
	require_once $current_dir . '/function_core.php';

	if (APP_INTERFACE == "admin") {
		require_once $current_dir . '/function_admin.php';
	}

/* Initiate & Define Smarty Instance
-------------------------------------------------- */
	$smarty = new Smarty();
	$smarty->setTemplateDir($root_dir . '/templates/');
	$smarty->setCompileDir($root_dir . '/cs_tmp/compile/');
	$smarty->setCacheDir($root_dir . '/cs_tmp/cache/');
	// $smarty->debugging = true;

/* Register Custom Smarty Plugins Based on Function
-------------------------------------------------- */
	$smarty->registerPlugin('function', 'nicetime', 'smarty_nicetime', false, array('timestamp', 'detailLevel'));
	$smarty->registerPlugin('function', 'showupdate', 'smarty_showupdate', false, array('timestamp'));
	$smarty->registerPlugin('function', 'show_banner', 'smarty_show_banner', false, array('unsafe', 'type', 'shortcode'));
?>