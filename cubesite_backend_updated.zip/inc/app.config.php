<?php
/* Define Database Details
-------------------------------------------------- */
	define("DB_SERVER", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "123");
	define("DB_DATABASE", "test");

/* Define Template and Active Template
 * NOTE: Base URI Must end with a trailing slash
-------------------------------------------------- */
	define("APP_BASE_URI", "/");
	define('APP_THEME', 'default');
?>