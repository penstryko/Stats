<?php
function getConfiguration($smarty, $placeholder = array(), $tld = FALSE) {

    $db = Database::obtain();

    if (!empty($placeholder)) {
        $where = " WHERE placeholder IN ('" . implode("', '", $placeholder) . "')";
    }

    $sql = "SELECT placeholder, value FROM config" . $where;
    $rows = $db->fetch_array($sql);
    $config = array();

    foreach ($rows as $record) {
        $config[$record['placeholder']] = html_entity_decode($record['value'], ENT_QUOTES, 'UTF-8');
    }

    $smarty->assign('config', $config, TRUE);

    if ($config['CDN_STATUS'] == 'ENABLED') {
        define("TEMPLATE_PATH", $config['CDN_URL']);
    } else {
        define("TEMPLATE_PATH", APP_BASE_URI . 'templates');
    }

    if ($tld == TRUE) {
        $sql = "SELECT extension FROM tld WHERE status = 'ACTIVE'";
        $rows = $db->fetch_array($sql);
        foreach ($rows as $record) {
            $config['active_tld'][] = $record['extension'];
        }
    }

    $GLOBALS['config'] = $config;
}

function generateMenu($smarty) {
    
    global $config;

    $db = Database::obtain();

    $sql = "SELECT id, title, sef_title, type, parent_id, redirect_link FROM pages WHERE type IN ('MAIN MENU', 'FOOTER PAGES') ORDER BY parent_id ASC, page_order ASC";
    $rows = $db->fetch_array($sql);
    $menu = array();

    foreach ($rows as $record) {

        // Generate Page Link
        if (empty($record['redirect_link'])) {
            $link = APP_BASE_URI . $config['PREFIX_PAGE'] . '/' . $record['sef_title'] . '/';
        } elseif (substr($record['redirect_link'], 0, 1) == "/") {
            $link = APP_BASE_URI . substr($record['redirect_link'], 1);
        } else {
            $link = $record['redirect_link'];
        }

        // Build Menu & Sub-Menu
        if ($record['parent_id'] == "0") {
            $menu[$record['type']][$record['id']]['title']      = $record['title'];
            $menu[$record['type']][$record['id']]['sef_title']  = $record['sef_title'];
            $menu[$record['type']][$record['id']]['link']       = $link;
        } else {
            $menu[$record['type']][$record['parent_id']]['sub_menu'][]  = array(
                'title' => $record['title'],
                'link' => $link
                );
        }

    }

    $smarty->assign('menu', $menu, TRUE);

}

function generatePassword($length = 10, $add_time = FALSE) {
    
    $password = "";
    $possible = "2346789bcdfghjkmnpqrtvwxyzBCDFGHJKLMNPQRTVWXYZ";
    $maxlength = strlen($possible);
    
    if ($length > $maxlength) {
      $length = $maxlength;
    }
    
    $i = 0;
    while ($i < $length) {
        $char = substr($possible, mt_rand(0, $maxlength-1), 1);
        if (!strstr($password, $char)) {
            $password .= $char;
            $i++;
        }
    }

    if ($add_time == TRUE) {
        $password = $password . time();
    }

    return $password;
}

function getExtension($filename) {
    $extension = strtolower(substr($filename, strrpos($filename, '.') + 1));
    return $extension;
}

function getStatLink($domain) {

    global $config;
    return $config['SITE_ADDRESS'] . '/' . $config['PREFIX_STAT'] . '/' . $domain;

}

function getDomain($url, $check_subdomain_host = TRUE) {

    global $config;

    $db = Database::obtain();

    /* Get Domain Hostname
    -------------------------------------------------- */
        $url = filter_var(trim(strip_tags(strtolower($url))), FILTER_SANITIZE_URL);
        $url = (substr($url, 0, 7) != "http://" && substr($url, 0, 8) != "https://") ? 'http://' . $url : $url;
        if ( !filter_var($url, FILTER_VALIDATE_URL) ) { return FALSE; }
        
        $host = parse_url($url, PHP_URL_HOST);
        if ( empty($host) ) { return FALSE; }
        
        $host = implode(".", array_filter(explode(".", $host)));

        if ( count(explode(".", $host)) > 2 && substr($host, 0, 4) == "www." ) { $host = substr($host, 4, strlen($host)); }     
        if ( strlen($host) < 4 || count(explode(".", $host)) < 2 ) { return FALSE; }

    /* Create Array from Host
    -------------------------------------------------- */
        $pieces = explode('.', $host);
        $tmp = $pieces;
        $pieces_count = count($pieces);
        if ($pieces_count > 2) {

            // since our loop is starting from 0
            // and we are working on an array having more than 2 indexes,
            // we will deduct 2 from the loop 
            for ($i=0; $i <= $pieces_count-2; $i++) {
                
                array_shift($tmp);
                
                if (in_array(implode('.', $tmp), $config['active_tld'])) {
                   
                    if ($pieces[$i-1] != "" && $check_subdomain_host == TRUE) {
                        
                        if ($config['ALLOW_SUBDOMAIN'] == "ENABLED") {
                            
                            $host = $pieces[$i] . '.' . implode('.', $tmp);
                            $sql = "SELECT id FROM subdomain_hosts WHERE host = '$host'";
                            $row = $db->query_first($sql);

                            if (!empty($row['id'])) {
                                $data['sub_domain'] = $pieces[$i-1];
                            }

                        }

                    }

                    $data['label'] = $pieces[$i];
                    $data['extension'] = implode('.', $tmp);
                    return $data;
                }

            }

            return FALSE;
            
        } else {
            if (in_array($pieces[1], $config['active_tld'])) {
                $data = array(
                    'label' => $pieces[0],
                    'extension' => $pieces[1]
                );
            } else {
                return FALSE;
            }
        }

    return $data;

}

function correctTag($string) {
    $string = strip_tags(mb_strtolower($string, 'UTF-8'));
    $string = html_entity_decode($string, ENT_QUOTES, 'UTF-8');
    $string = str_replace("'", '', $string);
    $string = preg_replace('/-+/', '-', $string);
    $replace = array("$", "-", "+", "!", "*", "'", '"', "(", ")", ",", "{", "}", "|", "\\", "^", "~", "[", "]", "`", "<", ">", "#", "%", ";", "/", "?", ":", "@", "&", "=");
    $string = str_replace($replace, ' ', $string);
    $string = preg_replace('/\s+/', ' ', $string);
    $string = trim($string);

    if (mb_strlen($string) > 100) {
        $string = "";
    }
    return $string;
}

function detectQuery($query) {
    if(filter_var($query, FILTER_VALIDATE_EMAIL)){
        $type = "email";
    } elseif (filter_var($query, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $type = "ip";
    } elseif (getDomain($query)) {
        $type = "domain";
    } else {
        $type = "tag";
    }
    return $type;
}

function generateToken() {
    $time = time();
    $token = base64_encode(hash("sha256", $time));
    $output = array(
        'time' => $time,
        'id' => $token
    );
    $_SESSION['token_time'] = $time;
    $_SESSION['token_id'] = $token;
    return $output;
}

function validateToken($token, $request_time, $timeout) {
    if ($token == $_SESSION['token_id'] && $request_time == $_SESSION['token_time']) {
        $valid_token = base64_encode(hash("sha256", $request_time));
        if (($token != $valid_token) || (time() > ($request_time + $timeout))) {
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
}

function processRoutes($routes) {
    
    if ( isset($_SERVER['REQUEST_URI']) || isset($_SERVER['SCRIPT_NAME'])) {
        
        $uri = $_SERVER['REQUEST_URI'];
        if (strpos($uri, $_SERVER['SCRIPT_NAME']) === 0){
            $uri = substr($uri, strlen($_SERVER['SCRIPT_NAME']));
        } elseif (strpos($uri, dirname($_SERVER['SCRIPT_NAME'])) === 0) {
            $uri = substr($uri, strlen(dirname($_SERVER['SCRIPT_NAME'])));
        }

        if ($uri == '/' || empty($uri)) {
            $uri = '/';
        }

        $uri = parse_url($uri, PHP_URL_PATH);
        $uri = str_replace(array('//', '../'), '/', trim($uri, '/'));

    }

    if ($uri != "") {
        $segments = explode('/', $uri);
        $GLOBALS['segments'] = $segments;
    }

    if (count($segments) > 0 && array_key_exists($segments[0], $routes) && file_exists('inc/routes/' . $routes[$segments[0]] . '.php')) {
        $route_path = 'inc/routes/' . $routes[$segments[0]] . '.php';
    } else {
        
        if (empty($segments[0]) || $segments[0] == "index.php") {
            $route_path = 'inc/routes/' . $routes['default'] . '.php';
        } else {
            $segments[1] = "404";
            $route_path = 'inc/routes/page.php';            
        }

    }

    return $route_path;

}

function generateSiteList($smarty, $recentsite_limit = 10, $topsite_limit = 15, $toptag_limit = 15) {

    global $config;

    $db = Database::obtain();

    /* Prepare Valid Domain Status
    -------------------------------------------------- */
        $valid_domain_status = array();
        $valid_domain_status[] = 1;

        if ($config['DATA_PRIVACY_UNSAFE'] == "ALLOWED TO ALL") {
            $valid_domain_status[] = 2;
        }

        if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
            $valid_domain_status[] = 0;
        } elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS SAFE") {
            $valid_domain_status[] = 0;
        }

        if (count($valid_domain_status) == 1) {
            $safe_where_domain = "status = $valid_domain_status[0] &&";
        } elseif (count($valid_domain_status) == 2) {
            $safe_where_domain = "status IN ('" . implode("', '", $valid_domain_status) . "') &&";
        }

    /* Cron Listing Status
    -------------------------------------------------- */
        if ($config['LISTINGS_CRON_DOMAIN'] == "DISABLED") {
            $where_cron = "&& is_cron = '0'";
        }

    /* Get Recently Analyzed Sites
    -------------------------------------------------- */
        if (!empty($recentsite_limit)) {

            $sql    = "SELECT
                        domain, updated_datetime, estimated_value, google_pr, alexa_rank
                    FROM
                        insights_base
                    WHERE
                        $safe_where_domain CHAR_LENGTH(domain) <= 20 $where_cron
                    ORDER BY
                        updated_datetime DESC
                    LIMIT
                        $recentsite_limit";

            $rows = $db->query($sql);

            while ($record = $db->fetch($rows)) {

                $worth = $config['DEFAULT_CURRENCY_SYMBOL'] . ' ' . number_format($record['estimated_value'] * $config['DEFAULT_CURRENCY_RATE'], 2);
                $stat_link = getStatLink($record['domain']);

                $listing_data['recent'][] = array(
                    'domain' => $record['domain'],
                    'stat_link' => $stat_link,
                    'updated_datetime' => $record['updated_datetime'],
                    'worth' => $worth,
                    'pagerank' => $record['google_pr'],
                    'alexa_rank' => number_format($record['alexa_rank'])
                );

            }

        }

    /* Get Top Sites
    -------------------------------------------------- */
        if (!empty($topsite_limit)) {

            $sql    = "SELECT
                        domain
                    FROM 
                        insights_base
                    WHERE
                        $safe_where_domain CHAR_LENGTH(domain) <= 18 && CHAR_LENGTH(extension) = 3 && is_subdomain = '0' && alexa_rank > 0
                    ORDER BY
                        alexa_rank ASC
                    LIMIT
                        $topsite_limit";

            $rows = $db->query($sql);

            while ($record = $db->fetch($rows)) {

                $stat_link = getStatLink($record['domain']);
                
                $listing_data['topsite'][] = array(
                    'domain' => $record['domain'],
                    'stat_link' => $stat_link
                );

            }

        }

    /* Get Top Tags
    -------------------------------------------------- */
        if (!empty($config['TOP_TAGS'])) {

            $top_tags = explode(',', $config['TOP_TAGS']);
            shuffle($top_tags);

            $i = 0;
            foreach ($top_tags as $top_tag) {
                $i++;
                $slug = correctTag(trim($top_tag));
                $slug = str_replace(" ", "-", $slug);
                $listing_data['toptags'][] = array('slug' => $slug, 'tag' => trim($top_tag));

                if ($i >= $toptag_limit) {
                    break;
                }
            }

        }

    /* Assign Data to Template
    -------------------------------------------------- */
        $smarty->assign('site_lists', $listing_data, TRUE);

}

function get_banner_code($params)
{
    // Params = array
    // Params = unsafe, format, width, height, image, link, html, alt_html

    $data = "";

    if (in_array($params['format'], array('IMAGE', 'FLASH')))
    {
        if ($params['width'] > 0)
        {
            $data_width = $params['width'];
        }

        if ($params['height'] > 0)
        {
            $data_height = $params['height'];
        }

        $image_path = TEMPLATE_PATH . '/userfiles/banners/' . $params['image'];
    }

    if ($params['format'] == "IMAGE")
    {
        if (!empty($params['link']))
        {
            $data .= '<a href="' . $params['link'] .'" target="_blank">';
        }

        $data .= '<img src="' . $image_path . '" width="' . $data_width . '" height="' . $data_height . '" />';

        if (!empty($params['link']))
        {
            $data .= "</a>";
        }
    }
    elseif ($params['format'] == "HTML")
    {
        if ($params['unsafe'] == true)
        {
            $data .= html_entity_decode($params['alt_html'], ENT_QUOTES, 'UTF-8');
        }
        else
        {
            $data .= html_entity_decode($params['html'], ENT_QUOTES, 'UTF-8');
        }
    }
    elseif ($params['format'] == "FLASH")
    {
        $data .= '<object width="' . $data_width . '" height="' . $data_height . '">';
        $data .= '<param name="movie" value="' . $image_path . '"></param>';
        $data .= '<param name="allowFullScreen" value="true"></param>';
        $data .= '<param name="allowscriptaccess" value="always"></param>';
        $data .= '<embed src="' . $image_path . '" type="application/x-shockwave-flash" width="' . $data_width . '" height="' . $data_height . '" allowscriptaccess="always" allowfullscreen="true"></embed>';
        $data .= '</object>';
    }

    return $data;
}

function smarty_show_banner($params, Smarty_Internal_Template $template)
{
    $db = Database::obtain();

    $data = "";

    if ($params['type'] == "CUSTOM")
    {
        $sql = "SELECT id, format, width, height, image, link, html_code, alternative_html_code FROM banners WHERE status='ACTIVE' && short_code='$params[shortcode]'";
        $record = $db->query_first($sql);

        if(!empty($record['id']))
        {
            $params = array(
                'unsafe' => $params['unsafe'],
                'format' => $record['format'],
                'width' => $record['width'],
                'height' => $record['height'],
                'image' => $record['image'],
                'link' => $record['link'],
                'html' => $record['html_code'],
                'alt_html' => $record['alternative_html_code']
                );
            $data .= get_banner_code($params);
            $data .= '<div class="clearfix"></div>';
        }
    }
    else
    {
        $sql = "SELECT format, width, height, image, link, html_code, alternative_html_code FROM banners WHERE status='ACTIVE' && location='$params[type]' ORDER BY banner_order ASC";
        $rows = $db->fetch_array($sql);

        foreach ($rows as $record)
        {
            $data .= '<div class="marginBottom_10">';

            $params = array(
                'unsafe' => $params['unsafe'],
                'format' => $record['format'],
                'width' => $record['width'],
                'height' => $record['height'],
                'image' => $record['image'],
                'link' => $record['link'],
                'html' => $record['html_code'],
                'alt_html' => $record['alternative_html_code']
                );
            $data .= get_banner_code($params);

            $data .= '<div class="clearfix"></div>';
            $data .= '</div>';
        }        
    }

    return $data;
}

function niceTime($params) {

    // parameters for this function
    // $timestamp = timestamp
    // $detailLevel = integer
    
    $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths = array("60", "60", "24", "7", "4.35", "12", "10");

    $now = time();

    // check validity of date
    if(empty($params['timestamp'])) {
        return "Unknown time";
    } else {
        $timestamp = (int)strtotime($params['timestamp']);
    }

    // check if detailLevel is specified, if not set the defaults
    if(empty($params['detailLevel'])) {
        $detailLevel = 1;
    } else {
        $detailLevel = $params['detailLevel'];
    }
    
    // is it future date or past date
    if($now > $timestamp) {
        $difference = $now - $timestamp;
        $tense = "ago";

    } else {
        $difference = $timestamp - $now;
        $tense = "from now";
    }

    if (empty($difference)) {
        //return "1 second ago";
        return array(
            'string' => '1 second',
            'tense' => 'ago'
        );
    }

    $remainders = array();

    for($j = 0; $j < count($lengths); $j++) {
        $remainders[$j] = floor(fmod($difference, $lengths[$j]));
        $difference = floor($difference / $lengths[$j]);
    }

    $difference = round($difference);

    $remainders[] = $difference;

    $string = "";

    for ($i = count($remainders) - 1; $i >= 0; $i--) {
        if ($remainders[$i]) {
            $string .= $remainders[$i] . " " . $periods[$i];

            if($remainders[$i] != 1) {
                $string .= "s";
            }

            $string .= " ";

            $detailLevel--;

            if ($detailLevel <= 0) {
                break;
            }
        }
    }

    $output = array(
        'string' => $string,
        'tense' => $tense
    );

    return $output;

}

function smarty_nicetime($params, Smarty_Internal_Template $template) {

    $output = niceTime($params);
    return $output['string'] . ' ' . $output['tense'];
    
}

function smarty_showupdate($params, Smarty_Internal_Template $template) {

    global $config;

    $now = time();

    // check validity of date
    if(empty($params['timestamp'])) {
        return "Unknown time";
    } else {
        $timestamp = strtotime($params['timestamp']);
    }

    $diff = $now - $timestamp;

    if ($diff < $config['UPDATE_BLOCK']) {
        return "disabled";
    }
}
?>