<?php
function checkAdminLogged($smarty, $nav = true) {
    if (empty($_SESSION['email']) || $_SESSION['logged'] != "yes" || $_SESSION['user_type'] != "ADMINISTRATOR") {
        header ("Location: logout.php");
        exit;
    } else {

        $smarty->assign('admin_logged', TRUE);

        if ($nav) {

        	$top_nav = array(
	            array('unq' => 'dashboard', 'title' => 'Admin Dashboard', 'icon' => 'icon-home', 'link' => 'dashboard.php', 'params' => ''),
	            array('unq' => 'admin_profile', 'title' => 'Admin Profile', 'icon' => 'icon-user', 'link' => 'profile.php', 'params' => ''),
	            array('unq' => 'visit', 'title' => 'Visit Website', 'icon' => 'icon-globe', 'link' => APP_BASE_URI, 'params' => 'target="_blank"'),
	            array('unq' => 'logout', 'title' => 'Logout', 'icon' => 'icon-off', 'link' => 'logout.php', 'params' => '')
	        );
	        $smarty->assign('top_nav', $top_nav);

	        $side_nav = array(
	            array(
	                'unq' => 'configurations',
	                'title' => 'Website Configurations',
	                'icon' => 'icon-cog',
	                'link' => 'configurations.php',
	                'params' => '',
	                'sub_menu' => ''
	            ),
	            array(
	                'unq' => 'domain_extensions',
	                'title' => 'Domain Extensions',
	                'icon' => 'icon-asterisk',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Domain Extensions', 'link' => 'extension.php?action=manage'),
	                    array('title' => 'Add New Domain Extension', 'link' => 'extension.php?action=add')
	                )
	            ),
				array(
	                'unq' => 'page_management',
	                'title' => 'Page Management',
	                'icon' => 'icon-file',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Pages', 'link' => 'page.php?action=manage'),
	                    array('title' => 'Add New Page', 'link' => 'page.php?action=add')
	                )
	            ),
	            array(
	                'unq' => 'banner_management',
	                'title' => 'Banner Management',
	                'icon' => 'icon-picture',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Banners', 'link' => 'banner.php?action=manage'),
	                    array('title' => 'Add a New Banner', 'link' => 'banner.php?action=add')
	                )
	            ),
	            array(
	                'unq' => 'domain_queuing',
	                'title' => 'Domain Queuing',
	                'icon' => 'icon-time',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Queued Domains', 'link' => 'queuing.php?action=manage'),
	                    array('title' => 'Add Domains to the Queue', 'link' => 'queuing.php?action=add'),
	                    array('title' => 'Compact Queued Domains', 'link' => 'queuing.php?action=compact')
	                )
	            ),
	            array(
	                'unq' => 'subdomain_hosts',
	                'title' => 'Allowed Subdomain Hosts',
	                'icon' => 'icon-indent-left',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Allowed Subdomain Hosts', 'link' => 'subdomain_hosts.php?action=manage'),
	                    array('title' => 'Add Allowed Subdomain Hosts', 'link' => 'subdomain_hosts.php?action=add')
	                )
	            ),
	            array(
	                'unq' => 'blockings',
	                'title' => 'Blockings',
	                'icon' => 'icon-ban-circle',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Blocked Data', 'link' => 'blockings.php?action=manage'),
	                    array('title' => 'Add New Blocked Data', 'link' => 'blockings.php?action=add')
	                )
	            ),
	            array(
	                'unq' => 'added_data',
	                'title' => 'Added Data Management',
	                'icon' => 'icon-map-marker',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Manage Added Domains', 'link' => 'added_data.php?action=domains'),
	                    array('title' => 'Manage Added Keywords', 'link' => 'added_data.php?action=keywords')
	                )
	            ),
	            array(
	                'unq' => 'utilities',
	                'title' => 'Utilities',
	                'icon' => 'icon-magnet',
	                'link' => '',
	                'params' => '',
	                'sub_menu' => array(
	                    array('title' => 'Clear All Caches', 'link' => 'utilities.php?action=clear_cache')
	                )
	            ),
	            array(
	                'unq' => 'file_manager',
	                'title' => 'File Manager',
	                'icon' => 'icon-filter',
	                'link' => APP_BASE_URI . 'inc/lib/filemanager/index.html',
	                'params' => 'target="_blank"',
	                'sub_menu' => ''
	            )
	        );
	        $smarty->assign('side_nav', $side_nav);

        }

    }
}
?>