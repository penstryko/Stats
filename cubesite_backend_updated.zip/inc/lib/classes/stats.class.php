<?php
class stats
{

	private $curl;
	private $whois;
	private $pagerank;
	private $dom_doc;

	/* Initializing Class Dependent Resources
	-------------------------------------------------- */
		public function __construct()
		{
			$this->curl = new Curl;
			$this->curl->follow_redirects = true;
			$this->curl->options['CURLOPT_ENCODING'] = ""; // Empty Value Means: all supported encoding types
			$this->curl->options['CURLOPT_MAXREDIRS'] = 5;
			$this->curl->options['CURLOPT_AUTOREFERER'] = true;
			$this->curl->options['CURLOPT_CONNECTTIMEOUT'] = 60;
			$this->curl->options['CURLOPT_TIMEOUT'] = 120;
			$this->curl->options['CURLOPT_SSL_VERIFYPEER'] = true;
			$this->curl->options['CURLOPT_CAINFO'] = dirname(__FILE__) . '/shuber-curl/cacert.pem';

			$this->whois = new Whois();
			$this->pagerank = new GooglePageRankChecker();
			$this->dom_doc = new DOMDocument();
		}

	/* Get Meta Data
	-------------------------------------------------- */
		public function getMeta($domain)
		{
			try
			{
				$callback_url = "http://" . $domain;
				$curl_response = $this->curl->get($callback_url);

				if (!empty($curl_response->headers['Status-Code'])) {
					
					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML('<?xml encoding="utf-8" ?>' . $curl_response);
					libxml_use_internal_errors(FALSE);

					$xpath = new DOMXPath($this->dom_doc);

					$metas = $xpath->query('//meta');
					foreach ($metas as $meta) {
						if (strtolower($meta->getAttribute('http-equiv')) == 'content-type') {
							$meta_charset = $meta->getAttribute('content');
						}
						if ($meta->getAttribute('charset') != '') {
							$html5_charset = $meta->getAttribute('charset');
						}
					}

					$header_charset = $curl_response->headers['Content-Type'];

					if (preg_match('/charset=(.+)/', $header_charset, $m)) {
						$charset = $m[1];
					} elseif (preg_match('/charset=(.+)/', $meta_charset, $m)) {
						$charset = $m[1];
					} elseif (!empty($html5_charset)) {
						$charset = $html5_charset;
					} else {
						// default charset
						// $charset = 'ISO-8859-1';
					}

					if (!empty($charset) && $charset != "utf-8") {
						
						$tmp = iconv($charset,'utf-8', $curl_response);
						libxml_use_internal_errors(TRUE);
						$this->dom_doc->loadHTML('<?xml encoding="utf-8" ?>' . $tmp);
						libxml_use_internal_errors(FALSE);

						$xpath = new DOMXPath($this->dom_doc);
					}

					$page_title = $xpath->query('//title')->item(0)->nodeValue;

					$metas = $xpath->query('//meta');
					foreach ($metas as $meta) {
						if (strtolower($meta->getAttribute('name')) == 'description') {
							$meta_description = $meta->getAttribute('content');
						}
						if (strtolower($meta->getAttribute('name')) == 'keywords') {
							$meta_tags = $meta->getAttribute('content');
						}
					}

					$page_title = htmlentities(trim($page_title), ENT_QUOTES, 'UTF-8', false);
					$meta_description = htmlentities(trim($meta_description), ENT_QUOTES, 'UTF-8', false);
					$meta_tags = htmlentities(trim($meta_tags), ENT_QUOTES, 'UTF-8', false);

					preg_match('/pub-[0-9]{16,16}/si', $curl_response, $output);
					$adsense_pub_id = ($output[0]) ? $output[0] : '';

					preg_match('/UA-[0-9]{6,9}-[0-9]{1,2}/si', $curl_response, $output);
					$analytics_id = ($output[0]) ? $output[0] : '';

					$links = $xpath->query('/html/body//a');
					foreach ($links as $link) {
						
						if (!$link->hasAttribute('href')) { continue; }

						$href = trim($link->getAttribute('href'));
						$rel = trim($link->getAttribute('rel'));

						if (empty($href)) { continue; }

						$tmp = parse_url(strtolower($href));

						if (substr($href, 0, 1) == '#' || (!empty($tmp['scheme']) && !in_array($tmp['scheme'], array('http', 'https')))) { continue; }

						if (empty($tmp['host']) || $tmp['host'] == $domain || strpos($tmp['host'], '.' . $domain) !== false) {
							$inlinks[] = $href;
							if (in_array("nofollow", explode(" ", $rel))) {
								$inlinks_nofollow[] = $href;
							}
						} else {
							$outlinks[] = $href;
							if (in_array("nofollow", explode(" ", $rel))) {
								$outlinks_nofollow[] = $href;
							}
						}

					}

					$inlinks = (is_array($inlinks)) ? array_unique(array_filter($inlinks)) : null ;
					$inlinks_nofollow = (is_array($inlinks_nofollow)) ? array_unique(array_filter($inlinks_nofollow)) : null ;
					$outlinks = (is_array($outlinks)) ? array_unique(array_filter($outlinks)) : null ;
					$outlinks_nofollow = (is_array($outlinks_nofollow)) ? array_unique(array_filter($outlinks_nofollow)) : null ;

					$inpage_analysis = array(
						'h1' => $xpath->query("/html/body//h1")->length,
						'h2' => $xpath->query("/html/body//h2")->length,
						'h3' => $xpath->query("/html/body//h3")->length,
						'h4' => $xpath->query("/html/body//h4")->length,
						'h5' => $xpath->query("/html/body//h5")->length,
						'h6' => $xpath->query("/html/body//h6")->length,
						'iframe' => $xpath->query("/html/body//iframe")->length,
						'img' => $xpath->query("/html/body//img")->length,
						'analytics' => $analytics_id,
						'inlinks' => count($inlinks),
						'inlinks_nofollow' => count($inlinks_nofollow),
						'outlinks' => count($outlinks),
						'outlinks_nofollow' => count($outlinks_nofollow)
					);

					$response = array(
						'status' => 'success',
						'data' => array(
							'test' => $test,
							'page_title' => $page_title,
							'meta_description' => $meta_description,
							'meta_tags' => $meta_tags,
							'adsense_pub_id' => $adsense_pub_id,
							'charset' => strtolower($charset),
							'header_data' => $curl_response->headers,
							'inpage_analysis' => $inpage_analysis
						)
					);

				} else {

					$response = array(
						'status' => 'error',
						'msg' => $this->curl->error()
					);
					
				}

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get DNS Records
	-------------------------------------------------- */
		public function getDNS($domain)
		{
			try
			{

				$data = dns_get_record($domain, DNS_ALL);
				$response = array(
					'status' => 'success',
					'data' => array(
						'dns_records' => $data
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Host Information
	-------------------------------------------------- */
		public function getHost($domain, $api = "")
		{
			try
			{
				$hosted_ip = gethostbyname($domain);

				if ($hosted_ip == $domain || !filter_var($hosted_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {

					$response = array(
						'status' => 'error',
						'msg' => 'Unable to Get IP by Host Name.'
					);

				} else {

					$callback_url = "http://api.ipinfodb.com/v3/ip-city/?";
					$data = array(
						'key'		=> (empty($api) ? $_SESSION['IPINFODB_API'] : $api),
						'ip'		=> $hosted_ip,
						'format' 	=> 'json'
					);

					$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

					if ($curl_response->headers['Status-Code'] == "200") {

						$content = json_decode($curl_response, true);

						if ($content['statusCode'] == "OK") {

							$friendly_location = array();
							
							$tmp = array('regionName', 'cityName', 'countryName', 'zipCode');
							foreach ($tmp as $c) {
								if ($content[$c] != "" && $content[$c] != "-") {
									$friendly_location[] = ucwords(strtolower($content[$c]));
								}
							}

							$host_details = array(
								'hosted_ip' 					=> $hosted_ip,
								'hosted_ip_latitude' 			=> $content['latitude'],
								'hosted_ip_longitude'			=> $content['longitude'],
								'hosted_ip_country' 			=> strtoupper($content['countryCode']),
								'hosted_ip_friendly_location'	=> implode(", ", $friendly_location)
							);

							$response = array(
								'status' => 'success',
								'data' => $host_details
							);

						} else {

							$response = array(
								'status' => 'error',
								'msg' => 'IPINFODB Error Message: ' . $content['statusMessage']
							);

						}

					} else {
						
						$response = array(
							'status' => 'error',
							'msg' => 'IPINFODB Error. HTTP Code: ' . $curl_response->headers['Status-Code']
						);

					}

				}
				
			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get WHOIS Information
	-------------------------------------------------- */
		public function getWhois($domain)
		{
			try
			{
				$result = $this->whois->Lookup($domain);
				$registrar = $result['regyinfo']['registrar'];
				$domain_status = $result['regrinfo']['domain']['status'];
				$domain_registered = $result['regrinfo']['domain']['created'];
				$domain_modified = $result['regrinfo']['domain']['changed'];
				$domain_expires = $result['regrinfo']['domain']['expires'];
				$nameservers = $result['regrinfo']['domain']['nserver'];
				$owner_email = (empty($result['regrinfo']['owner']['email']) ? $result['regrinfo']['admin']['email'] : $result['regrinfo']['owner']['email']);
				
				$tmp = "";
				foreach($result['rawdata'] as $line) {
					$line = trim($line);
					$tmp .= $line."\n";
				}
				$tmp = trim($tmp);
				$tmp = strip_tags($tmp);

				$tmp = str_replace("\n", "<br/>", $tmp);
				$tmp = str_replace("<br/><br/><br/>", "<br/><br/>", $tmp);
				$tmp = preg_replace('/\s\s+/', ' ', $tmp);

				$full_whois = $tmp;

				if (is_array($nameservers) && count($nameservers) > 0) {

					$gi = geoip_open(dirname(__FILE__) . "/maxmind_geoip/GeoIP.dat", GEOIP_STANDARD);
					
					$nameservers_final = array();
					foreach ($nameservers as $host => $ip) {
						
						if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
							$ns_ip = $ip;
							$ns_country = strtoupper(geoip_country_code_by_addr($gi, $ns_ip));
						}

						$nameservers_final[] = array(
							'ns_host'		=> $host,
							'ns_ip' 		=> $ns_ip,
							'ns_country' 	=> $ns_country
						);
					}

					geoip_close($gi);

				}

				if (strpos($full_whois, "domain is not supported") !== false) {
					$full_whois = "";					
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'registrar' 		=> $registrar,
						'domain_status' 	=> $domain_status,
						'domain_registered'	=> $domain_registered,
						'domain_modified'	=> $domain_modified,
						'domain_expires'	=> $domain_expires,
						'nameservers'		=> $nameservers_final,
						'owner_email'		=> $owner_email,
						'full_whois'		=> $full_whois
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => 'Failed to Initialize WHOIS Lookup.'
				);
			}
			return $response;
		}

	/* Get Google Indexed Page Data
	-------------------------------------------------- */
		public function getGoogleIndexedPage($domain)
		{
			try
			{
				$callback_url = "http://www.google.com/search?";
				$data = array(
					'q'		=> 'site:' . $domain,
					'hl'	=> 'en'
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//div[@id="resultStats"]')->item(0)->nodeValue;
					$tmp = explode(' ', trim($tmp));
					$google_indexed_page = str_replace(",", "", $tmp[1]);

				} else {
					$google_indexed_page = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'google_indexed_page' => filter_var($google_indexed_page, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Google Inbound Links Data
	-------------------------------------------------- */
		public function getGoogleInboundLinks($domain)
		{
			try
			{
				$callback_url = "http://www.google.com/search?";
				$data = array(
					'q'		=> 'link:' . $domain,
					'hl'	=> 'en'
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//div[@id="resultStats"]')->item(0)->nodeValue;
					$tmp = explode(' ', trim($tmp));
					$google_inbound_links = str_replace(",", "", $tmp[1]);

				} else {
					$google_inbound_links = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'google_inbound_links' => filter_var($google_inbound_links, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Google Pagerank Data
	-------------------------------------------------- */
		public function getGooglePageRank($domain)
		{
			try
			{
				$pageRank = $this->pagerank->getRank($domain);
				$response = array(
					'status' => 'success',
					'data' => array(
						'pagerank' => (int)$pageRank
					)
				);
			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Google Pagespeed Data
	-------------------------------------------------- */
		public function getPageSpeed($domain, $api = "")
		{
			try
			{
				$callback_url = "https://www.googleapis.com/pagespeedonline/v1/runPagespeed?";
				$data = array(
					'url'		=> 'http://' . $domain,
					'key'		=> (empty($api) ? $_SESSION['GOOGLE_API_SERVER_APPS'] : $api),
					'fields' 	=> 'score,pageStats(htmlResponseBytes,textResponseBytes,cssResponseBytes,imageResponseBytes,javascriptResponseBytes,flashResponseBytes,otherResponseBytes)'
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					$content = json_decode($curl_response, true);
					$response = array(
						'status' => 'success',
						'data' => array(
							'pagespeed_score' => (int)$content['score'],
							'pagespeed_stats' => $content['pageStats']
						)
					);

				} else {

					$response = array(
						'status' => 'error',
						'msg' => 'Google API Error. HTTP Code: ' . $curl_response->headers['Status-Code']
					);

				}
			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Yahoo Indexed Page Data
	-------------------------------------------------- */
		public function getYahooIndexedPage($domain)
		{
			try
			{
				$callback_url = "http://search.yahoo.com/search?";
				$data = array(
					'p'	=> 'site:' . $domain
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//span[@id="resultCount"]')->item(0)->nodeValue;
					$yahoo_indexed_page = str_replace(",", "", $tmp);

				} else {
					$yahoo_indexed_page = "0";
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'yahoo_indexed_page' => filter_var($yahoo_indexed_page, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Bing Indexed Page Data
	-------------------------------------------------- */
		public function getBingIndexedPage($domain)
		{
			try
			{
				$callback_url = "http://www.bing.com/search?";
				$data = array(
					'q'	=> 'site:' . $domain
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {

					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//span[@id="count"]')->item(0)->nodeValue;
					$tmp = explode(' ', trim($tmp));
					$bing_indexed_page = str_replace(",", "", $tmp[0]);

				} else {
					$bing_indexed_page = "0";
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'bing_indexed_page' => filter_var($bing_indexed_page, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Bing Inbound Links Data
	-------------------------------------------------- */
		public function getBingInboundLinks($domain)
		{
			try
			{
				$callback_url = "http://www.bing.com/search?";
				$data = array(
					'q'	=> "inbody:$domain -site:$domain"
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//span[@id="count"]')->item(0)->nodeValue;
					$tmp = explode(' ', trim($tmp));
					$bing_inbound_links = str_replace(",", "", $tmp[0]);

				} else {
					$bing_inbound_links = "0";
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'bing_inbound_links' => filter_var($bing_inbound_links, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get SEOmoz Data
	-------------------------------------------------- */
		public function getSeoMoz($domain, $accessid = "", $secret = "")
		{
			try
			{
				$access_id = (empty($accessid) ? $_SESSION['SEOMOZ_API_ACCESSID'] : $accessid);
				$secret_key = (empty($secret) ? $_SESSION['SEOMOZ_API_SECRETKEY'] : $secret);

				$expires = time() + 300;
				$stringToSign = $access_id."\n".$expires;
				$binarySignature = hash_hmac('sha1', $stringToSign, $secret_key, true);
				$urlSafeSignature = base64_encode($binarySignature);

				$callback_url = "http://lsapi.seomoz.com/linkscape/url-metrics/www." . $domain . "?";
				$data = array(
					'Cols'		=> '68719476736',
					'AccessID'	=> $access_id,
					'Expires'	=> $expires,
					'Signature'	=> $urlSafeSignature
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {
					
					$parse_response = json_decode($curl_response, true);
					$domain_authority = $parse_response['pda'];

					$response = array(
						'status' => 'success',
						'data' => array(
							'domain_authority' => (int)round($domain_authority)
						)
					);

				} else {

					$response = array(
						'status' => 'error',
						'msg' => 'SEOMoZ Response Error.'
					);

				}
			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;		
		}

	/* Get SiteAdvisor Rating Data
	-------------------------------------------------- */
		public function getSiteAdvisor($domain)
		{
			try
			{
				$callback_url = "http://www.siteadvisor.com/sites/" . $domain;

				$curl_response = $this->curl->get($callback_url);

				if ($curl_response->headers['Status-Code'] == "200") {

					libxml_use_internal_errors(TRUE);
					$this->dom_doc->loadHTML($curl_response);
					libxml_use_internal_errors(FALSE);
					
					$xpath = new DOMXPath($this->dom_doc);
					$tmp = $xpath->query('/html/body//div[@id="siteVerdict"]//img')->item(0);
					
					if ($tmp->hasAttribute('src')) {
						
						$tmp = $tmp->getAttribute('src');

						if (stripos($tmp, "green") !== false) {
							$siteadvisor_rating = 1;
						} elseif (stripos($tmp, "yellow") !== false) {
							$siteadvisor_rating = 2;
						} elseif (stripos($tmp, "red") !== false) {
							$siteadvisor_rating = 3;
						} else {
							$siteadvisor_rating = 0;
						}
						
					} else {
						$siteadvisor_rating = 0;
					}

				} else {
					$siteadvisor_rating = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'siteadvisor' => (int)$siteadvisor_rating
					)
				);
			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;		
		}

	/* Get Alexa Data
	-------------------------------------------------- */
		public function getAlexa($domain)
		{
			try
			{
				$callback_url = "http://data.alexa.com/data?";
				$data = array(
					'cli'	=> '10',
					'dat'	=> 's',
					'url'	=> $domain
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {

					$xml = simplexml_load_string($curl_response);
					
					$popularity = $xml->xpath('//SD/POPULARITY');
					$links = $xml->xpath('//SD/LINKSIN');
					$dmoz = $xml->xpath('//DMOZ/SITE/CATS/CAT');

					$alexa_rank = $popularity[0]['TEXT'];
					$alexa_inbound_links = $links[0]['NUM'];
					$is_dmoz_listed = (count($dmoz) > 0 ? 1 : 0);

				} else {
					$alexa_rank = 0;
					$alexa_inbound_links = 0;
					$is_dmoz_listed = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'alexa_rank' => filter_var($alexa_rank, FILTER_SANITIZE_NUMBER_INT),
						'alexa_inbound_links' => filter_var($alexa_inbound_links, FILTER_SANITIZE_NUMBER_INT),
						'is_dmoz_listed' => (int)$is_dmoz_listed
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;		
		}

	/* Get Facebook Data
	-------------------------------------------------- */
		public function getFacebookData($domain)
		{
			try
			{
				$callback_url = "https://graph.facebook.com/fql?";
				$data = array(
					'q'	=> "SELECT comment_count, like_count, share_count FROM link_stat WHERE url='$domain'"
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {

					$parse_response = json_decode($curl_response, true);
					$fb_share_count = $parse_response['data'][0]['share_count'];
					$fb_like_count = $parse_response['data'][0]['like_count'];
					$fb_comment_count = $parse_response['data'][0]['comment_count'];

				} else {
					$fb_share_count = 0;
					$fb_like_count = 0;
					$fb_comment_count = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'fb_share_count' => filter_var($fb_share_count, FILTER_SANITIZE_NUMBER_INT),
						'fb_like_count' => filter_var($fb_like_count, FILTER_SANITIZE_NUMBER_INT),
						'fb_comment_count' => filter_var($fb_comment_count, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Twitter Data
	-------------------------------------------------- */
		public function getTwitterData($domain)
		{
			try
			{
				$curl_response_1 = $this->curl->get("http://urls.api.twitter.com/1/urls/count.json?url=" . $domain);
				$curl_response_2 = $this->curl->get("http://urls.api.twitter.com/1/urls/count.json?url=" . $domain);

				if ($curl_response_1->headers['Status-Code'] == "200" || $curl_response_2->headers['Status-Code'] == "200") {

					$parse_response_1 = json_decode($curl_response_1, true);
					$parse_response_2 = json_decode($curl_response_2, true);
					$twitter_count = $parse_response_1['count'] + $parse_response_2['count'];

				} else {
					$twitter_count = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'twitter_count' => filter_var($twitter_count, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get LinkedIn Data
	-------------------------------------------------- */
		public function getLinkedInData($domain)
		{
			try
			{
				$curl_response = $this->curl->get("http://www.linkedin.com/countserv/count/share?format=json&url=" . $domain);

				if ($curl_response->headers['Status-Code'] == "200") {

					$parse_response = json_decode($curl_response, true);
					$linkedin_share_count = $parse_response['count'];

				} else {
					$linkedin_share_count = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'linkedin_share_count' => filter_var($linkedin_share_count, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Delicious Data
	-------------------------------------------------- */
		public function getDeliciousData($domain)
		{
			try
			{
				$curl_response_1 = $this->curl->get("http://feeds.delicious.com/v2/json/urlinfo/data?url=" . $domain);
				$curl_response_2 = $this->curl->get("http://feeds.delicious.com/v2/json/urlinfo/data?url=www." . $domain);

				if ($curl_response_1->headers['Status-Code'] == "200" || $curl_response_2->headers['Status-Code'] == "200") {

					$parse_response_1 = json_decode($curl_response_1, true);
					$parse_response_2 = json_decode($curl_response_2, true);
					$delicious_total_posts = $parse_response_1[0]['total_posts'] + $parse_response_2[0]['total_posts'];

				} else {
					$delicious_total_posts = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'delicious_total_posts' => filter_var($delicious_total_posts, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Google Plus Data
	-------------------------------------------------- */
		public function getGooglePlusData($domain)
		{
			try
			{
				$this->curl->options['CURLOPT_POSTFIELDS'] = '[{ "method" : "pos.plusones.get", "id" : "p", "params" : { "nolog" : true, "id" : "http://' . $domain . '", "source" : "widget", "userId" : "@viewer", "groupId" : "@self" }, "jsonrpc" : "2.0", "key" : "p", "apiVersion" : "v1" }]';
				$this->curl->headers['Content-type'] = 'application/json';

				$curl_response = $this->curl->post("https://clients6.google.com/rpc?key=AIzaSyCKSbrvQasunBoV16zDH9R33D88CeLr9gQ");

				if ($curl_response->headers['Status-Code'] == "200") {

					$parse_response = json_decode($curl_response, true);
					$g_plus_count = $parse_response[0]['result']['metadata']['globalCounts']['count'];

				} else {
					$g_plus_count = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'g_plus_count' => filter_var($g_plus_count, FILTER_SANITIZE_NUMBER_INT)
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Google Safe Browsing Data
	-------------------------------------------------- */
		public function getSafeBrowsingData($domain, $api = "")
		{
			try
			{
				$callback_url = "https://sb-ssl.google.com/safebrowsing/api/lookup?";
				$data = array(
					'client'	=> 'api',
					'apikey'	=> (empty($api) ? $_SESSION['GOOGLE_SAFE_BROWSING_API'] : $api),
					'appver'	=> '1.0',
					'pver'		=> '3.0',
					'url'		=> $domain
				);

				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200" || $curl_response->headers['Status-Code'] == "204") {

					if ($curl_response == "phishing") {
						$google_safe_browsing = 1;
					} elseif ($curl_response == "malware") {
						$google_safe_browsing = 2;
					} elseif ($curl_response == "phishing,malware") {
						$google_safe_browsing = 3;
					} else {
						$google_safe_browsing = 0;
					}

				} else {
					$google_safe_browsing = 0;
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'google_safe_browsing' => (int)$google_safe_browsing
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

	/* Get Web of Trust Data
	-------------------------------------------------- */
		public function getWebOfTrustData($domain, $api = "")
		{
			try
			{
				$callback_url = "http://api.mywot.com/0.4/public_link_json2?";
				$data = array(
					'hosts'		=> $domain . '/',
					'key'	=> (empty($api) ? $_SESSION['WOT_API'] : $api)
				);
				
				$curl_response = $this->curl->get($callback_url . http_build_query($data, '', '&'));

				if ($curl_response->headers['Status-Code'] == "200") {

					$parse_response = json_decode($curl_response, true);

					if ($parse_response[$domain][0]) {
						$component['0'] = implode(",", $parse_response[$domain][0]);
					}
					if ($parse_response[$domain][1]) {
						$component['1'] = implode(",", $parse_response[$domain][1]);
					}
					if ($parse_response[$domain][2]) {
						$component['2'] = implode(",", $parse_response[$domain][2]);
					}
					if ($parse_response[$domain][4]) {
						$component['4'] = implode(",", $parse_response[$domain][4]);
					}
					
					$wot_rating = $component;

				} else {
					$wot_rating = "";
				}

				$response = array(
					'status' => 'success',
					'data' => array(
						'wot_rating' => $wot_rating
					)
				);

			}
			catch (Exception $e)
			{
				$response = array(
					'status' => 'error',
					'msg' => $e->getMessage()
				);
			}
			return $response;
		}

}
?>