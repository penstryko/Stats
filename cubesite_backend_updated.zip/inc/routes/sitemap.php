<?php
header('Content-Type: application/xml');

/* Set Several Values
-------------------------------------------------- */
	$page = ($segments[1] > 0 ? $segments[1] : 'index');
	$limit = 5000;

/* Set Smarty Caching for Listing
-------------------------------------------------- */
	$smarty->setCaching(Smarty::CACHING_LIFETIME_SAVED);
	$smarty->setCacheLifetime('86400'); // One Day of Caching

	$cache_id = 'sitemap|' . $page;
	$template = APP_THEME . "/sitemap.tpl";

/* Query for Sitemap Content if we do not have a cache copy
-------------------------------------------------- */
	if(!$smarty->isCached($template, $cache_id)) {

		/* Prepare Valid Domain Status
		-------------------------------------------------- */				
			$valid_domain_status = array();
			$valid_domain_status[] = 1;

			if ($config['DATA_PRIVACY_UNSAFE'] == "ALLOWED TO ALL") {
				$valid_domain_status[] = 2;
			}

			if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
				$valid_domain_status[] = 0;
			} elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS SAFE") {
				$valid_domain_status[] = 0;
			}

			if (count($valid_domain_status) == 1) {
	            $safe_where_domain = "status = $valid_domain_status[0]";
	            $safe_where_domain_alt = $safe_where_domain . ' &&';
	        } elseif (count($valid_domain_status) == 2) {
	            $safe_where_domain = "status IN ('" . implode("', '", $valid_domain_status) . "')";
	            $safe_where_domain_alt = $safe_where_domain . ' &&';
	        }

		/* Get Data
		-------------------------------------------------- */
			if ($page > 0) {

				$start_id = ($page * $limit) - $limit;
				$end_id = $start_id + $limit;
				$sql = "SELECT domain FROM insights_base WHERE $safe_where_domain_alt id BETWEEN $start_id AND $end_id ORDER BY id ASC";
				$rows = $db->fetch_array($sql);

				$listings = array();
				foreach ($rows as $record) {
					$listings[] = getStatLink($record['domain']);
				}

				$data['listings'] 	= $listings;

				$data['type'] 	= 'listing';

			} else {

				$sql = "SELECT COUNT(id) AS total FROM insights_base";
				if (!empty($safe_where_domain)) {
					$sql = $sql . ' WHERE ' . $safe_where_domain;
				}

				$record = $db->query_first($sql);
				$total_items = $record['total'];
				$total_pages = ceil($total_items / $limit);

				$data['type'] 	= 'index';
				$data['pages'] 	= $total_pages;

			}

		$smarty->assign('data', $data);

	}

$smarty->display($template, $cache_id);
?>