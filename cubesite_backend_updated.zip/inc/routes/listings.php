<?php
/* Generate Data
-------------------------------------------------- */
	generateMenu($smarty);
	generateSiteList($smarty);
	
/* Set Several Values
-------------------------------------------------- */
	$no_value_prefix = array("topsites", "recently-added");

	$action = $segments[0];

	if (in_array($action, $no_value_prefix)) {
		$page = ($segments[1] > 0 ? $segments[1] : 1);
	} else {
		$value = urldecode(trim($db->escape($segments[1])));
		$page = ($segments[2] > 0 ? $segments[2] : 1);
	}

	$valid_max_page = ceil($config['SITE_LISTINGS_TOTAL_ITEMS'] / $config['SITE_PER_PAGE_LISTINGS']);

/* Set Smarty Caching for Listing
-------------------------------------------------- */
	if ($config['CACHE_STATUS'] == "ENABLED") {
		
		$smarty->setCaching(Smarty::CACHING_LIFETIME_SAVED);

		if ($action == "recently-added")
		{
			$cache_duration = 900;
		}
		else
		{
			$cache_duration = $config['LISTINGS_CACHING'];		
		}

		$smarty->setCacheLifetime($cache_duration);
	}

	$cache_id[] = $action;
	if (!empty($value) && !in_array($action, $no_value_prefix)) {
		$cache_id[] = md5($value);
	}
	$cache_id[] = $page;

	$cache_id = implode("|", $cache_id);
	$template = APP_THEME . "/listings.tpl";

/* Query for Listing Content if we do not have a cache copy
-------------------------------------------------- */
	if(!$smarty->isCached($template, $cache_id) || $config['CACHE_STATUS'] == "DISABLED") {

		/* Populate Valid Actions
		-------------------------------------------------- */
			$valid_actions 		= array();
			$valid_actions[] 	= $config['PREFIX_TAG'];
			$valid_actions[] 	= $config['PREFIX_EMAIL'];
			$valid_actions[] 	= $config['PREFIX_HOSTED_IP'];
			$valid_actions[] 	= $config['PREFIX_HOSTED_COUNTRY'];
			$valid_actions[] 	= $config['PREFIX_NAMESERVER'];
			$valid_actions[] 	= $config['PREFIX_REGISTRAR'];
			$valid_actions[] 	= $config['PREFIX_EXTENSION'];
			$valid_actions[] 	= $config['PREFIX_PAGERANK'];
			$valid_actions[] 	= $config['PREFIX_ADSENSE'];
			$valid_actions[] 	= "topsites";
			$valid_actions[] 	= "recently-added";

		/* Validate Value
		-------------------------------------------------- */
			switch ($action) {

				case $config['PREFIX_TAG']:
					$value_non_dash = correctTag($value);
					$value = str_replace(" ", "-", $value_non_dash);
					break;

				case $config['PREFIX_EMAIL']:
					$value = (filter_var($value, FILTER_VALIDATE_EMAIL) ? $value : '');
					break;

				case $config['PREFIX_HOSTED_IP']:
					$value = (filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? $value : '');
					break;

				case $config['PREFIX_HOSTED_COUNTRY']:
					$value = strtoupper($value);
					$value = (preg_match('/[A-Z]{2}/', $value)) ? $value : '' ;
					break;

				case $config['PREFIX_NAMESERVER']:
					$value = strtolower($value);
					break;

				case $config['PREFIX_REGISTRAR']:
					break;

				case $config['PREFIX_EXTENSION']:
					$value = strtolower(trim($value, '.'));
					break;

				case $config['PREFIX_PAGERANK']:
					$value = (int)$value;
					$value = ($value > 10 || $value < 0) ? 0 : $value ;
					break;

				case $config['PREFIX_ADSENSE']:
					$value = (preg_match('/pub-[0-9]{16,16}/si', $value)) ? $value : '' ;
					break;

				case "topsites":
					break;

				case "recently-added":
					break;

			}

		if (!in_array($action, $valid_actions) || $page > $valid_max_page || (empty($value) && $action != $config['PREFIX_PAGERANK'] && !in_array($action, $no_value_prefix))) {

			header("HTTP/1.0 404 Not Found");
			$page_title = $lang["page_not_found"];
			$cache_id = "404_error";
			$template = APP_THEME . "/404.tpl";

		} else {

			/* Prepare Valid Domain Status
			-------------------------------------------------- */				
				$valid_domain_status = array();
				$valid_domain_status[] = 1;

				if ($config['DATA_PRIVACY_UNSAFE'] == "ALLOWED TO ALL") {
					$valid_domain_status[] = 2;
				}

				if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
					$valid_domain_status[] = 0;
				} elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS SAFE") {
					$valid_domain_status[] = 0;
				}

				if (count($valid_domain_status) == 1) {
		            $safe_where_domain = "&& IB.status = $valid_domain_status[0]";
		        } elseif (count($valid_domain_status) == 2) {
		            $safe_where_domain = "&& IB.status IN ('" . implode("', '", $valid_domain_status) . "')";
		        }

			/* Prepare SQL Queries and Several Values
			-------------------------------------------------- */
				switch ($action) {

					case $config['PREFIX_TAG']:

						/* Prepare Valid Keyword Status
						-------------------------------------------------- */							
							$valid_keyword_status = array();
							$valid_keyword_status[] = 1;

							if ($config['DATA_PRIVACY_UNSAFE'] != "BLOCKED TO ALL") {
								$valid_keyword_status[] = 2;
							}

							if ($config['MANUAL_APPROVAL_KEYWORD'] == "DISABLED") {
								$valid_keyword_status[] = 0;
							} elseif ($config['MANUAL_APPROVAL_KEYWORD'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] != "BLOCKED TO ALL") {
								$valid_keyword_status[] = 0;
							}

							if (count($valid_keyword_status) == 1) {
					            $safe_where_keyword = "&& T.status = $valid_keyword_status[0]";
					        } elseif (count($valid_keyword_status) == 2) {
					            $safe_where_keyword = "&& T.status IN ('" . implode("', '", $valid_keyword_status) . "')";
					        }

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												tags T
											INNER JOIN
												insights_tags IT ON IT.tag_id = T.id
											INNER JOIN
												insights_base IB ON IB.id = IT.domain_id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												T.slug = '$value' $safe_where_keyword
											ORDER BY
												google_pr DESC";

						$info_sql 		= "SELECT 
												T.status AS status,
												B.id AS blocking_exist
											FROM 
												tags T
											LEFT JOIN
												blockings B ON B.data = '$value_non_dash' && B.type = 'KEYWORDS' 
											WHERE
												T.slug = '$value'";

						break;

					case $config['PREFIX_EMAIL']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												owner_emails OE
											INNER JOIN
												insights_base IB ON IB.owner_email_id = OE.id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												OE.email = '$value'
											ORDER BY
												google_pr DESC";

						break;

					case $config['PREFIX_HOSTED_IP']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												hosted_ips HI
											INNER JOIN
												insights_base IB ON IB.hosted_ip_id = HI.id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												HI.ip = '$value'
											ORDER BY
												google_pr DESC";

						$info_sql 		= "SELECT 
												ip, latitude, longitude, friendly_location,
												C.name AS country 
											FROM 
												hosted_ips HI
											INNER JOIN
												country C ON HI.country = C.id 
											WHERE
												ip = '$value'";

						break;

					case $config['PREFIX_HOSTED_COUNTRY']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												insights_base IB
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											INNER JOIN
												country C ON C.id = IB.hosted_country
											WHERE
												IB.hosted_country = '$value' $safe_where_domain
											ORDER BY
												google_pr DESC";

						$info_sql 		= "SELECT 
												name
											FROM 
												country
											WHERE
												id = '$value'";

						break;

					case $config['PREFIX_NAMESERVER']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												nameservers N
											INNER JOIN
												insights_nameservers INS ON INS.nameserver_id = N.id
											INNER JOIN
												insights_base IB ON IB.id = INS.domain_id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												N.ns_host = '$value'
											ORDER BY
												google_pr DESC";

						$info_sql 		= "SELECT 
												N.ns_ip AS ip,
												C.name AS country 
											FROM 
												nameservers N
											INNER JOIN
												country C ON C.id = N.ns_country 
											WHERE
												N.ns_host = '$value'";

						break;

					case $config['PREFIX_REGISTRAR']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												registrars R
											INNER JOIN
												insights_base IB ON IB.registrar_id = R.id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												R.slug = '$value'
											ORDER BY
												google_pr DESC";

						$info_sql 		= "SELECT 
												registrar 
											FROM 
												registrars
											WHERE
												slug = '$value'";

						break;

					case $config['PREFIX_EXTENSION']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												insights_base IB 
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												extension = '$value' $safe_where_domain
											ORDER BY
												google_pr DESC";

						break;

					case $config['PREFIX_PAGERANK']:

						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												insights_base IB
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												google_pr = '$value' $safe_where_domain
											ORDER BY
												average_rating DESC";

						break;

					case $config['PREFIX_ADSENSE']:
						
						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM
												adsense A
											INNER JOIN
												insights_base IB ON IB.adsense_id = A.id $safe_where_domain
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												A.pub = '$value'
											ORDER BY
												google_pr DESC";

						break;

					case "topsites":
						
						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												insights_base IB
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												alexa_rank > 0 $safe_where_domain
											ORDER BY
												alexa_rank ASC";

						break;

					case "recently-added":

						/* Cron Listing Status
					    -------------------------------------------------- */
					        if ($config['LISTINGS_CRON_DOMAIN'] == "DISABLED") {
					            $where_cron = "&& is_cron = '0'";
					        }
						
						$element_sql 	= "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												insights_base IB
											INNER JOIN
												insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
											WHERE
												added_date = updated_date $where_cron $safe_where_domain
											ORDER BY
												added_date DESC";

						break;

				}

			$current_index = $config['SITE_PER_PAGE_LISTINGS'] * ($page - 1);
			$offset_rows = $config['SITE_PER_PAGE_LISTINGS'] + 1;

			$sql = $element_sql . " LIMIT " . $current_index . ", " . $offset_rows;
			$rows = $db->query($sql);
			$total_items = $db->affected_rows;

			if(empty($total_items)) {

				header("HTTP/1.0 404 Not Found");
				$page_title = $lang["page_not_found"];
				$cache_id = "404_error";
				$template = APP_THEME . "/404.tpl";

			} else {

				/* Run SQL to get Additional Information
				-------------------------------------------------- */
					if (!empty($info_sql)) {
						$info_record = $db->query_first($info_sql);
					}

				/* Page Title / Data Heading / Additional Info
				-------------------------------------------------- */
					switch ($action) {

						case $config['PREFIX_TAG']:
							
							$data['listing_type'] = "tag";
							$data['listing_value'] = $value;

							$data['data_heading'] = sprintf($lang["listing"]["heading"]["tag"], ucwords($value_non_dash));
							$page_title = sprintf($lang["listing"]["title"]["tag"], ucwords($value_non_dash));

							if ( ($info_record['status'] == "2" || $info_record['blocking_exist'] > 0 && $config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO SEARCH ENGINES") || ($info_record['status'] == "0" && $config['MANUAL_APPROVAL_KEYWORD'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS UNSAFE") ) {
								$smarty->assign('is_unsafe', true);
								$data['meta'][] = "<META NAME='ROBOTS' CONTENT='NOINDEX, NOFOLLOW'>";
							}

							break;

						case $config['PREFIX_EMAIL']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["email"], $value);
							$page_title = sprintf($lang["listing"]["title"]["email"], $value);
							break;

						case $config['PREFIX_HOSTED_IP']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["ip"], $value);
							$page_title = sprintf($lang["listing"]["title"]["ip"], $value);
							$data['additional_info'] = sprintf($lang["listing"]["info"]["ip"], $info_record['ip'], $info_record['ip'], $info_record['latitude'], $info_record['longitude'], $info_record['country'], $info_record['friendly_location']);
							break;

						case $config['PREFIX_HOSTED_COUNTRY']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["country"], $info_record['name']);
							$page_title = sprintf($lang["listing"]["title"]["country"], $info_record['name']);
							break;

						case $config['PREFIX_NAMESERVER']:
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["nameserver"], $value);
							$page_title = sprintf($lang["listing"]["title"]["nameserver"], $value);
							$data['additional_info'] = sprintf($lang["listing"]["info"]["nameserver"], $value, $info_record['ip'], $info_record['country']);
							break;

						case $config['PREFIX_REGISTRAR']:
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["registrar"], $info_record['registrar']);
							$page_title = sprintf($lang["listing"]["title"]["registrar"], $info_record['registrar']);
							break;

						case $config['PREFIX_EXTENSION']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["extension"], $value);
							$page_title = sprintf($lang["listing"]["title"]["extension"], $value);
							break;

						case $config['PREFIX_PAGERANK']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["pagerank"], $value);
							$page_title = sprintf($lang["listing"]["title"]["pagerank"], $value);
							break;

						case $config['PREFIX_ADSENSE']:							
							$data['data_heading'] = sprintf($lang["listing"]["heading"]["adsense"], $value);
							$page_title = sprintf($lang["listing"]["title"]["adsense"], $value);
							break;

						case "topsites":							
							$data['data_heading'] = $lang["listing"]["heading"]["topsites"];
							$page_title = $lang["listing"]["heading"]["topsites"];
							break;

						case "recently-added":							
							$data['data_heading'] = $lang["listing"]["heading"]["newsites"];
							$page_title = $lang["listing"]["heading"]["newsites"];
							break;

					}

				/* Process Listing Items
				-------------------------------------------------- */
					if (in_array($action, $no_value_prefix)) {
						$paginate_url = APP_BASE_URI . $action;
					} else {
						$paginate_url = APP_BASE_URI . $action . '/' . $value;
					}

					$next_page = ($total_items > $config['SITE_PER_PAGE_LISTINGS']) ? TRUE : FALSE ;
					$paginate = array(
						'current_page' => $page,
						'url' => $paginate_url,
						'next_page' => $next_page
					);
					$data['pagination'] = TRUE;
					$data['pagination_data'] = $paginate;

					$listing_data = array();
					$i = 0;
					while ($record = $db->fetch($rows)) {

						$i++;

						$worth = $config['DEFAULT_CURRENCY_SYMBOL'] . ' ' . number_format($record['estimated_value'] * $config['DEFAULT_CURRENCY_RATE'], 2);
						$stat_link = getStatLink($record['domain']);

						$listing_data[] = array(
							'domain' => $record['domain'],
							'stat_link' => $stat_link,
							'rating' => $record['average_rating'],
							'title' => stripslashes(html_entity_decode($record['title'], ENT_QUOTES, 'UTF-8')),
							'description' => stripslashes(html_entity_decode($record['description'], ENT_QUOTES, 'UTF-8')),
							'worth' => $worth,
							'pagerank' => $record['google_pr'],
							'alexa_rank' => number_format($record['alexa_rank'])
						);

						if ($i == $config['SITE_PER_PAGE_LISTINGS']) {
							break;
						}

					}

					$data['listing_show'] = TRUE;
					$data['listing_data'] = $listing_data;
					
				/* Meta Data
				-------------------------------------------------- */
					if ($page > 1) {
						$canonical_page = "$page/";
					}

					if (in_array($action, $no_value_prefix)) {
						$data['meta'][] = "<link rel='canonical' href='$config[SITE_ADDRESS]/$action/$canonical_page' />";
					} else {
						$data['meta'][] = "<link rel='canonical' href='$config[SITE_ADDRESS]/$action/$value/$canonical_page' />";
					}

					if ($next_page) {
						$canonical_next_page = $page + 1;
						if (in_array($action, $no_value_prefix)) {
							$data['meta'][] = "<link rel='next' href='$config[SITE_ADDRESS]/$action/$canonical_next_page/' />";
						} else {
							$data['meta'][] = "<link rel='next' href='$config[SITE_ADDRESS]/$action/$value/$canonical_next_page/' />";
						}
					}

					if ($page > 1) {
						$canonical_pre_page = $page - 1;
						if (in_array($action, $no_value_prefix)) {
						} else {
							$data['meta'][] = "<link rel='prev' href='$config[SITE_ADDRESS]/$action/$canonical_pre_page/' />";
						}
					}

			}

		}

		$data['page_title'] = $page_title . sprintf(' %s ', $config['TITLEBAR_SEPERATOR']) . $config['SITE_TITLE'];

		$smarty->assign('data', $data);

	}

$smarty->display($template, $cache_id);
?>