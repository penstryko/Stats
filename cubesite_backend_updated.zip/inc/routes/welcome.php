<?php
/* Generate Data
-------------------------------------------------- */
	generateMenu($smarty);
	generateSiteList($smarty);

/* Process
-------------------------------------------------- */
	$data['page_title'] = $config['SITE_TITLE'] . sprintf(' %s ', $config['TITLEBAR_SEPERATOR']) . $config['SITE_TAGLINE'];
	$data['meta'][] = "<link rel='canonical' href='$config[SITE_ADDRESS]/' />";
	$smarty->assign('data', $data);

/* Display
-------------------------------------------------- */
	$smarty->display(APP_THEME . '/welcome.tpl');
?>