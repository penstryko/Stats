<?php
/* Generate Data
-------------------------------------------------- */
	generateMenu($smarty);
	generateSiteList($smarty);
	
/* Set Smarty Caching for Pages
-------------------------------------------------- */
	if ($config['CACHE_STATUS'] == "ENABLED") {
		$smarty->setCaching(Smarty::CACHING_LIFETIME_SAVED);
		$smarty->setCacheLifetime($config['PAGE_CACHING']);
	}

	$sef_title = $db->escape($segments[1]);

	$cache_id = "page|" . $sef_title;
	$template = APP_THEME . "/page.tpl";

/* Query for Page Content if we do not have a cache copy
-------------------------------------------------- */
	if(!$smarty->isCached($template, $cache_id) || $config['CACHE_STATUS'] == "DISABLED") {

		$sql = "SELECT * FROM pages WHERE sef_title = '$sef_title' && redirect_link = ''";
		$record = $db->query_first($sql);
		
		if(empty($record['id'])) {

			header("HTTP/1.0 404 Not Found");
			$page_title = $lang["page_not_found"];
			$cache_id = "404_error";
			$template = APP_THEME . "/404.tpl";

		} else {

			$title = html_entity_decode($record['title']);
			$details = stripslashes(html_entity_decode($record['details'], ENT_QUOTES, 'UTF-8'));

			/* Check Short Code [CONTACT_FORM] in Content Details to display its correct output
			-------------------------------------------------- */
				$short_code = "[CONTACT_FORM]";
				if (strpos($details, '[CONTACT_FORM]')) {
					$smarty->assign('contact_form', TRUE);
				}
				$details = str_replace($short_code, '', $details);

			$page_title = $title;
			$data['content_title'] = $title;
			$data['content_details'] = $details;

			$data['meta'][] = "<link rel='canonical' href='$config[SITE_ADDRESS]/$config[PREFIX_PAGE]/$record[sef_title]/' />";

		}

		$data['page_title'] = $page_title . sprintf(' %s ', $config['TITLEBAR_SEPERATOR']) . $config['SITE_TITLE'];

		$smarty->assign('data', $data);

	}

/* Contact Form Processing
-------------------------------------------------- */
	if ($config['RECAPTCHA_STATUS'] == "ENABLED") {
		require_once $current_dir . '/lib/classes/recaptcha/recaptchalib.php';
	}

	if($_POST['cmd'] == "process_form") {

		$full_name = trim(stripslashes($_POST['full_name']));
		$email = trim(stripslashes($_POST['email']));
		$subject = trim(stripslashes($_POST['subject']));
		$message = trim(stripslashes($_POST['message']));

		if ($config['RECAPTCHA_STATUS'] == "ENABLED") {
			$resp = recaptcha_check_answer($config['RECAPTCHA_PRIVATE_KEY'], $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
		}

		if (empty($full_name)) {
			$response[] = array(
				'type' => 'error',
				'text' => $lang["contact_form"]["error"]["name"]
				);
		} elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$response[] = array(
				'type' => 'error',
				'text' => $lang["contact_form"]["error"]["email"]
				);
		} elseif (empty($subject)) {
			$response[] = array(
				'type' => 'error',
				'text' => $lang["contact_form"]["error"]["subject"]
				);
		} elseif (empty($message)) {
			$response[] = array(
				'type' => 'error',
				'text' => $lang["contact_form"]["error"]["message"]
				);
		} elseif ($config['RECAPTCHA_STATUS'] == "ENABLED" && !$resp->is_valid) {
			$response[] = array(
				'type' => 'error',
				'text' => $lang["contact_form"]["error"]["security"]
				);
		} else {

			$host = strtoupper(parse_url($config['SITE_ADDRESS'], PHP_URL_HOST));
			$subject = "$subject - $host";
			$mailheaders = "From: $full_name<$email>\n";
			$success = mail($config['ADMIN_EMAIL'], $subject, stripslashes($message), $mailheaders);

			if ($success) {
				$smarty->assign('contact_form', FALSE);
				$response[] = array(
					'type' => 'success',
					'text' => $lang["contact_form"]["message"]["success"]
					);
			} else {
				$response[] = array(
					'type' => 'error',
					'text' => $lang["contact_form"]["message"]["failed"]
					);
			}

		}

		$response = array('method' => 'static', 'response' => $response);
		$smarty->assign("response_data", $response);

	}

	if ($response['response'][0]['type'] == "error") {
		$smarty->assign('contact_form', TRUE);
	}
	if (($response['response'][0]['type'] == "error" || $_POST['cmd'] != "process_form") && $config['RECAPTCHA_STATUS'] == "ENABLED") {
		$smarty->assign("recaptcha", recaptcha_get_html($config['RECAPTCHA_PUBLIC_KEY']), TRUE);
	}

$smarty->display($template, $cache_id);
?>