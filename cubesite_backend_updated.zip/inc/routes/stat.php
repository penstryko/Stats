<?php
/* Generate Data
-------------------------------------------------- */
	generateMenu($smarty);
	
/* Set Smarty Caching for Domain Stat
-------------------------------------------------- */
	if ($config['CACHE_STATUS'] == "ENABLED") {
		$smarty->setCaching(Smarty::CACHING_LIFETIME_SAVED);
		$smarty->setCacheLifetime($config['STATS_CACHING']);
	}

	$cache_id = "stats|" . $segments[1];
	$template = APP_THEME . "/stat.tpl";

/* Query for Stat Content if we do not have a cache copy
-------------------------------------------------- */
	if(!$smarty->isCached($template, $cache_id) || $config['CACHE_STATUS'] == "DISABLED") {

		/* Prepare Valid Domain / Keyword Status
		-------------------------------------------------- */			
			$valid_domain_status = $valid_keyword_status = array();
			$valid_domain_status[] = $valid_keyword_status[] = 1;

			if ($config['DATA_PRIVACY_UNSAFE'] != "BLOCKED TO ALL") {
				$valid_domain_status[] = $valid_keyword_status[] = 2;
			}

			if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
				$valid_domain_status[] = 0;
			} elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] != "BLOCKED TO ALL") {
				$valid_domain_status[] = 0;
			}

			if ($config['MANUAL_APPROVAL_KEYWORD'] == "DISABLED") {
				$valid_keyword_status[] = 0;
			} elseif ($config['MANUAL_APPROVAL_KEYWORD'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] != "BLOCKED TO ALL") {
				$valid_keyword_status[] = 0;
			}

			if (count($valid_domain_status) == 1) {
	            $safe_where_domain = "IB.status = $valid_domain_status[0] &&";
	        } elseif (count($valid_domain_status) == 2) {
	            $safe_where_domain = "IB.status IN ('" . implode("', '", $valid_domain_status) . "') &&";
	        }

	        if (count($valid_keyword_status) == 1) {
	            $safe_where_keyword = "&& T.status = $valid_keyword_status[0]";
	        } elseif (count($valid_domain_status) == 2) {
	            $safe_where_keyword = "&& T.status IN ('" . implode("', '", $valid_keyword_status) . "')";
	        }

		/* Get Stat Record
		-------------------------------------------------- */
			$sql = "SELECT
						IB.id AS id,
						domain, extension, is_subdomain, status, average_rating, added_datetime, updated_datetime, hosted_ip_id, domain_status, domain_registered, domain_modified, domain_expires, daily_unique_visits, daily_page_views, income_per_day, estimated_value, google_indexed_page, google_inbound_links, google_pr, google_pagespeed, google_pagespeed_stats, yahoo_indexed_page, bing_indexed_page, bing_inbound_links, alexa_rank, alexa_inbound_links, seomoz_domain_authority, is_dmoz_listed, fb_share_count, fb_like_count, fb_comment_count, twitter_count, linkedin_share_count, delicious_total_posts, g_plus_count, google_safe_browsing, wot_rating, siteadvisor_rating, inpage_analysis,						
						IM.page_title AS page_title,
						IM.meta_description AS meta_description,
						IFW.full_whois AS full_whois,
						IH.data AS headers,
						ID.data AS dns_records,
						OE.email AS owner_email,
						R.registrar AS registrar,
						R.slug AS registrar_slug,
						A.pub AS adsense_pub_id,
						HI.ip AS hosted_ip,
						HI.latitude AS hosted_ip_latitude,
						HI.longitude AS hosted_ip_longitude,
						HI.country AS hosted_ip_country,
						HI.friendly_location AS hosted_ip_friendly_location,
						C.name AS hosted_ip_full_country,
						B.data AS blocked_domain
					FROM 
						insights_base IB 
					LEFT JOIN
						insights_meta IM ON IB.id = IM.domain_id 
					LEFT JOIN
						insights_full_whois IFW ON IB.id = IFW.domain_id 
					LEFT JOIN
						insights_header IH ON IB.id = IH.domain_id 
					LEFT JOIN
						insights_dns ID ON IB.id = ID.domain_id 
					LEFT JOIN
						owner_emails OE ON OE.id = IB.owner_email_id
					LEFT JOIN
						registrars R ON R.id = IB.registrar_id 
					LEFT JOIN
						adsense A ON A.id = IB.adsense_id 
					LEFT JOIN
						hosted_ips HI ON HI.id = IB.hosted_ip_id 
					LEFT JOIN
						country C ON C.id = HI.country 
					LEFT JOIN
						blockings B ON B.data = IB.domain && B.type = 'DOMAINS'
					WHERE
						$safe_where_domain IB.domain = '" . $db->escape($segments[1]) . "'";

			$record = $db->query_first($sql);

		/* Get More Data
		-------------------------------------------------- */
			if(empty($record['id']) || ($config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO ALL" && !empty($record['blocked_domain']))) {

				header("HTTP/1.0 404 Not Found");
				$page_title = $lang["page_not_found"];
				$cache_id = "404_error";
				$template = APP_THEME . "/404.tpl";

				generateSiteList($smarty);

			} else {

				/* Process Stat Record
				-------------------------------------------------- */
					$data['stat']['domain'] 					= $record['domain'];
					$data['stat']['extension'] 					= $record['extension'];
					$data['stat']['is_subdomain'] 				= ($record['is_subdomain'] == "1") ? true : false ;
					$data['stat']['rating'] 					= number_format($record['average_rating'], 2);
					$data['stat']['added_datetime'] 			= $record['added_datetime'];
					$data['stat']['updated_datetime'] 			= $record['updated_datetime'];
					$data['stat']['page_title'] 				= html_entity_decode($record['page_title'], ENT_QUOTES, 'UTF-8');
					$data['stat']['meta_description'] 			= html_entity_decode($record['meta_description'], ENT_QUOTES, 'UTF-8');
					$data['stat']['full_whois'] 				= html_entity_decode($record['full_whois'], ENT_QUOTES, 'UTF-8');
					$data['stat']['headers'] 					= json_decode($record['headers'], true);
					$data['stat']['dns_records'] 				= json_decode($record['dns_records'], true);
					$data['stat']['domain_whois_status'] 		= json_decode($record['domain_whois_status'], true);
					$data['stat']['domain_registered'] 			= $record['domain_registered'];
					$data['stat']['domain_modified'] 			= $record['domain_modified'];
					$data['stat']['domain_expires'] 			= $record['domain_expires'];
					$data['stat']['daily_unique_visits'] 		= number_format($record['daily_unique_visits']);
					$data['stat']['daily_page_views'] 			= number_format($record['daily_page_views']);
					$data['stat']['income_per_day'] 			= $config['DEFAULT_CURRENCY_SYMBOL'] . " " . number_format($record['income_per_day'] * $config['DEFAULT_CURRENCY_RATE'], 2);
					$data['stat']['estimated_value'] 			= $config['DEFAULT_CURRENCY_SYMBOL'] . " " . number_format($record['estimated_value'] * $config['DEFAULT_CURRENCY_RATE'], 2);
					$data['stat']['owner_email'] 				= $record['owner_email'];
					$data['stat']['registrar'] 					= $record['registrar'];
					$data['stat']['registrar_slug'] 			= $record['registrar_slug'];
					$data['stat']['adsense_pub_id'] 			= $record['adsense_pub_id'];
					$data['stat']['hosted_ip_id'] 				= $record['hosted_ip_id'];
					$data['stat']['hosted_ip'] 					= $record['hosted_ip'];
					$data['stat']['hosted_ip_latitude'] 		= $record['hosted_ip_latitude'];
					$data['stat']['hosted_ip_longitude'] 		= $record['hosted_ip_longitude'];
					$data['stat']['hosted_ip_country'] 			= $record['hosted_ip_country'];
					$data['stat']['hosted_ip_full_country'] 	= $record['hosted_ip_full_country'];
					$data['stat']['hosted_ip_location'] 		= $record['hosted_ip_friendly_location'];
					$data['stat']['google_indexed_page'] 		= number_format($record['google_indexed_page']);
					$data['stat']['google_inbound_links'] 		= number_format($record['google_inbound_links']);
					$data['stat']['google_pr'] 					= $record['google_pr'];
					$data['stat']['google_pagespeed'] 			= $record['google_pagespeed'];
					$data['stat']['google_pagespeed_stats'] 	= json_decode($record['google_pagespeed_stats'], true);
					
					if (!empty($data['stat']['google_pagespeed_stats'])) {
						arsort($data['stat']['google_pagespeed_stats']);
					}

					$data['stat']['yahoo_indexed_page'] 		= number_format($record['yahoo_indexed_page']);
					$data['stat']['bing_indexed_page'] 			= number_format($record['bing_indexed_page']);
					$data['stat']['bing_inbound_links'] 		= number_format($record['bing_inbound_links']);
					$data['stat']['alexa_rank'] 				= number_format($record['alexa_rank']);
					$data['stat']['alexa_inbound_links'] 		= number_format($record['alexa_inbound_links']);
					$data['stat']['seomoz_domain_authority'] 	= $record['seomoz_domain_authority'];
					$data['stat']['dmoz'] 						= $record['is_dmoz_listed'];
					$data['stat']['fb_share_count'] 			= number_format($record['fb_share_count']);
					$data['stat']['fb_like_count'] 				= number_format($record['fb_like_count']);
					$data['stat']['fb_comment_count'] 			= number_format($record['fb_comment_count']);
					$data['stat']['twitter_count'] 				= number_format($record['twitter_count']);
					$data['stat']['linkedin_share_count'] 		= number_format($record['linkedin_share_count']);
					$data['stat']['delicious_total_posts'] 		= number_format($record['delicious_total_posts']);
					$data['stat']['g_plus_count'] 				= number_format($record['g_plus_count']);
					$data['stat']['google_safe_browsing'] 		= $record['google_safe_browsing'];
					$data['stat']['inpage_analysis'] 			= json_decode($record['inpage_analysis'], true);
					
					$wot_rating = json_decode($record['wot_rating'], true);
					if (is_array($wot_rating)) {
						foreach ($wot_rating as $k => $v) {
							$v = explode(",", $v);
							$data['stat']['wot_rating'][$k] = array(
								'r' => (int)$v[0],
								'c' => (int)$v[1]
								);
						}
					}

					$data['stat']['siteadvisor_rating'] 		= $record['siteadvisor_rating'];

				/* Get and Process Tags
				-------------------------------------------------- */
					$sql_tag = "SELECT 
									T.tag AS tag,
									T.slug AS tag_slug,
									T.status AS status,
									B.id AS blocking_exist
								FROM 
									tags T
								INNER JOIN
									insights_tags IT ON T.id = IT.tag_id && IT.domain_id = '$record[id]' $safe_where_keyword
								LEFT JOIN
									blockings B ON B.data = T.tag && B.type = 'KEYWORDS'";

					$rows_tag = $db->fetch_array($sql_tag);

					foreach($rows_tag as $tag){

						if ( ($tag['status'] == "2" || !empty($tag['blocking_exist']) && $config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO SEARCH ENGINES") || ($tag['status'] == "0" && $config['MANUAL_APPROVAL_KEYWORD'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS UNSAFE") ) {
							$detected_unsafe = true;
						}

						$data['stat']['tags'][] = array(
							'title' 	=> $tag['tag'],
							'slug' 		=> $tag['tag_slug']
						);

					}

				/* Get and Process Nameservers
				-------------------------------------------------- */
					$sql_nameserver = "SELECT 
										N.ns_host AS host,
										N.ns_ip AS ip,
										N.ns_country AS country_code,
										C.name AS country_name
									FROM 
										nameservers N
									INNER JOIN insights_nameservers INS ON N.id = INS.nameserver_id && INS.domain_id = '$record[id]' 
									INNER JOIN country C ON C.id = N.ns_country";

					$rows_nameserver = $db->fetch_array($sql_nameserver);

					foreach($rows_nameserver as $nameserver){
						$data['stat']['nameservers'][] = array(
							'host' 			=> $nameserver['host'],
							'ip' 			=> $nameserver['ip'],
							'country_code' 	=> $nameserver['country_code'],
							'country_name' 	=> $nameserver['country_name']
						);
					}

				/* Get Domains Hosted
				-------------------------------------------------- */
					$hosted_sql = "SELECT 
										domain, average_rating, estimated_value, google_pr, alexa_rank,
										IM.page_title AS title, IM.meta_description AS description 
									FROM 
										insights_base IB 
									INNER JOIN
										insights_meta IM ON IB.id = IM.domain_id && IM.page_title != '' 
									WHERE
										$safe_where_domain IB.id != '$record[id]' && hosted_ip_id = '$record[hosted_ip_id]'
									ORDER BY
										google_pr DESC
									LIMIT 5";

					$hosted_rows = $db->fetch_array($hosted_sql);

					foreach($hosted_rows as $hosted_record){

						$worth = $config['DEFAULT_CURRENCY_SYMBOL'] . ' ' . number_format($hosted_record['estimated_value'] * $config['DEFAULT_CURRENCY_RATE'], 2);
						$stat_link = getStatLink($hosted_record['domain']);

						$data['stat']['same_host'][] = array(
							'domain' => $hosted_record['domain'],
							'stat_link' => $stat_link,
							'rating' => $hosted_record['average_rating'],
							'title' => stripslashes(html_entity_decode($hosted_record['title'], ENT_QUOTES, 'UTF-8')),
							'description' => stripslashes(html_entity_decode($hosted_record['description'], ENT_QUOTES, 'UTF-8')),
							'worth' => $worth,
							'pagerank' => $hosted_record['google_pr'],
							'alexa_rank' => number_format($hosted_record['alexa_rank'])
						);

					}

				/* Get Similarly Ranked Websites
				-------------------------------------------------- */
					$similarly_ranked_sql = "SELECT 
												domain, average_rating, estimated_value, google_pr, alexa_rank,
												IM.page_title AS title, IM.meta_description AS description
											FROM 
												insights_base IB 
											INNER JOIN
												insights_meta IM ON IB.id = IM.domain_id && IM.page_title != '' 
											WHERE
												$safe_where_domain IB.id != '$record[id]' && alexa_rank > $record[alexa_rank]
											ORDER BY
												alexa_rank ASC
											LIMIT 5";

					$similarly_ranked_rows = $db->fetch_array($similarly_ranked_sql);

					foreach($similarly_ranked_rows as $similarly_ranked_record){

						$worth = $config['DEFAULT_CURRENCY_SYMBOL'] . ' ' . number_format($similarly_ranked_record['estimated_value'] * $config['DEFAULT_CURRENCY_RATE'], 2);
						$stat_link = getStatLink($similarly_ranked_record['domain']);

						$data['stat']['similar_ranked'][] = array(
							'domain' => $similarly_ranked_record['domain'],
							'stat_link' => $stat_link,
							'rating' => $similarly_ranked_record['average_rating'],
							'title' => stripslashes(html_entity_decode($similarly_ranked_record['title'], ENT_QUOTES, 'UTF-8')),
							'description' => stripslashes(html_entity_decode($similarly_ranked_record['description'], ENT_QUOTES, 'UTF-8')),
							'worth' => $worth,
							'pagerank' => $similarly_ranked_record['google_pr'],
							'alexa_rank' => number_format($similarly_ranked_record['alexa_rank'])
						);

					}

				/* Detecting UNSAFE
				-------------------------------------------------- */
					if ($record['status'] == "2" || !empty($record['blocked_domain']) && $config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO SEARCH ENGINES") {
						$detected_unsafe = true;
					}

					if ($record['status'] == "0" && $config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS UNSAFE") {
						$detected_unsafe = true;
					}

					if ($detected_unsafe != true && $config['DATA_PRIVACY_UNSAFE'] == "BLOCKED TO SEARCH ENGINES") {
						
						$a = explode(" ", $record['page_title']);
                        $b = explode(" ", $record['meta_description']);
                        $c = array();

                        $tmp = explode(".", $record['domain']);
                        foreach ($tmp as $value) {
                            if (strpos($value,"-") === false) {
                                $c[] = $value;
                            } else {
                                $tmp_s = explode("-", $value);
                                foreach ($tmp_s as $value_s) {
                                    $c[] = $value_s;
                                }
                            }
                        }

                        $tmp = array_merge($a, $b, $c);
                        $combined = array();

                        foreach ($tmp as $v) {
                            $v = correctTag($v);
                            $combined[] = htmlentities($v, ENT_QUOTES, 'UTF-8');
                        }

                        $combined = array_unique(array_filter($combined));
                        $combined_check_list = "'" . implode("', '", $combined) . "'";

                        $sql_1 = "SELECT COUNT(id) AS total FROM tags WHERE tag IN ($combined_check_list) && status = 2";
                        $row_1 = $db->query_first($sql_1);

                        $sql_2 = "SELECT COUNT(id) AS total FROM blockings WHERE data IN ($combined_check_list) && type = 'KEYWORDS'";
                        $row_2 = $db->query_first($sql_2);

                        if ($row_1['total'] > 0 || $row_2['total'] > 0) {
                            $detected_unsafe = true;
                        }

					}

					if ($detected_unsafe == true) {
						$smarty->assign('is_unsafe', true);
						$data['meta'][] = "<META NAME='ROBOTS' CONTENT='NOINDEX, NOFOLLOW'>";
					}

				/* Formatted Data
				-------------------------------------------------- */
					$data['stat']['formatted']['stat_heading'] 				= sprintf($lang['stat']['heading']['analysis'], $record['domain'], $data['stat']['estimated_value']);
					$data['stat']['formatted']['map_string'] 				= sprintf($lang['stat']['value']['map_locate'], $record['domain'], $data['stat']['hosted_ip_location']);
					$data['stat']['formatted']['meta_title_heading'] 		= sprintf($lang['stat']['heading']['meta_title'], $record['domain']);
					$data['stat']['formatted']['meta_description_heading'] 	= sprintf($lang['stat']['heading']['meta_description'], $record['domain']);
					$data['stat']['formatted']['meta_tags_heading'] 		= sprintf($lang['stat']['heading']['meta_tags'], $record['domain']);
					$data['stat']['formatted']['same_host_heading'] 		= sprintf($lang['stat']['heading']['same_host'], $record['hosted_ip']);


				/* Prepare Stat Overview
				-------------------------------------------------- */
					$overview = array();

					if ($record['domain_registered'] != "0000-00-00") {
						$tmp = niceTime(array('timestamp' => $record['domain_registered'], 'detailLevel' => 2));
						$overview[] = sprintf($lang["stat"]["overview"]["domain_age"], $record['domain'], $tmp['string']);
					}

					if ($data['stat']['is_subdomain']) {
						$tmp = explode(".", $record['domain']);
						array_shift($tmp);
						$main_domain = implode(".", $tmp);
						$overview[] = sprintf($lang["stat"]["overview"]["subdomain"], $main_domain);
					}

					if ($record['alexa_rank'] > 0) {
						$overview[] = sprintf($lang["stat"]["overview"]["alexa"], $data['stat']['alexa_rank']);
					}

					if (!$data['stat']['is_subdomain']) {
						$tmp = "<a href='" . APP_BASE_URI . $config['PREFIX_EXTENSION'] . "/" . $record['extension'] . "/' title='" . $lang["link"]["title"]["extension"] . "'>." . $record['extension'] . "</a>";
						$overview[] = sprintf($lang["stat"]["overview"]["extension"], $tmp);
					}

					if ($record['google_pr'] > 0) {
						$overview[] = sprintf($lang["stat"]["overview"]["pagerank"], $record['google_pr']);
					}

					$overview[] = sprintf($lang["stat"]["overview"]["estimation"], $data['stat']['estimated_value'], $data['stat']['income_per_day']);

					if ($record['is_dmoz_listed'] == "1") {
						$overview[] = $lang["stat"]["overview"]["dmoz_listed"];
					}

					if (!empty($data['stat']['adsense_pub_id'])) {
						$tmp_1 = APP_BASE_URI . $config['PREFIX_ADSENSE'] . "/" . $data['stat']['adsense_pub_id'] . "/";
						$overview[] = sprintf($lang["stat"]["overview"]["adsense"], $tmp_1, $lang["link"]["title"]["adsense"]);
					}

					if (in_array($data['stat']['google_safe_browsing'], array(2, 3)) || $data['stat']['siteadvisor_rating'] == "3") {
						$overview[] = sprintf($lang["stat"]["overview"]["safety"]["unsafe"], $record['domain']);
					} elseif ($data['stat']['google_safe_browsing'] == "1" || $data['stat']['siteadvisor_rating'] == "2") {
						$overview[] = sprintf($lang["stat"]["overview"]["safety"]["suspicious"], $record['domain']);
					} elseif ($data['stat']['google_safe_browsing'] == "0" || in_array($data['stat']['siteadvisor_rating'], array(0, 1))) {
						$overview[] = sprintf($lang["stat"]["overview"]["safety"]["safe"], $record['domain']);
					}
					
					$data['stat']["overview"] = implode(" ", $overview);

					$page_title = sprintf($lang["stat"]["title"]["analysis"], $record['domain'], $data['stat']['estimated_value']);
				
			}

		$data['page_title'] = $page_title . sprintf(' %s ', $config['TITLEBAR_SEPERATOR']) . $config['SITE_TITLE'];

		$smarty->assign('data', $data);

	}

$smarty->display($template, $cache_id);
?>