<?php
header("Content-Type: application/xml");
$template = APP_THEME . "/rss.tpl";

/* Prepare Valid Domain Status
-------------------------------------------------- */				
	$valid_domain_status = array();
	$valid_domain_status[] = 1;

	if ($config['DATA_PRIVACY_UNSAFE'] == "ALLOWED TO ALL") {
		$valid_domain_status[] = 2;
	}

	if ($config['MANUAL_APPROVAL_DOMAIN'] == "DISABLED") {
		$valid_domain_status[] = 0;
	} elseif ($config['MANUAL_APPROVAL_DOMAIN'] == "ENABLED" && $config['DATA_PRIVACY_PENDING'] == "ALLOWED AS SAFE") {
		$valid_domain_status[] = 0;
	}

	if (count($valid_domain_status) == 1) {
        $safe_where_domain = "status = $valid_domain_status[0] &&";
    } elseif (count($valid_domain_status) == 2) {
        $safe_where_domain = "status IN ('" . implode("', '", $valid_domain_status) . "') &&";
    }

$sql = "SELECT 
			domain, IM.page_title AS title, IM.meta_description AS description
		FROM 
			insights_base IB
		INNER JOIN
			insights_meta IM ON IM.domain_id = IB.id && IM.page_title != ''
		WHERE
			$safe_where_domain added_date = updated_date
		ORDER BY
			added_datetime DESC
		LIMIT 10";

$rows = $db->fetch_array($sql);

$listings = array();
foreach ($rows as $record) {

	$listings[] = array(
		'domain' => $record['domain'],
		'stat_link' => getStatLink($record['domain']),
		'title' => stripslashes(html_entity_decode($record['title'], ENT_QUOTES, 'UTF-8')),
		'description' => stripslashes(html_entity_decode($record['description'], ENT_QUOTES, 'UTF-8'))
	);

}

$data['listings'] 	= $listings;

$smarty->assign('data', $data);

$smarty->display($template);
?>