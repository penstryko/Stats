<?php
function finalProcess($arguments, $is_cron = false) {

    global $config;
    $db = Database::obtain();

    $time_stamp             = date('Y-m-d H:i:s');
    $date                   = date('Y-m-d');
    $domain                 = $arguments['domain'];
    $extension              = $arguments['extension'];
    $is_sub_domain          = $arguments['is_sub_domain'];
    $process_type           = $arguments['type'];
    $data                   = $arguments['data'];
    $total_internet_users   = $arguments['total_internet_users'];

    /* Add or Update data to Table: insights_base,
     * so that we can get domain_id that is linked on all other tables.
    -------------------------------------------------- */
        if ($process_type == "add") {

            $insights_base['domain']            = $domain;
            $insights_base['extension']         = $extension;
            $insights_base['is_subdomain']      = ($is_sub_domain == 'yes' ? 1 : 0);
            $insights_base['is_cron']           = ($is_cron == true ? 1 : 0);

            $insights_base['added_datetime']    = (empty($data['added_datetime'])) ? $time_stamp : $data['added_datetime'];
            $insights_base['updated_datetime']  = (empty($data['updated_datetime'])) ? $time_stamp : $data['updated_datetime'];

            $insights_base['added_date']        = (empty($data['added_date'])) ? $date : $data['added_date'];
            $insights_base['updated_date']      = (empty($data['updated_date'])) ? $date : $data['updated_date'];

            $domain_id = $db->insert("insights_base", $insights_base);

        } else {

            $insights_base['updated_datetime']  = $time_stamp;
            $insights_base['updated_date']      = $date;
            $insights_base['is_cron']           = 0;
            $db->update("insights_base", $insights_base, "domain='$domain'");

            if ($db->affected_rows > 0) {
                
                $sql = "SELECT id, status, average_rating FROM insights_base WHERE domain='$domain'";
                $row = $db->query_first($sql);
                $domain_id = $row['id'];
                $current_status = $row['status'];
            }

        }

    /* Process further when we successfully get Domain ID from base table
    -------------------------------------------------- */
        if ($domain_id > 0) {

            /* Process Meta Tags
            -------------------------------------------------- */
                
                // Get Existing Tag Entries

                    $existing_tags = array();
                    $sql = "SELECT tags.id AS id, tags.tag AS tag FROM tags INNER JOIN insights_tags ON tags.id = insights_tags.tag_id WHERE insights_tags.domain_id = '$domain_id'";
                    $rows = $db->fetch_array($sql);
                    foreach ($rows as $record) {
                        $existing_tags[$record['id']] = $record['tag'];
                    }
                    
                // Sanitize and Prepare array of New Tags

                    $tmp_tags = array();
                    $tmp = explode(",", $data['meta_tags']);
                    foreach ($tmp as $v) {
                        $v = correctTag($v);
                        $tmp_tags[] = htmlentities($v, ENT_QUOTES, 'UTF-8', false);
                    }
                    $tmp_tags = array_unique(array_filter($tmp_tags));

                // Remove Non Existing Old Tags Relationship with this Domain

                    $old_tags_id = array_keys(array_diff($existing_tags, $tmp_tags));
                    if (count($old_tags_id) > 0) {
                        $db->query("DELETE FROM insights_tags WHERE domain_id = '$domain_id' && tag_id IN ('" . implode("', '", $old_tags_id) . "')");
                    }

                // Process New Tags

                    $new_tags = array_values(array_diff($tmp_tags, $existing_tags));
                    if (count($new_tags) > 0) {

                        $check_list = "'" . implode("', '", $new_tags) . "'";

                        $blocked_keywords = array();
                        $sql = "SELECT data FROM blockings WHERE type = 'KEYWORDS' && data IN ($check_list)";
                        $rows = $db->fetch_array($sql);
                        foreach ($rows as $record) {
                            $blocked_keywords[] = $record['data'];
                        }
                        $detected_unsafe = (count($blocked_keywords) > 0 ? true : false);

                        $tag_ids = array();
                        $sql = "SELECT id, tag FROM tags WHERE tag IN ($check_list)";
                        $rows = $db->fetch_array($sql);
                        foreach ($rows as $record) {
                            $tag_ids[$record['tag']] = $record['id'];
                        }

                        foreach ($new_tags as $new_tag) {

                            if (array_key_exists($new_tag, $tag_ids)) {
                                $tag_id = $tag_ids[$new_tag];
                            } else {
                                $tags['tag'] = $new_tag;
                                $tags['slug'] = str_replace(" ", "-", $new_tag);
                                $tags['status'] = (in_array($new_tag, $blocked_keywords) ? 2 : 0);
                                $tag_id = $db->insert("tags", $tags);
                                unset($tags);
                            }

                            if ($tag_id > 0) {
                                $insights_tags['domain_id'] = $domain_id;
                                $insights_tags['tag_id'] = $tag_id;
                                $db->insert("insights_tags", $insights_tags);
                            }

                        }

                    }

            /* Process Nameservers if it is not a sub domain
            -------------------------------------------------- */

                if ($is_sub_domain != 'yes' && is_array($data['nameservers']) && count($data['nameservers']) > 0) {

                    // Get Existing Nameserver Entries

                        $existing_nameservers = array();
                        $sql = "SELECT * FROM nameservers INNER JOIN insights_nameservers ON nameservers.id = insights_nameservers.nameserver_id WHERE insights_nameservers.domain_id = '$domain_id'";
                        $rows = $db->fetch_array($sql);
                        foreach ($rows as $record) {
                            $existing_nameservers[$record['ns_host']] = array(
                                'record_id'     => $record['id'],
                                'ns_ip'         => $record['ns_ip'],
                                'ns_country'    => $record['ns_country']
                                );
                        }

                    // Sanitize and Prepare array of New Nameservers

                        $tmp_nameservers = array();
                        if (count($data['nameservers']) > 0) {
                            foreach ($data['nameservers'] as $v) {
                                $tmp_nameservers[strtolower($v['ns_host'])] = array(
                                    'ns_ip'         => $v['ns_ip'],
                                    'ns_country'    => strtoupper($v['ns_country'])
                                    );
                            }
                            $tmp_nameservers = array_filter($tmp_nameservers);
                        }

                    // Remove Non Existing Old Nameservers Relationship with this Domain

                        $old_nameservers = array_diff_key($existing_nameservers, $tmp_nameservers);
                        if (count($old_nameservers) > 0) {

                            $old_nameserver_id = array();
                            foreach ($old_nameservers as $k => $v) {
                                $old_nameserver_id[] = $v['record_id'];
                            }

                            $db->query("DELETE FROM insights_nameservers WHERE domain_id = '$domain_id' && nameserver_id IN ('" . implode("', '", $old_nameserver_id) . "')");
                        }

                    // Update Changes on Common Nameservers (if any)

                        $common_nameservers = array_intersect_key($existing_nameservers, $tmp_nameservers);
                        if (count($common_nameservers) > 0) {

                            $check_list = "'" . implode("', '", array_keys($common_nameservers)) . "'";

                            $nameserver_ids = array();
                            $sql = "SELECT * FROM nameservers WHERE ns_host IN ($check_list)";
                            $rows = $db->fetch_array($sql);
                            foreach ($rows as $record) {
                                $nameserver_ids[$record['ns_host']] = array(
                                    'record_id'     => $record['id'],
                                    'ns_ip'         => $record['ns_ip'],
                                    'ns_country'    => $record['ns_country']
                                    );
                            }

                            foreach ($common_nameservers as $k => $v) {

                                $nameserver_id = $nameserver_ids[$k]['record_id'];
                                if ($nameserver_ids[$k]['ns_ip'] != $v['ns_ip'] || $nameserver_ids[$k]['ns_country'] != $v['ns_country']) {
                                    $nameservers['ns_ip'] = $v['ns_ip'];
                                    $nameservers['ns_country'] = $v['ns_country'];
                                    $db->update("nameservers", $nameservers, "id='$nameserver_id'");
                                }

                            }

                        }

                    // Process New Nameservers

                        $new_nameservers = array_diff_key($tmp_nameservers, $existing_nameservers);
                        if (count($new_nameservers) > 0) {

                            $check_list = "'" . implode("', '", array_keys($new_nameservers)) . "'";

                            $nameserver_ids = array();
                            $sql = "SELECT * FROM nameservers WHERE ns_host IN ($check_list)";
                            $rows = $db->fetch_array($sql);
                            foreach ($rows as $record) {
                                $nameserver_ids[$record['ns_host']] = array(
                                    'record_id'     => $record['id'],
                                    'ns_ip'         => $record['ns_ip'],
                                    'ns_country'    => $record['ns_country']
                                    );
                            }

                            foreach ($new_nameservers as $k => $v) {

                                if (array_key_exists($k, $nameserver_ids)) {
                                    $nameserver_id = $nameserver_ids[$k]['record_id'];
                                    if ($nameserver_ids[$k]['ns_ip'] != $v['ns_ip'] || $nameserver_ids[$k]['ns_country'] != $v['ns_country']) {
                                        $nameservers['ns_ip'] = $v['ns_ip'];
                                        $nameservers['ns_country'] = $v['ns_country'];
                                        $db->update("nameservers", $nameservers, "id='$nameserver_id'");
                                    }
                                } else {
                                    $nameservers['ns_host'] = $k;
                                    $nameservers['ns_ip'] = $v['ns_ip'];
                                    $nameservers['ns_country'] = $v['ns_country'];
                                    $nameserver_id = $db->insert("nameservers", $nameservers);
                                    unset($nameservers);
                                }

                                if ($nameserver_id > 0) {
                                    $insights_nameservers['domain_id'] = $domain_id;
                                    $insights_nameservers['nameserver_id'] = $nameserver_id;
                                    $db->insert("insights_nameservers", $insights_nameservers);
                                }

                            }

                        }

                } else {
                    $db->query("DELETE FROM insights_nameservers WHERE domain_id = '$domain_id'");
                }

            /* Process Hosted IP
            -------------------------------------------------- */
                
                $hosted_ip = array(
                    'ip' => trim($data['hosted_ip']),
                    'latitude' => trim($data['hosted_ip_latitude']),
                    'longitude' => trim($data['hosted_ip_longitude']),
                    'country' => strtoupper(trim($data['hosted_ip_country'])),
                    'friendly_location' => trim($data['hosted_ip_friendly_location'])
                    );

                $sql = "SELECT * FROM hosted_ips WHERE ip = '$hosted_ip[ip]'";
                $row = $db->query_first($sql);

                if (!empty($row['id'])) {

                    $hosted_ip_id = $row['id'];

                    if ($hosted_ip['latitude'] != $row['latitude'] || $hosted_ip['longitude'] != $row['longitude'] || $hosted_ip['country'] != $row['country'] || $hosted_ip['friendly_location'] != $row['friendly_location']) {
                        $db->update("hosted_ips", $hosted_ip, "id='$hosted_ip_id'");
                    }

                } else {

                    $hosted_ip_id = $db->insert("hosted_ips", $hosted_ip);

                }

            /* Process Owner Email
            -------------------------------------------------- */

                $owner_email = strtolower($data['owner_email']);

                if (filter_var($owner_email, FILTER_VALIDATE_EMAIL)) {

                    $sql = "SELECT id FROM owner_emails WHERE email = '$owner_email'";
                    $row = $db->query_first($sql);

                    if (!empty($row['id'])) {
                        $owner_email_id = $row['id'];
                    } else {

                        $owner_emails['email'] = $owner_email;
                        $owner_email_id = $db->insert("owner_emails", $owner_emails);

                    }

                }

            /* Process Registrar
            -------------------------------------------------- */

                $registrar = trim($data['registrar']);

                if (!empty($registrar)) {

                    $registrar_slug = str_replace(" ", "-", correctTag($registrar));
                    $sql = "SELECT id FROM registrars WHERE slug = '$registrar_slug'";
                    $row = $db->query_first($sql);

                    if (!empty($row['id'])) {
                        $registrar_id = $row['id'];
                    } else {

                        $registrars['registrar'] = htmlentities($registrar, ENT_QUOTES, 'UTF-8', false);
                        $registrars['slug'] = $registrar_slug;
                        $registrar_id = $db->insert("registrars", $registrars);

                    }

                }

            /* Process Adsense
            -------------------------------------------------- */

                $adsense_pub_id = strtolower(trim($data['adsense_pub_id']));

                if (!empty($adsense_pub_id)) {

                    $sql = "SELECT id FROM adsense WHERE pub = '$adsense_pub_id'";
                    $row = $db->query_first($sql);

                    if (!empty($row['id'])) {
                        $adsense_id = $row['id'];
                    } else {

                        $adsense['pub'] = $adsense_pub_id;
                        $adsense_id = $db->insert("adsense", $adsense);

                    }

                }

            /* Process Estimation Data
            -------------------------------------------------- */

                $estimations_args = array(
                    'alexa_rank' => $data['alexa_rank'],
                    'total_internet_users' => $total_internet_users
                    );
                $estimation = processEstimation($estimations_args);

            /* Prepare Data for normal tables
            -------------------------------------------------- */
                
                $data_meta['page_title']                        = htmlentities(trim($data['page_title']), ENT_QUOTES, 'UTF-8', false);
                $data_meta['meta_description']                  = htmlentities(trim($data['meta_description']), ENT_QUOTES, 'UTF-8', false);

                $data_header['data']                            = json_encode($data['header_data']);

                $data_dns['data']                               = json_encode($data['dns_records']);

                $data_whois['full_whois']                       = (!empty($data['full_whois'])) ? htmlentities(trim($data['full_whois']), ENT_QUOTES, 'UTF-8', false) : "" ;

                $data_update_base['adsense_id']                 = ($adsense_id > 0 ? $adsense_id : NULL);
                $data_update_base['owner_email_id']             = ($owner_email_id > 0 ? $owner_email_id : NULL);
                $data_update_base['registrar_id']               = ($registrar_id > 0 ? $registrar_id : NULL);
                $data_update_base['hosted_country']             = strtoupper(trim($data['hosted_ip_country']));
                $data_update_base['hosted_ip_id']               = $hosted_ip_id;
                $data_update_base['domain_status']              = json_encode($data['domain_status']);
                $data_update_base['domain_registered']          = trim($data['domain_registered']);
                $data_update_base['domain_modified']            = trim($data['domain_modified']);

                $data_update_base['domain_expires']             = (is_array($data['domain_expires'])) ? $data['domain_expires'] : trim($data['domain_expires']);
                $data_update_base['daily_unique_visits']        = filter_var($estimation['daily_unique_visits'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['daily_page_views']           = filter_var($estimation['daily_page_views'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['income_per_day']             = trim($estimation['income_per_day']);
                $data_update_base['estimated_value']            = trim($estimation['estimated_value']);

                $data_update_base['google_indexed_page']        = filter_var($data['google_indexed_page'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['google_inbound_links']       = filter_var($data['google_inbound_links'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['google_pr']                  = (int)$data['pagerank'];
                $data_update_base['google_pagespeed']           = (int)$data['pagespeed_score'];
                $data_update_base['google_pagespeed_stats']     = json_encode($data['pagespeed_stats']);
                $data_update_base['yahoo_indexed_page']         = filter_var($data['yahoo_indexed_page'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['bing_indexed_page']          = filter_var($data['bing_indexed_page'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['bing_inbound_links']         = filter_var($data['bing_inbound_links'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['alexa_rank']                 = filter_var($data['alexa_rank'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['alexa_inbound_links']        = filter_var($data['alexa_inbound_links'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['seomoz_domain_authority']    = (int)round($data['domain_authority']);
                $data_update_base['is_dmoz_listed']             = (int)$data['is_dmoz_listed'];
                $data_update_base['fb_share_count']             = filter_var($data['fb_share_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['fb_like_count']              = filter_var($data['fb_like_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['fb_comment_count']           = filter_var($data['fb_comment_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['twitter_count']              = filter_var($data['twitter_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['linkedin_share_count']       = filter_var($data['linkedin_share_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['delicious_total_posts']      = filter_var($data['delicious_total_posts'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['g_plus_count']               = filter_var($data['g_plus_count'], FILTER_SANITIZE_NUMBER_INT);
                $data_update_base['google_safe_browsing']       = (int)$data['google_safe_browsing'];
                $data_update_base['wot_rating']                 = json_encode($data['wot_rating']);
                $data_update_base['siteadvisor_rating']         = (int)$data['siteadvisor'];
                $data_update_base['inpage_analysis']            = json_encode($data['inpage_analysis']);

            /* Add/Update Data to normal Table
            -------------------------------------------------- */

                if ($process_type == "add") {

                    $data_meta['domain_id']                     = $domain_id;
                    $data_header['domain_id']                   = $domain_id;
                    $data_dns['domain_id']                      = $domain_id;
                    
                    $db->insert("insights_meta", $data_meta);
                    $db->insert("insights_header", $data_header);
                    $db->insert("insights_dns", $data_dns);
                    $db->update('insights_base', $data_update_base, "id='$domain_id'");

                    if ($is_sub_domain != 'yes') {
                        $data_whois['domain_id']                = $domain_id;
                        $db->insert("insights_full_whois", $data_whois);
                    }

                } else {

                    /* Check if we have entries on tables 
                    -------------------------------------------------- */

                        $sql = "SELECT
                                    IB.id AS ibid,
                                    IM.domain_id AS imdi,
                                    IH.domain_id AS ihdi,
                                    ID.domain_id AS iddi,
                                    IFW.domain_id AS ifwdi
                                FROM
                                    insights_base IB
                                LEFT JOIN insights_meta IM ON IB.id = IM.domain_id
                                LEFT JOIN insights_header IH ON IB.id = IH.domain_id
                                LEFT JOIN insights_dns ID ON IB.id = ID.domain_id
                                LEFT JOIN insights_full_whois IFW ON IB.id = IFW.domain_id
                                WHERE
                                    IB.id = '$domain_id'";
                        $row = $db->query_first($sql);

                    /* Process Further
                    -------------------------------------------------- */

                        if (empty($row['imdi'])) {
                            $data_meta['domain_id'] = $domain_id;
                            $db->insert("insights_meta", $data_meta);
                        } else {
                            $db->update("insights_meta", $data_meta, "domain_id='$domain_id'");
                        }

                        if (empty($row['ihdi'])) {
                            $data_header['domain_id'] = $domain_id;
                            $db->insert("insights_header", $data_header);
                        } else {
                            $db->update("insights_header", $data_header, "domain_id='$domain_id'");
                        }

                        if (empty($row['iddi'])) {
                            $data_dns['domain_id'] = $domain_id;
                            $db->insert("insights_dns", $data_dns);
                        } else {
                            $db->update("insights_dns", $data_dns, "domain_id='$domain_id'");
                        }

                        if ($is_sub_domain != 'yes') {

                            if (empty($row['ifwdi'])) {
                                $data_whois['domain_id'] = $domain_id;
                                $db->insert("insights_full_whois", $data_whois);
                            } else {
                                $db->update("insights_full_whois", $data_whois, "domain_id='$domain_id'");
                            }
                            
                        }

                }

                /* Final Updates to Table: insights_base
                -------------------------------------------------- */

                    /* Generate Average Rating
                     * Metrics Used: Pagerank, Safebrowsing, Domain Authority
                    -------------------------------------------------- */
                        $ar_point = 3;
                        $tmp_ar = 0;
                        $tmp_ar += $data_update_base['google_pr']/2;
                        $tmp_ar += $data_update_base['seomoz_domain_authority']/20;
                        $tmp_ar += ($data_update_base['google_safe_browsing'] > 0) ? 0 : 5 ;
                        $tmp_ar = round($tmp_ar/$ar_point, 2);
                        $average_rating = ($tmp_ar < 1) ? 0.5 : $tmp_ar ;
                        
                        $data_update_base['average_rating'] = $average_rating;

                    if ($data_update_base['google_safe_browsing'] != 0 ) {
                        $detected_unsafe = true;
                    }

                    if ($current_status == "0" && $detected_unsafe != true) {

                        $sql = "SELECT id FROM blockings WHERE data = '$domain' && type = 'DOMAINS'";
                        $row = $db->query_first($sql);

                        if (!empty($row['id'])) {
                            $detected_unsafe = true;
                        } else {

                            $a = explode(",", $data['meta_tags']);
                            $b = explode(" ", $data['page_title']);
                            $c = explode(" ", $data['meta_description']);
                            $d = array();

                            $tmp = explode(".", $domain);
                            foreach ($tmp as $value) {
                                if (strpos($value,"-") === false) {
                                    $d[] = $value;
                                } else {
                                    $tmp_s = explode("-", $value);
                                    foreach ($tmp_s as $value_s) {
                                        $d[] = $value_s;
                                    }
                                }
                            }

                            $tmp = array_merge($a, $b, $c, $d);
                            $combined = array();

                            foreach ($tmp as $v) {
                                $v = correctTag($v);
                                $combined[] = htmlentities($v, ENT_QUOTES, 'UTF-8', false);
                            }

                            $combined = array_unique(array_filter($combined));
                            $combined_check_list = "'" . implode("', '", $combined) . "'";

                            $sql_1 = "SELECT COUNT(id) AS total FROM tags WHERE tag IN ($combined_check_list) && status = 2";
                            $row_1 = $db->query_first($sql_1);

                            $sql_2 = "SELECT COUNT(id) AS total FROM blockings WHERE data IN ($combined_check_list) && type = 'KEYWORDS'";
                            $row_2 = $db->query_first($sql_2);

                            if ($row_1['total'] > 0 || $row_2['total'] > 0) {
                                $detected_unsafe = true;
                            }

                        }

                    }

                    if ($current_status == "0" && $detected_unsafe == true) {
                        $data_update_base['status'] = 2;
                    }

                    $db->update("insights_base", $data_update_base, "id='$domain_id'");

                $response = array(
                    'status' => 'success',
                    'is_unsafe' => $detected_unsafe
                );

        } else {

            $response = array(
                'status' => 'error',
                'msg' => 'Unable to Get Domain ID from Base Table.'
            );

        }

        return $response;

}
?>