<?php

/* Multiple Usages: Global
-------------------------------------------------- */

	$lang["global"]["button"]["submit"]		= "Submit";
	$lang["global"]["button"]["reset"]		= "Reset";
	$lang["global"]["rating"]["hints"]		= "'Poor', 'Satisfactory', 'Good', 'Excellent', 'Outstanding'";

/* Usages: Lookup Form
-------------------------------------------------- */

	$lang["lookup"]["placeholder"] 	= "Enter your Query Here!";
	$lang["lookup"]["button"] 		= "Lookup";
	$lang["lookup"]["auto"] 		= "Auto Detect";
	$lang["lookup"]["domain"] 		= "Domain Name";
	$lang["lookup"]["keyword"] 		= "Tag or Keyword";
	$lang["lookup"]["email"] 		= "E-Mail Address";
	$lang["lookup"]["ip"] 			= "IP Address";
	$lang["lookup"]["nameserver"] 	= "Name Server";

/* Usages: Processing
-------------------------------------------------- */
	
	$lang["process"]["title"] 					= "Processing Your Query";
	$lang["process"]["oops_heading"]			= "Oops! There is an Error...";

	$lang["process"]["missing_query"] 			= "We expect some Valid Query Data but you are trying to process without it.<br />Use the lookup form above and submit it with a valid Query.";
	$lang["process"]["missing_valid_domain"] 	= "We expect here a Valid Domain Name but you are trying to access the page without it.<br />Use the lookup form above and submit it with a valid Domain Name.";
	$lang["process"]["error_update_block"]		= "You can not update Domain Stats frequently.<br />Please wait until the Block Period for Stat Update expires.";
	$lang["process"]["error_domain_block"]		= "The domain is currently blocked on our system<br />You will not be able to process it.";

	$lang["process"]["heading"]["add"] 			= "Oh! A New Domain Name?";
	$lang["process"]["heading"]["add_process"] 	= "Processing New Domain...";
	$lang["process"]["details"]["add"] 			= "Supplied Domain Name is detected as a New on Our Database.<br />Please Wait while we gather information on it.<br />For your information, it may take upto 60 Seconds.";

	$lang["process"]["heading"]["update"] 			= "Oh! You need Updated Information?";
	$lang["process"]["heading"]["update_process"] 	= "Processing Stat Update...";
	$lang["process"]["details"]["update"] 			= "Stat Update for the supplied Domain Name is now Running.<br />Please Wait while we gather and update information on it.<br />For your information, it may take upto 60 Seconds.";

	$lang["process"]["label"]["started"] 		= "Process Started";
	$lang["process"]["label"]["wait"] 			= "Please Wait...";

	$lang["process"]["label"]["running"] 		= "Running";
	$lang["process"]["label"]["complete"] 		= "Complete";
	$lang["process"]["label"]["error"] 			= "Error";
	$lang["process"]["label"]["failed"] 		= "Failed";
	$lang["process"]["label"]["failed_step"] 	= "<strong>Further Processing Stopped because of a Failed Step.</strong>";

	$lang["process"]["label"]["meta"]			= "Gathering Meta Information";
	$lang["process"]["label"]["dns"]			= "Gathering DNS Records";
	$lang["process"]["label"]["host"]			= "Gathering Host Information";
	$lang["process"]["label"]["searchengine"]	= "Gathering Search Engines Data";
	$lang["process"]["label"]["pagerank"]		= "Gathering Google PageRank Data";
	$lang["process"]["label"]["pagespeed"]		= "Gathering Google PageSpeed Data";
	$lang["process"]["label"]["safebrowsing"]	= "Gathering Google Safe Browsing Data";
	$lang["process"]["label"]["weboftrust"]		= "Gathering Web of Trust Data";
	$lang["process"]["label"]["siteadvisor"]	= "Gathering SiteAdvisor Rating Data";
	$lang["process"]["label"]["alexa"]			= "Gathering Alexa Data";
	$lang["process"]["label"]["social"]			= "Gathering Social Data";
	$lang["process"]["label"]["seomoz"]			= "Gathering SEOMoz Data";
	$lang["process"]["label"]["whois"]			= "Gathering WHOIS Information";
	$lang["process"]["label"]["add"]			= "Adding Domain Information to the Database";
	$lang["process"]["label"]["update"]			= "Updating Domain Information to the Database";

/* Usages: Page Not Found
-------------------------------------------------- */

	$lang["page_not_found"]				= "Page Not Found";
	$lang["page_not_found_details"]		= "<p>Oops! The page that you are looking for does not exist.</p>";

/* Usages: Contact Form
-------------------------------------------------- */

	$lang["contact_form"]["heading"]			= "Contact Form";
	$lang["contact_form"]["field"]["name"]		= "Full Name:";
	$lang["contact_form"]["field"]["email"]		= "Your E-Mail:";
	$lang["contact_form"]["field"]["subject"]	= "Subject:";
	$lang["contact_form"]["field"]["message"]	= "Your Message:";
	$lang["contact_form"]["field"]["security"]	= "Security:";

	$lang["contact_form"]["error"]["name"]		= "Please enter Your Full Name.";
	$lang["contact_form"]["error"]["email"]		= "Please enter your valid E-Mail address.";
	$lang["contact_form"]["error"]["subject"]	= "Please enter your Subject.";
	$lang["contact_form"]["error"]["message"]	= "Please enter your Message.";
	$lang["contact_form"]["error"]["security"]	= "The reCAPTCHA was not entered correctly.";

	$lang["contact_form"]["message"]["failed"]	= "Error sending your message. Please Try Again.";
	$lang["contact_form"]["message"]["success"]	= "Your message has been successfully sent.";

/* Usages: Link Titles
-------------------------------------------------- */

	$lang["link"]["title"]["extension"]					= "View Websites having this Domain Extension";
	$lang["link"]["title"]["adsense"]					= "View Websites using this Google Adsense ID";
	$lang["link"]["title"]["nameserver"]				= "View Websites Hosted in this Nameserver";
	$lang["link"]["title"]["hosted_country"]			= "View Websites Hosted in this Country";
	$lang["link"]["title"]["hosted_ip"]					= "View Websites Hosted on this IP Address";
	$lang["link"]["title"]["registrar"]					= "View Websites Registered from this Domain Registrar";
	$lang["link"]["title"]["owner_email"]				= "View Websites Owned by this E-Mail Address";

/* Usages: Common Lists (e.g. homepage, pages)
-------------------------------------------------- */
	$lang["common_lists"]["heading"]["recent"]		= "Recently Analyzed";
	$lang["common_lists"]["heading"]["top_site"]	= "List of Top Websites based on Alexa Rank";
	$lang["common_lists"]["heading"]["top_tags"]	= "Popular and Frequently Used Tags";

	$lang["common_lists"]["label"]["alexa"]			= "Alexa";
	$lang["common_lists"]["label"]["pagerank"]		= "Pagerank";
	$lang["common_lists"]["label"]["worth"]			= "Worth";
	$lang["common_lists"]["label"]["updated"]		= "Updated";

	$lang["common_lists"]["label"]["more_topsites"]	= "More Topsites";

/* Usages: Listings
-------------------------------------------------- */
	
	$lang["listing"]["title"]["tag"]			= "%s Websites";
	$lang["listing"]["title"]["email"]			= "Websites Owned by %s";
	$lang["listing"]["title"]["ip"]				= "Websites hosted on %s IP Address";
	$lang["listing"]["title"]["country"]		= "Websites Hosted in %s";
	$lang["listing"]["title"]["nameserver"] 	= "Websites Hosted in %s Nameserver";
	$lang["listing"]["title"]["registrar"]		= "Websites Registered through %s";
	$lang["listing"]["title"]["extension"]		= "Websites having .%s Domain Extension";
	$lang["listing"]["title"]["pagerank"]		= "Websites having Google Pagerank of %s";
	$lang["listing"]["title"]["adsense"]		= "Websites using %s Google Adsense ID";

	$lang["listing"]["heading"]["tag"]			= "%s Websites";
	$lang["listing"]["heading"]["email"]		= "Websites Owned by %s";
	$lang["listing"]["heading"]["ip"]			= "Websites hosted on %s IP Address";
	$lang["listing"]["heading"]["country"] 		= "Websites Hosted in %s";
	$lang["listing"]["heading"]["nameserver"] 	= "Websites Hosted in %s Nameserver";
	$lang["listing"]["heading"]["registrar"]	= "Websites Registered through %s";
	$lang["listing"]["heading"]["extension"]	= "Websites having .%s Domain Extension";
	$lang["listing"]["heading"]["pagerank"]		= "Websites having Google Pagerank of %s";
	$lang["listing"]["heading"]["adsense"]		= "Websites using %s Google Adsense ID";
	$lang["listing"]["heading"]["topsites"]		= "Worldwide Top Websites Ordered by Alexa Traffic Rank";
	$lang["listing"]["heading"]["newsites"]		= "Newly Analyzed Websites";

	$lang["listing"]["info"]["ip"]				= "Geo Location Information for <strong>%s</strong> IP Address. The IP Address <strong>%s</strong> is located at <strong>%s</strong> latitude and <strong>%s</strong> longitude in <strong>%s</strong>. Friendly Location for the IP Address is <strong>%s</strong>";
	$lang["listing"]["info"]["nameserver"]		= "The Nameserver <strong>%s</strong> have a IP Address of <strong>%s</strong> which is hosted on <strong>%s</strong>.";

/* Usages: Stat Overview
-------------------------------------------------- */

	$lang["stat"]["overview"]["domain_age"]				= "%s was registered %s ago.";
	$lang["stat"]["overview"]["subdomain"]				= "It is a sub-domain of %s.";
	$lang["stat"]["overview"]["alexa"]					= "It has a alexa rank of #%s in the world.";
	$lang["stat"]["overview"]["extension"]				= "It is a domain having <b>%s</b> extension.";
	$lang["stat"]["overview"]["pagerank"]				= "This site has a Google PageRank of %s/10.";
	$lang["stat"]["overview"]["estimation"]				= "It is estimated worth of %s and have a daily income of around %s.";
	$lang["stat"]["overview"]["dmoz_listed"]			= "This website is also listed on Dmoz.";
	$lang["stat"]["overview"]["adsense"]				= "Furthermore the website is generating income from <a href='%s' title='%s'>Google Adsense</a>.";
	$lang["stat"]["overview"]["safety"]["safe"]			= "As no active threats were reported recently, %s is SAFE to browse.";
	$lang["stat"]["overview"]["safety"]["suspicious"] 	= "%s is SUSPICIOUS and may contains potentially risky contents. You should be careful while visiting this website.";
	$lang["stat"]["overview"]["safety"]["unsafe"]		= "We found potential security risks with %s and it is Un-SAFE to browse this website. USE EXTEREME CAUTION while visiting this website.";

/* Usages: Stat
-------------------------------------------------- */
	
	$lang["stat"]["not_applicable"] 			= "Not Applicable";
	$lang["stat"]["stat_updated"] 				= "Updated";
	$lang["stat"]["visit_website"] 				= "Visit Website";
	$lang["stat"]["update"] 					= "Update";
	$lang["stat"]["get_widget"] 				= "Get Widget";

	$lang["stat"]["title"]["analysis"]			= "%s is worth %s";
	$lang["stat"]["heading"]["analysis"]		= "<span itemprop='itemreviewed'>%s</span> is worth %s";

	$lang["stat"]["heading"]["traffic"]			= "Traffic Report";
	$lang["stat"]["heading"]["valuation"]		= "Estimated Valuation";
	$lang["stat"]["heading"]["indexes"]			= "Search Engine Indexes";
	$lang["stat"]["heading"]["backLinks"]		= "Search Engine Backlinks";
	$lang["stat"]["heading"]["safety"]			= "Safety Information";
	$lang["stat"]["heading"]["ranks"]			= "Website Ranks & Scores";
	$lang["stat"]["heading"]["webserver"]		= "Web Server Information";
	$lang["stat"]["heading"]["social"]			= "Social Engagement";
	$lang["stat"]["heading"]["resources"]		= "Page Resources Breakdown";
	$lang["stat"]["heading"]["home_links"]		= "Homepage Links Analysis";

	$lang["stat"]["heading"]["meta_title"]			= "Page Title of %s";
	$lang["stat"]["heading"]["meta_description"]	= "Meta Description of %s";
	$lang["stat"]["heading"]["meta_tags"]			= "Meta Tags of %s";
	
	$lang["stat"]["heading"]["inpage_analysis"]	= "Website Inpage Analysis";
	$lang["stat"]["heading"]["same_host"]		= "Websites Hosted on Same IP (i.e. %s)";
	$lang["stat"]["heading"]["headers"]			= "HTTP Header Analysis";
	$lang["stat"]["heading"]["domain_info"]		= "Domain Information";
	$lang["stat"]["heading"]["nameservers"]		= "Domain Nameserver Information";
	$lang["stat"]["heading"]["dns"]				= "DNS Record Analysis";
	$lang["stat"]["heading"]["similar_ranked"]	= "Similarly Ranked Websites";
	$lang["stat"]["heading"]["full_whois"]		= "Full WHOIS Lookup";

	$lang["stat"]["label"]["rating"]			= "Rating by <span itemprop='reviewer'>CuteStatLite</span>";

	$lang["stat"]["label"]["daily_visits"]		= "Daily Unique Visitors";
	$lang["stat"]["label"]["daily_pageviews"]	= "Daily Pageviews";
	$lang["stat"]["label"]["income_per_day"]	= "Income Per Day";
	$lang["stat"]["label"]["estimated_value"]	= "Estimated Worth";
	$lang["stat"]["label"]["google_index"]		= "Google Indexed Pages";
	$lang["stat"]["label"]["yahoo_index"]		= "Yahoo Indexed Pages";
	$lang["stat"]["label"]["bing_index"]		= "Bing Indexed Pages";
	$lang["stat"]["label"]["google_backlinks"]	= "Google Backlinks";
	$lang["stat"]["label"]["bing_backlinks"]	= "Bing Backlinks";
	$lang["stat"]["label"]["alexa_backLinks"]	= "Alexa BackLinks";
	$lang["stat"]["label"]["safe_browsing"]		= "Google Safe Browsing";
	$lang["stat"]["label"]["siteadvisor"]		= "Siteadvisor Rating";
	$lang["stat"]["label"]["wot_trust"]			= "WOT Trustworthiness";
	$lang["stat"]["label"]["wot_privacy"]		= "WOT Privacy";
	$lang["stat"]["label"]["wot_child_safety"]	= "WOT Child Safety";
	$lang["stat"]["label"]["google_pr"]			= "Google Pagerank";
	$lang["stat"]["label"]["alexa_rank"]		= "Alexa Rank";
	$lang["stat"]["label"]["pagespeed"]			= "PageSpeed Score";
	$lang["stat"]["label"]["domain_authority"]	= "Domain Authority";
	$lang["stat"]["label"]["dmoz"] 				= "DMOZ Listing";
	$lang["stat"]["label"]["fb_shares"]			= "Facebook Shares";
	$lang["stat"]["label"]["fb_like"]			= "Facebook Likes";
	$lang["stat"]["label"]["fb_comment"]		= "Facebook Comments";
	$lang["stat"]["label"]["tweets"]			= "Twitter Count (Tweets)";
	$lang["stat"]["label"]["linkedin_shares"]	= "Linkedin Shares";
	$lang["stat"]["label"]["delicious_shares"]	= "Delicious Shares";
	$lang["stat"]["label"]["g_plus_count"]		= "Google+";
	$lang["stat"]["label"]["hosted_ip"]			= "Hosted IP Address";
	$lang["stat"]["label"]["hosted_country"]	= "Hosted Country";
	$lang["stat"]["label"]["latitude"]			= "Location Latitude";
	$lang["stat"]["label"]["longitude"]			= "Location Longitude";

	$lang["stat"]["label"]["h1_tag"]			= "H1 Headings";
	$lang["stat"]["label"]["h2_tag"]			= "H2 Headings";
	$lang["stat"]["label"]["h3_tag"]			= "H3 Headings";
	$lang["stat"]["label"]["h4_tag"]			= "H4 Headings";
	$lang["stat"]["label"]["h5_tag"]			= "H5 Headings";
	$lang["stat"]["label"]["h6_tag"]			= "H6 Headings";
	$lang["stat"]["label"]["iframe"]			= "Total IFRAMEs";
	$lang["stat"]["label"]["images"]			= "Total Images";
	$lang["stat"]["label"]["adsense"]			= "Google Adsense";
	$lang["stat"]["label"]["analytics"]			= "Google Analytics";

	$lang["stat"]["label"]["registrar"]			= "Domain Registrar";
	$lang["stat"]["label"]["registration"]		= "Registration Date";
	$lang["stat"]["label"]["modified"]			= "Last Modified";
	$lang["stat"]["label"]["expiration"]		= "Expiration Date";
	$lang["stat"]["label"]["domain_status"]		= "Domain Status";	
	$lang["stat"]["label"]["owner_email"]		= "Owner's E-Mail";

	$lang["stat"]["value"]["safe"]				= "No Risk Issues"; 		// Used on Google Safe Browsing & Siteadvisor
	$lang["stat"]["value"]["phishing"]			= "Phishing"; 				// Used on Google Safe Browsing
	$lang["stat"]["value"]["malware"]			= "Malware"; 				// Used on Google Safe Browsing
	$lang["stat"]["value"]["phishing_malware"]	= "Phishing & Malware"; 	// Used on Google Safe Browsing
	$lang["stat"]["value"]["caution"]			= "Minor Risk Issues"; 		// Used on Siteadvisor Rating
	$lang["stat"]["value"]["warning"]			= "Serious Risk Issues"; 	// Used on Siteadvisor Rating
	$lang["stat"]["value"]["wot_very_poor"]		= "Very Poor";				// Used on WOT (Web of Trust) Rating
	$lang["stat"]["value"]["wot_poor"]			= "Poor";					// Used on WOT (Web of Trust) Rating
	$lang["stat"]["value"]["wot_unsatisfying"]	= "Unsatisfactory";			// Used on WOT (Web of Trust) Rating
	$lang["stat"]["value"]["wot_good"]			= "Good";					// Used on WOT (Web of Trust) Rating
	$lang["stat"]["value"]["wot_excellent"]		= "Excellent";				// Used on WOT (Web of Trust) Rating
	$lang["stat"]["value"]["dmoz_yes"]			= "Yes";
	$lang["stat"]["value"]["dmoz_no"]			= "No";
	$lang["stat"]["value"]["map_locate"] 		= "%s is Hosted on <br /> %s";

	$lang["stat"]["graph"]["backlinks_discovery"]		= "Backlink History Chart from Majestic SEO";
	$lang["stat"]["graph"]["referring_domains"]			= "Referring Domains Discovery Chart from Majestic SEO";
	$lang["stat"]["graph"]["alexa_traffic_rank"]		= "Alexa Traffic Rank";
	$lang["stat"]["graph"]["alexa_search_traffic"]		= "Alexa Search Engine Traffic";

/* Usages: Generate Widget
-------------------------------------------------- */
	
	$lang["widget"]["heading"]["generate"] 		= "Generate Widgets for";
	$lang["widget"]["heading"]["worth"] 		= "Website Worth Widget";
	$lang["widget"]["heading"]["stat"] 			= "Website Statistics Widget";
	$lang["widget"]["heading"]["pagerank"] 		= "Google Pagerank Widget";

/* Usages: Footer
-------------------------------------------------- */

	$lang["footer"]["copyright"]	= "Copyright &copy; %s %s, All Rights Reserved. <br /> Any other Brand Information used from us are the properties of their respective owners.";
	$lang["footer"]["powered_by"]	= "Powered by:";

?>